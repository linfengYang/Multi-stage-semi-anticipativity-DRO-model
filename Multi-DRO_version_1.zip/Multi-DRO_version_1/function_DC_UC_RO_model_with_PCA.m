function [model] = function_DC_UC_RO_model_with_PCA(UC_model,data,data_wind_history,param)
%FUNCTION_BUILD_DROMODEL �˴���ʾ�йش˺�����ժҪ
%����PCA��³���Ż�
% DC +wind +PCA

%thermal unit
B=data.B;
Alpha = data.units.alpha;                           %���鷢�纯��ϵ��Alpha--N*1����
Beta = data.units.beta;                             %���鷢�纯��ϵ��Beta--N*1����
Gama = data.units.gamma;                            %���鷢�纯��ϵ��Gama--N*1����
ThPimin = data.units.PG_low;                         %���鷢�繦���½�--N*1����
ThPimax = data.units.PG_up;                          %���鷢�繦���Ͻ�--N*1����
Piup = data.units.ramp;                         %�������¹����Ͻ�--N*1����
Pidown = data.units.ramp;                     %�������¹����Ͻ�--N*1����
Pt = data.totalLoad.PD_T;                       %�й�����--T*1����
Qt=data.totalLoad.QD_T;                       %�޹�����--T*1
Bus_G=data.units.bus_G;                           %����ڵ��
N = data.baseparameters.unitN;                 %��������--1*1����
T = data.totalLoad.T;                          %ʱ�����--1*1����
Dt = data.totalLoad.PD_T;                                 %��������--T*1����
bus_P_factor=data.busLoad.bus_P_factor;           %�ڵ��й���������
bus_Q_factor=data.busLoad.bus_Q_factor;            %�ڵ��޹���������
bus_P=data.busLoad.node_P;
Spin = data.totalLoad.R_T;                     %��ת�ȱ���--T*1����
ThTime_on_off_init = data.units.U_ini;        %�����ڳ�ʼ״̬ǰ�Ѿ�����/ͣ����ʱ��--N*1����
Thon_off_init =  data.units.PG_up*0.7;               %��������ʼ����--N*1����
ThTime_on_min = data.units.T_on;             %������С����ʱ��--N*1����
ThTime_off_min = data.units.T_off;           %������Сͣ��ʱ��--N*1����
Th_cost_start = data.units.start_cost;           %������������--N*1����
ThCold_cost_start = data.units.start_cost*2;           %����������������--N*1����
ThHot_cost_start = data.units.start_cost;             %����������������--N*1����
Pistartup = data.units.PG_low;      %�����鿪������--N*1����
Pishutdown = data.units.PG_low;      %������ػ�����--N*1����
Ui0 = full(spones(Thon_off_init));                                  %����������ʼ��/ͣ��״̬
wind_Node=data.Wind.wind_Node;
NodeNum=data.baseparameters.busN;

bool_partition=param.partition;
T_wan=param.T_wan;
T_windows=param.T_windows;


if(NodeNum==118&T_windows<24)
    Pt=Pt(2*T_windows+1:2*T_windows+T_windows);
    Qt=Qt(2*T_windows+1:2*T_windows+T_windows);
    T=T_windows;
    Dt=Dt(2*T_windows+1:2*T_windows+T_windows);
    Spin=Spin(2*T_windows+1:2*T_windows+T_windows);
    bus_P=bus_P(2*T_windows+1:2*T_windows+T_windows);
    
else
    Pt=Pt(1:T_windows);
    Qt=Qt(1:T_windows);
    T=T_windows;
    Dt=Dt(1:T_windows);
    Spin=Spin(1:T_windows);
    bus_P=bus_P(1:T_windows);
end


Ui = max(0,min(ones(N,1) * T,Ui0 .* (ThTime_on_min - ThTime_on_off_init)));                    %--N*1����
Li = max(0,min(ones(N,1) * T,(ones(N,1) - Ui0) .* (ThTime_off_min + ThTime_on_off_init)));     %--N*1����
ThCold_time_start=min(max(2*ThTime_off_min,1),T);
L=4;

%net

branchI=data.branch.I;
branchJ=data.branch.J;
branchR=data.branch.R;
branchX=data.branch.X;
branchP=data.branch.P;
branchB=data.branch.B;
branchGroundI=0;
branchGroundB=0;
branchTransformerI=data.branchTransformer.I;
branchTransformerJ=data.branchTransformer.J;
branchTransformerR=data.branchTransformer.R;
branchTransformerX=data.branchTransformer.X;
branchTransformerK=data.branchTransformer.K;
branchTransformerP=data.branchTransformer.P;

All_branchI=[branchI;branchTransformerI];
All_branchJ=[branchJ;branchTransformerJ];
All_branchX=[branchX;branchTransformerX];
All_branchP=[branchP;branchTransformerP];
%% partion




%%

bus_PDQR=data.busLoad.bus_PDQR;

R=data.Wind.wind_Number;
Lk=4;
rou=1e-2;
%Wind unit
for i=1:R
    M(i)=length(data_wind_history{i});
end
M_min=min(M);
data_wind=[];
%P_w(1,1) P_w(2,1) P_w(3,1)...
for t=1:T
    data_wind_part=[];
    for i=1:R
        data_wind_part=[data_wind_part;data_wind_history{i}(t,1:M_min)];
    end
    if(bool_partition==1)
        data_wind_part=sum(data_wind_part,1);
    end
    data_wind=[data_wind;data_wind_part];
end

R_wan_len=R*T;

P_Wind_Max=max(data_wind,[],2);
P_Wind_Min=min(data_wind,[],2);
miu_average=mean(data_wind,2);
covariance=cov(data_wind');
[U,S,V] = svd (covariance);
diag_S=diag(S);
diag_S_1_2=power(diag_S,0.5);
mean_S=mean(diag_S);
S_log=floor(log10(mean_S));
R_wan=0;
switch(param.PCA)
    case 0
        R_wan=find(log10(diag_S)>S_log);
        R_wan_len=length(R_wan);
    case -1
        R_wan=[1:length(miu_average)];
        R_wan_len=length(R_wan);
    otherwise
        R_wan=[1:param.PCA];
        R_wan_len=length(R_wan);
end

P_wan=(U(:,R_wan)*((S(R_wan,R_wan))^0.5)^(-1))'*(data_wind-repmat(miu_average,1,M_min));
P_wind_PCA=(U(:,R_wan)*((S(R_wan,R_wan))^0.5))*P_wan+repmat(miu_average,1,M_min);
% data_wind_1=data_wind(1:2:end,1);
% data_wind_wan_1=P_wind(1:2:end,1);
P_wan_Wind_Max=max(P_wan,[],2);
P_wan_Wind_Min=min(P_wan,[],2);

Ckl=repmat(P_wan_Wind_Min,1,Lk)+...
    repmat((P_wan_Wind_Max-P_wan_Wind_Min),1,Lk).*...
    repmat(([1:Lk]/Lk),R_wan_len,1);
gamma_R_T_L=[];

for j=1:Lk-1
    gamma_R_T_L=[gamma_R_T_L,mean(max(P_wan-repmat(Ckl(:,j),1,M_min),0),2)+rou*ones(R_wan_len,1)];
end
gamma_k_l=gamma_R_T_L;
%% uit,sit,dit,Sit_wan,PGit,Seitait,Zit,PWrt
% x
x_num=0;
uit_num=N*T;
sit_num=N*T;
dit_num=N*T;
Sit_num=N*T;
x_num=uit_num+sit_num+dit_num+Sit_num;

%other variables
PGit_num=N*T;
Seitait_num=NodeNum*T;
Zit_num=N*T;
PWrt_num=R*T;

if(param.windLoss==1)
    windLoss_num=R*T;
    y_num=PGit_num+Seitait_num+Zit_num+PWrt_num+windLoss_num;
else
    y_num=PGit_num+Seitait_num+Zit_num+PWrt_num;
end
y_location=x_num+1:x_num+y_num;
%location
%x
total_num=0;
uit_location=1:uit_num;
total_num=total_num+length(uit_location);

sit_location=total_num+1:total_num+sit_num;
total_num=total_num+length(sit_location);

dit_location=total_num+1:total_num+dit_num;
total_num=total_num+length(dit_location);

Sit_location=total_num+1:total_num+Sit_num;
total_num=total_num+length(Sit_location);
%y
PGit_location=total_num+1:total_num+PGit_num;
PGit_in_y_location=1:PGit_num;
total_num=total_num+length(PGit_location);

Seitait_location=total_num+1:total_num+Seitait_num;
Seitait_in_y_location=1+PGit_num:PGit_num+Seitait_num;
total_num=total_num+length(Seitait_location);

Zit_location=total_num+1:total_num+Zit_num;
Zit_in_y_location=1+PGit_num+Seitait_num:PGit_num+Seitait_num+Zit_num;
total_num=total_num+length(Zit_location);

PWrt_location=total_num+1:total_num+PWrt_num;
PWrt_in_y_location=PGit_num+Seitait_num+Zit_num+1:PGit_num+Seitait_num+Zit_num+PWrt_num;
total_num=total_num+length(PWrt_location);

if(param.windLoss==1)
    windLoss_location=total_num+1:total_num+windLoss_num;
    windLoss_in_y_location=PGit_num+Seitait_num+Zit_num+PWrt_num+1:PGit_num+Seitait_num+Zit_num+PWrt_num+windLoss_num;
    total_num=total_num+length(windLoss_location);
    
    Wl_location=total_num+1:total_num+1;
    total_num=total_num+length(Wl_location);
end

%% Constraints without uncertain

Aeq_constraints_state=UC_model.Aeq_constraints_state;
beq_constraints_state=UC_model.beq_constraints_state;
%% initial status

Aeq_constraints_initial_statues=[UC_model.Aeq_constraints_initial_statues];
beq_constraints_initial_statues=[UC_model.beq_constraints_initial_statues];
%% start_cost_constraint

Aineq_constraint_start_cost=[UC_model.Aineq_constraint_start_cost];
bineq_constraint_start_cost=UC_model.bineq_constraint_start_cost;
%% minim up/down time constraint

Aineq_constraint_min_upordown_time=[UC_model.Aineq_constraint_min_upordown_time];
bineq_constraint_min_upordown_time=[UC_model.bineq_constraint_min_upordown_time];
%% Constraints with uncertain


Aineq_ramp_limt=[UC_model.Aineq_constraint_ramp_limt_up;UC_model.Aineq_constraint_ramp_limt_down];
bineq_ramp_limt=[UC_model.bineq_constraint_ramp_limt_up;UC_model.bineq_constraint_ramp_limt_down];
Aineq_genration_limit=[UC_model.Aineq_constraint_genration_limit_upper;UC_model.Aineq_constraint_genration_limit_lower];
bineq_genration_limit=[UC_model.bineq_constraint_genration_limit_upper;UC_model.bineq_constraint_genration_limit_lower];

Aineq_ramp_limt_up=[UC_model.Aineq_constraint_ramp_limt_up];
bineq_ramp_limt_up=[UC_model.bineq_constraint_ramp_limt_up];
Aineq_ramp_limt_down=[UC_model.Aineq_constraint_ramp_limt_down];
bineq_ramp_limt_down=[UC_model.bineq_constraint_ramp_limt_down];

Aineq_genration_limit_upper=[UC_model.Aineq_constraint_genration_limit_upper];
bineq_genration_limit_upper=[UC_model.bineq_constraint_genration_limit_upper];
Aineq_genration_limit_lower=[UC_model.Aineq_constraint_genration_limit_lower];
bineq_genration_limit_lower=[UC_model.bineq_constraint_genration_limit_lower];

%%

if(param.eq==1)
    Aineq_Aeq_DCPowerFlow=[UC_model.Aineq_DCPowerFlow];
    bineq_Aeq_DCPowerFlow=[UC_model.bineq_DCPowerFlow];
    Aineq_Aeq_DCPowerFlow=[UC_model.Aineq_constraint_DCPowerFlow];
    bineq_Aeq_DCPowerFlow=[UC_model.bineq_constraint_DCPowerFlow];
else

    Aineq_Aeq_DCPowerFlow=[UC_model.Aineq_constraint_DCPowerFlow];
    bineq_Aeq_DCPowerFlow=[UC_model.bineq_constraint_DCPowerFlow];
end

%%

Aineq_linear_approximation=[UC_model.Aineq_constraint_linear_approximation];
bineq_linear_approximation=[UC_model.bineq_constraint_linear_approximation];
%%
Aineq_windLoss_constraint=[UC_model.Aineq_LoadLoss_constraint];
bineq_windLoss_constraint=[UC_model.bineq_LoadLoss_constraint];

%% 
Aineq_cost_windLoss=sparse(1,total_num);
Aineq_cost_windLoss(1,windLoss_location)=UC_model.f(windLoss_location(1),1);
Aineq_cost_windLoss(1,Wl_location)=-1;
bineq_cost_windLoss=0;

%% DRO
%uncertain set

%E(u)<=gamma
%p(Pw,u in Q)=1

%Pw_min<=Pw<=Pw_max
%max{v,0}<=u

C=[];
d=[];

%P_wind<=P_wind_max
% C=[C;sparse(diag(ones(R_wan_len,1)))];
% d=[d;P_Wind_Max];

%-P_wind<=-P_wind_min
% C=[C;sparse(diag(-1*ones(R_wan_len,1)))];
% d=[d;-1*P_Wind_Min];

% P_wind>=P_Wind_Min
C=[C;-1*U(:,R_wan)*power(S(R_wan,R_wan),0.5)];
d=[d;miu_average-P_Wind_Min];

% P_wind<=P_Wind_Max
C=[C;U(:,R_wan)*power(S(R_wan,R_wan),0.5)];
d=[d;P_Wind_Max-miu_average];

%%

DRO_total_var_num=0;
Y0_num=0;
YP_num=0;

x_location=1:x_num;
DRO_total_var_num=DRO_total_var_num+length(x_location);

zit_location=DRO_total_var_num+1:DRO_total_var_num+Zit_num;
DRO_total_var_num=DRO_total_var_num+length(zit_location);

Y0_PG=DRO_total_var_num+1:DRO_total_var_num+PGit_num;
DRO_total_var_num=DRO_total_var_num+length(Y0_PG);
PG_in_Y0=Y0_num+1:Y0_num+length(Y0_PG);
Y0_num=length(Y0_PG)+Y0_num;

Y0_Seita=DRO_total_var_num+1:DRO_total_var_num+Seitait_num;
DRO_total_var_num=DRO_total_var_num+length(Y0_Seita);
Seita_in_Y0=Y0_num+1:Y0_num+length(Y0_Seita);
Y0_num=length(Y0_Seita)+Y0_num;

if(param.windLoss==1)
    Y0_windLoss=DRO_total_var_num+1:DRO_total_var_num+windLoss_num;
    DRO_total_var_num=DRO_total_var_num+length(Y0_windLoss);
    windLoss_in_Y0=Y0_num+1:Y0_num+length(Y0_windLoss);
    Y0_num=length(Y0_windLoss)+Y0_num;
end

if(param.LDR==0)
    YP_PG=DRO_total_var_num+1:...
        DRO_total_var_num+N*T_wan*R*(0.5-0.5*T_wan+T);
    DRO_total_var_num=DRO_total_var_num+length(YP_PG);
    PG_in_YP=YP_num+1:YP_num+length(YP_PG);
    YP_num=YP_num+N*T_wan*R*(0.5-0.5*T_wan+T);
    
    YP_Seita=DRO_total_var_num+1:...
        DRO_total_var_num+NodeNum*T_wan*R*(0.5-0.5*T_wan+T);
    DRO_total_var_num=DRO_total_var_num+length(YP_Seita);
    Seita_in_YP=YP_num+1:YP_num+length(YP_Seita);
    YP_num=YP_num+NodeNum*T_wan*R*(0.5-0.5*T_wan+T);
    
    
    if(param.windLoss==1)
        YP_windLoss=DRO_total_var_num+1:...
            DRO_total_var_num+R*T_wan*R*(0.5-0.5*T_wan+T);
        DRO_total_var_num=DRO_total_var_num+length(YP_windLoss);
        windLoss_in_YP=YP_num+1:YP_num+length(YP_windLoss);
        YP_num=YP_num+length(YP_windLoss);
    end

else
    YP_PG=DRO_total_var_num+1:...
        DRO_total_var_num+PGit_num*R_wan_len;
    DRO_total_var_num=DRO_total_var_num+length(YP_PG);
    PG_in_YP=YP_num+1:YP_num+length(YP_PG);
    YP_num=YP_num+length(YP_PG);
    
    YP_Seita=DRO_total_var_num+1:...
        DRO_total_var_num+Seitait_num*R_wan_len;
    DRO_total_var_num=DRO_total_var_num+length(YP_Seita);
    Seita_in_YP=YP_num+1:YP_num+length(YP_Seita);
    YP_num=YP_num+length(YP_Seita);
    
    
    if(param.windLoss==1)
        YP_windLoss=DRO_total_var_num+1:...
            DRO_total_var_num+windLoss_num*R_wan_len;
        DRO_total_var_num=DRO_total_var_num+length(YP_windLoss);
        windLoss_in_YP=YP_num+1:YP_num+length(YP_windLoss);
        YP_num=YP_num+length(YP_windLoss);
    end
 
end
if(param.windLoss==1)
    Y0_location=[Y0_PG,Y0_Seita,Y0_windLoss];
    YP_location=[YP_PG,YP_Seita,YP_windLoss];
else
    Y0_location=[Y0_PG,Y0_Seita];
    YP_location=[YP_PG,YP_Seita];
end

   wl_location=DRO_total_var_num+1:...
            DRO_total_var_num+1;
        DRO_total_var_num=DRO_total_var_num+length(wl_location);
        
pai_1_location=DRO_total_var_num+1:DRO_total_var_num+size(C,1)*(size(Aineq_cost_windLoss,1));
DRO_total_var_num=DRO_total_var_num+length(pai_1_location);

pai_2_location_upper=DRO_total_var_num+1:...
    DRO_total_var_num+size(C,1)*(size(Aineq_genration_limit_upper,1));
DRO_total_var_num=DRO_total_var_num+length(pai_2_location_upper);

pai_2_location_lower=DRO_total_var_num+1:...
    DRO_total_var_num+size(C,1)*(size(Aineq_genration_limit_lower,1));
DRO_total_var_num=DRO_total_var_num+length(pai_2_location_lower);

pai_3_location=DRO_total_var_num+1:DRO_total_var_num+size(C,1)*size(Aineq_linear_approximation,1);
DRO_total_var_num=DRO_total_var_num+length(pai_3_location);

if(~isempty(Aineq_Aeq_DCPowerFlow))
    pai_4_location=DRO_total_var_num+1:...
        DRO_total_var_num+size(C,1)*(size(Aineq_Aeq_DCPowerFlow,1));
    DRO_total_var_num=DRO_total_var_num+length(pai_4_location);
else
    pai_4_location=[];
end

pai_5_location_upper=DRO_total_var_num+1:...
    DRO_total_var_num+size(C,1)*(size(Aineq_ramp_limt_up,1));
DRO_total_var_num=DRO_total_var_num+length(pai_5_location_upper);

pai_5_location_down=DRO_total_var_num+1:...
    DRO_total_var_num+size(C,1)*(size(Aineq_ramp_limt_down,1));
DRO_total_var_num=DRO_total_var_num+length(pai_5_location_down);

pai_5_location=[pai_5_location_upper,pai_5_location_down];

if(param.windLoss==1)
    pai_6_location=DRO_total_var_num+1:...
        DRO_total_var_num+size(C,1)*(size(Aineq_windLoss_constraint,1));
    DRO_total_var_num=DRO_total_var_num+length(pai_6_location);
end

total_var_num=DRO_total_var_num;

%% linear decision rule
PW2Pwan_coeficent=(U*diag(power(diag(S),-0.5)))';
PW2Pwan_coeficent=PW2Pwan_coeficent(R_wan,:);

Pwan2PW_coeficent=U*power(S,0.5);
Pwan2PW_coeficent=Pwan2PW_coeficent(:,R_wan);

Y0_part=sparse(diag(ones(y_num-PWrt_num-Zit_num,1)));
if(param.LDR==0)
    YP_part=[];
    for t=1:T
        if(t<=T_wan)
            YP_part=sparse(blkdiag(YP_part,ones(1,t*R)));
        else
            YP_part=sparse(blkdiag(YP_part,ones(1,T_wan*R)));
        end
    end
    YP_part_PG=[];
    for i=1:N
        YP_part_PG=sparse(blkdiag(YP_part_PG,YP_part));
    end
    YP_part_Seita=[];
    for i=1:NodeNum
        YP_part_Seita=sparse(blkdiag(YP_part_Seita,YP_part));
    end    
    if(param.windLoss==1)
        YP_part_windLoss=[];
        for i=1:R
            YP_part_windLoss=sparse(blkdiag(YP_part_windLoss,YP_part));
        end
    end
    
    YP_part=sparse(y_num-PWrt_num-Zit_num,YP_num);
    YP_part(PGit_location-x_num,YP_PG-x_num-Y0_num-length(zit_location))=YP_part_PG;
    YP_part(Seitait_location-x_num,YP_Seita-x_num-Y0_num-length(zit_location))=YP_part_Seita;
    if(param.windLoss==1)
        YP_part(windLoss_location-x_num-PWrt_num,YP_windLoss-x_num-Y0_num-length(zit_location))=YP_part_windLoss;
    end
    
    
    %model variable   
    model_coeficent_YP=[];
    part_YP=sparse(R*T,length(YP_PG)/N);
    for i=1:T
      
        if(i>T_wan)
            part_YP((i-T_wan)*R+1:i*R,...
                T_wan*R+(T_wan-1)*T_wan*R/2+(i-1-T_wan)*T_wan*R+1:...
                T_wan*R+(T_wan-1)*T_wan*R/2+(i-T_wan)*T_wan*R)=diag(ones(R*T_wan,1));
            
        else
            part_YP(1:i*R,(i-1)*R+(i-1)*(i-2)*R/2+1:i*R+(i-1)*i*R/2)=diag(ones(R*i,1));
        end
    end
    
    
    %PG
    for i=1:N
        model_coeficent_YP=[model_coeficent_YP,part_YP];
    end
    %seita
    for i=1:NodeNum
        model_coeficent_YP=[model_coeficent_YP,part_YP];
    end
    if(param.windLoss==1)
        for i=1:R
            model_coeficent_YP=[model_coeficent_YP,part_YP];
        end
    end
    
else
    YP_part=[];
    for t=1:T
        YP_part=sparse(blkdiag(YP_part,ones(1,R_wan_len)));
    end
    YP_part_PG=[];
    for i=1:N
        YP_part_PG=sparse(blkdiag(YP_part_PG,YP_part));
    end
    YP_part_Seita=[];
    for i=1:NodeNum
        YP_part_Seita=sparse(blkdiag(YP_part_Seita,YP_part));
    end    
    if(param.windLoss==1)
        YP_part_windLoss=[];
        for i=1:R
            YP_part_windLoss=sparse(blkdiag(YP_part_windLoss,YP_part));
        end
    end
    
    YP_part=sparse(y_num-PWrt_num-Zit_num,YP_num);
    YP_part(PGit_location-x_num,YP_PG-x_num-Y0_num-length(zit_location))=YP_part_PG;
    YP_part(Seitait_location-x_num,YP_Seita-x_num-Y0_num-length(zit_location))=YP_part_Seita;
    if(param.windLoss==1)
        YP_part(windLoss_location-x_num-PWrt_num-Zit_num,YP_windLoss-x_num-Y0_num-length(zit_location))=YP_part_windLoss;
    end
    
  
    %model variable
    
    model_coeficent_YP=[];
    part_YP=sparse(R_wan_len,length(YP_PG)/N);
    for i=1:T
         part_YP(1:R_wan_len,(i-1)*R_wan_len+1:i*R_wan_len)=diag(ones(R_wan_len,1));
    end
    
    windLoss_part=[];
    %PG
    for i=1:N
        model_coeficent_YP=[model_coeficent_YP,part_YP];
    end
    %seita
    for i=1:NodeNum
        model_coeficent_YP=[model_coeficent_YP,part_YP];
    end
    if(param.windLoss==1)
        for i=1:R
            model_coeficent_YP=[model_coeficent_YP,part_YP];
            windLoss_part=[windLoss_part,part_YP];
        end
    end
end
%%

%
f=sparse(1,total_var_num);
f(1,sit_location)=reshape(repmat(ThHot_cost_start,1,T)',N*T,1);
f(1,Sit_location)=1;
f(1,zit_location)=1;
f(1,wl_location)=1;

%% WindLoss


% YP_Aeq_windLoss=sparse(size(C,2),length(YP_windLoss));
% 
% constraint_pai_1=sparse(1,total_var_num);
% constraint_pai_1(:,Y0_windLoss)=UC_model.f(windLoss_location(1),1);
% constraint_pai_1(:,wl_location)=-1;
% constraint_pai_1(:,pai_1_location)=d';
% 
% bineq_constraint_pai_1=0;
% 
% Aineq_constraint_pai_1=[Aineq_constraint_pai_1;constraint_pai_1];
% 
% Aeq_constraint_pai_1=sparse(size(C,2),total_var_num);
% Aeq_constraint_pai_1(1:size(C,2),YP_windLoss)=windLoss_part;
% Aeq_constraint_pai_1(:,pai_1_location)=C';
% beq_constraint_pai_1=sparse(size(C,2),1);


Aineq_constraint_pai_1=[];
bineq_constraint_pai_1=[];

Aeq_constraint_pai_1=[];
beq_constraint_pai_1=[];

part_pai_1_d=[];
part_pai_1_C=[];
YP_Aeq_windLoss=sparse(size(C,2)*size(Aineq_cost_windLoss,1),length(YP_windLoss));
for i=1:size(Aineq_cost_windLoss,1)
    part_pai_1_d=blkdiag(part_pai_1_d,d');
    part_pai_1_C=blkdiag(part_pai_1_C,C');
    
    windLoss_part_location=find(Aineq_cost_windLoss(i,windLoss_location)~=0);
    
    for k=1:length(windLoss_part_location)
        [YP_windLoss_part_location_row,YP_windLoss_part_location_col]=find(YP_part(windLoss_in_Y0(windLoss_part_location(k)),:)~=0);
        YP_Aeq_windLoss((i-1)*size(C,2)+1:i*size(C,2),YP_windLoss_part_location_col-length(YP_PG)-length(YP_Seita))=-1*Aineq_cost_windLoss(i,windLoss_location(windLoss_part_location(k)))*model_coeficent_YP(:,YP_windLoss_part_location_col);
        
    end
  
end

constraint_pai_1=sparse(size(Aineq_cost_windLoss,1),total_var_num);
constraint_pai_1(:,wl_location)=Aineq_cost_windLoss(:,Wl_location);
constraint_pai_1(:,Y0_windLoss)=Aineq_cost_windLoss(:,windLoss_location);
constraint_pai_1(:,pai_1_location)=part_pai_1_d;
Aineq_constraint_pai_1=[Aineq_constraint_pai_1;constraint_pai_1];
bineq_constraint_pai_1=[bineq_constraint_pai_1;0];

%eq
constraint_pai_1=sparse((size(C,2))*size(Aineq_cost_windLoss,1),total_var_num);
constraint_pai_1(1:size(C,2)*size(Aineq_cost_windLoss,1),YP_windLoss)=YP_Aeq_windLoss;
constraint_pai_1(1:size(C,2)*size(Aineq_cost_windLoss,1),pai_1_location)=part_pai_1_C;

Aeq_constraint_pai_1=[Aeq_constraint_pai_1;constraint_pai_1];
beq_constraint_pai_1=[beq_constraint_pai_1;sparse((size(C,2))*size(Aineq_cost_windLoss,1),1)];



%% Aineq_genration_limit
Aineq_constraint_pai_2=[];
bineq_constraint_pai_2=[];

Aeq_constraint_pai_2=[];
beq_constraint_pai_2=[];

part_pai_2_d=[];
part_pai_2_C=[];
YP_Aeq_PG=sparse(size(C,2)*size(Aineq_genration_limit_upper,1),length(YP_PG));
for i=1:size(Aineq_genration_limit_upper,1)
    part_pai_2_d=blkdiag(part_pai_2_d,d');
    part_pai_2_C=blkdiag(part_pai_2_C,C');
    
    PG_part_location=find(Aineq_genration_limit_upper(i,PGit_location)~=0);
    
    YP_PG_part_location=find(YP_part(PG_part_location,:)~=0);
    YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location)=-1*Aineq_genration_limit_upper(i,PGit_location(PG_part_location))*model_coeficent_YP(:,YP_PG_part_location);
end

constraint_pai_2=sparse(size(Aineq_genration_limit_upper,1),total_var_num);
constraint_pai_2(:,x_location)=Aineq_genration_limit_upper(:,x_location);
constraint_pai_2(:,Y0_PG)=Aineq_genration_limit_upper(:,PGit_location);
constraint_pai_2(:,pai_2_location_upper)=part_pai_2_d;
Aineq_constraint_pai_2=[Aineq_constraint_pai_2;constraint_pai_2];
bineq_constraint_pai_2=[bineq_constraint_pai_2;bineq_genration_limit_upper];

%eq
constraint_pai_2=sparse((size(C,2))*size(Aineq_genration_limit_upper,1),total_var_num);
constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_upper,1),YP_PG)=YP_Aeq_PG;
constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_upper,1),pai_2_location_upper)=part_pai_2_C;

Aeq_constraint_pai_2=[Aeq_constraint_pai_2;constraint_pai_2];
beq_constraint_pai_2=[beq_constraint_pai_2;sparse((size(C,2))*size(Aineq_genration_limit_upper,1),1)];

%Aineq_genration_limit_lower
part_pai_2_d=[];
part_pai_2_C=[];
YP_Aeq_PG=sparse(size(C,2)*size(Aineq_genration_limit_lower,1),length(YP_PG));
for i=1:size(Aineq_genration_limit_lower,1)
    part_pai_2_d=blkdiag(part_pai_2_d,d');
    part_pai_2_C=blkdiag(part_pai_2_C,C');
    
    PG_part_location=find(Aineq_genration_limit_lower(i,PGit_location)~=0);
    
    YP_PG_part_location=find(YP_part(PG_part_location,:)~=0);
    YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location)=-1*Aineq_genration_limit_lower(i,PGit_location(PG_part_location))*model_coeficent_YP(:,YP_PG_part_location);
    
   
end

constraint_pai_2=sparse(size(Aineq_genration_limit_lower,1),total_var_num);
constraint_pai_2(:,x_location)=Aineq_genration_limit_lower(:,x_location);
constraint_pai_2(:,Y0_PG)=Aineq_genration_limit_lower(:,PGit_location);
constraint_pai_2(:,pai_2_location_lower)=part_pai_2_d;

Aineq_constraint_pai_2=[Aineq_constraint_pai_2;constraint_pai_2];
bineq_constraint_pai_2=[bineq_constraint_pai_2;bineq_genration_limit_lower];

%eq
constraint_pai_2=sparse((size(C,2))*size(Aineq_genration_limit_lower,1),total_var_num);
constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_lower,1),YP_PG)=YP_Aeq_PG;
constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_lower,1),pai_2_location_lower)=part_pai_2_C;

Aeq_constraint_pai_2=[Aeq_constraint_pai_2;constraint_pai_2];
beq_constraint_pai_2=[beq_constraint_pai_2;sparse((size(C,2))*size(Aineq_genration_limit_lower,1),1)];


%% Aineq_linear_approximation
Aineq_constraint_pai_3=[];
bineq_constraint_pai_3=[];
Aeq_constraint_pai_3=[];
beq_constraint_pai_3=[];

part_pai_3_d=[];
part_pai_3_C=[];

YP_Aeq_PG=sparse(size(C,2)*size(Aineq_linear_approximation,1),length(YP_PG));


for i=1:size(Aineq_linear_approximation,1)
    part_pai_3_d=sparse(blkdiag(part_pai_3_d,d'));
    part_pai_3_C=sparse(blkdiag(part_pai_3_C,C'));
    
    PG_part_location=find(Aineq_linear_approximation(i,PGit_location)~=0);
    
    YP_PG_part_location=find(YP_part(PG_part_location,:)~=0);
    
    YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location)=-1*Aineq_linear_approximation(i,PGit_location(PG_part_location))*model_coeficent_YP(:,YP_PG_part_location);

end

if(param.windLoss==1)
    part_YP_windLoss=-1*UC_model.f(windLoss_location(1),1)*part_YP;
    YP_windLoss_part=[];
    for i=1:R
        YP_windLoss_part=[YP_windLoss_part,part_YP_windLoss];
    end
end


constraint_pai_3=sparse(size(Aineq_linear_approximation,1),total_var_num);
constraint_pai_3(:,x_location)=Aineq_linear_approximation(:,x_location);
constraint_pai_3(:,Y0_PG)=Aineq_linear_approximation(:,PGit_location);
constraint_pai_3(:,zit_location)=Aineq_linear_approximation(:,Zit_location);
constraint_pai_3(:,pai_3_location)=part_pai_3_d;


Aineq_constraint_pai_3=[Aineq_constraint_pai_3;constraint_pai_3];
bineq_constraint_pai_3=[bineq_constraint_pai_3;bineq_linear_approximation];

%eq

constraint_pai_3=sparse((size(C,2))*size(Aineq_linear_approximation,1),total_var_num);
constraint_pai_3(1:size(C,2)*size(Aineq_linear_approximation,1),YP_PG)=YP_Aeq_PG;
constraint_pai_3(1:size(C,2)*size(Aineq_linear_approximation,1),pai_3_location)=part_pai_3_C;

Aeq_constraint_pai_3=[Aeq_constraint_pai_3;constraint_pai_3];
beq_constraint_pai_3=[beq_constraint_pai_3;sparse((size(C,2))*size(Aineq_linear_approximation,1),1)];

%% DC flow

Aineq_constraint_pai_4=[];
bineq_constraint_pai_4=[];

Aeq_constraint_pai_4=[];
beq_constraint_pai_4=[];

part_pai_4_d=[];
part_pai_4_C=[];

YP_Aeq_PG=sparse(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YP_PG));
YP_Aeq_Seita=sparse(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YP_Seita));
if(param.windLoss==1)
    YP_Aeq_windLoss=sparse(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YP_windLoss));
end

bineq_constraint_pai_4_part=sparse(size(Aineq_Aeq_DCPowerFlow,1),1);
for i=1:size(Aineq_Aeq_DCPowerFlow,1)
    beq_constraint_pai_4_part=sparse(size(C,2),1);
    part_pai_4_d=sparse(blkdiag(part_pai_4_d,d'));
    part_pai_4_C=sparse(blkdiag(part_pai_4_C,C'));
    
    PG_part_location=find(Aineq_Aeq_DCPowerFlow(i,PGit_location)~=0);
    Seita_part_location=find(Aineq_Aeq_DCPowerFlow(i,Seitait_location)~=0);
    PWrt_part_location=find(Aineq_Aeq_DCPowerFlow(i,PWrt_location)~=0);
    if(param.windLoss==1)
        windLoss_part_location=find(Aineq_Aeq_DCPowerFlow(i,windLoss_location)~=0);
    end
    
    for k=1:length(PG_part_location)
        [YP_PG_part_location_row,YP_PG_part_location_col]=find(YP_part(PG_part_location(k),:)~=0);
        YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location_col)=-1*Aineq_Aeq_DCPowerFlow(i,PGit_location(PG_part_location(k)))*model_coeficent_YP(:,YP_PG_part_location_col);
        
   
    end
    for k=1:length(Seita_part_location)
        [YP_Seita_part_location_row,YP_Seita_part_location_col]=find(YP_part(Seita_in_Y0(Seita_part_location(k)),:)~=0);
        YP_Aeq_Seita((i-1)*size(C,2)+1:i*size(C,2),YP_Seita_part_location_col-length(YP_PG))=-1*Aineq_Aeq_DCPowerFlow(i,Seitait_location(Seita_part_location(k)))*model_coeficent_YP(:,YP_Seita_part_location_col);

    end
    
    if(~isempty(PWrt_part_location))
        for r=1:length(PWrt_part_location)
            beq_constraint_pai_4_part=beq_constraint_pai_4_part+Aineq_Aeq_DCPowerFlow(i,PWrt_location(PWrt_part_location(r)))*Pwan2PW_coeficent(PWrt_part_location(r),:)';
            bineq_constraint_pai_4_part(i,1)=bineq_constraint_pai_4_part(i,1)+...
                    -1*Aineq_Aeq_DCPowerFlow(i,PWrt_location(PWrt_part_location(r)))*miu_average(PWrt_part_location(r));
        end
    end
    
    if(param.windLoss==1)
        for k=1:length(windLoss_part_location)
            [YP_windLoss_part_location_row,YP_windLoss_part_location_col]=find(YP_part(windLoss_in_Y0(windLoss_part_location(k)),:)~=0);
            YP_Aeq_windLoss((i-1)*size(C,2)+1:i*size(C,2),YP_windLoss_part_location_col-length(YP_PG)-length(YP_Seita))=-1*Aineq_Aeq_DCPowerFlow(i,windLoss_location(windLoss_part_location(k)))*model_coeficent_YP(:,YP_windLoss_part_location_col);

        end
    end
    beq_constraint_pai_4=[beq_constraint_pai_4;beq_constraint_pai_4_part];
end

constraint_pai_4=sparse(size(Aineq_Aeq_DCPowerFlow,1),total_var_num);
constraint_pai_4(:,x_location)=Aineq_Aeq_DCPowerFlow(:,x_location);
constraint_pai_4(:,Y0_PG)=Aineq_Aeq_DCPowerFlow(:,PGit_location);
constraint_pai_4(:,Y0_Seita)=Aineq_Aeq_DCPowerFlow(:,Seitait_location);
constraint_pai_4(:,pai_4_location)=part_pai_4_d;
if(param.windLoss==1)
    constraint_pai_4(:,Y0_windLoss)=Aineq_Aeq_DCPowerFlow(:,windLoss_location);
end

Aineq_constraint_pai_4=[Aineq_constraint_pai_4;constraint_pai_4];
bineq_constraint_pai_4=[bineq_constraint_pai_4;bineq_Aeq_DCPowerFlow+bineq_constraint_pai_4_part];


constraint_pai_4=sparse((size(C,2))*size(Aineq_Aeq_DCPowerFlow,1),total_var_num);
constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),YP_PG)=YP_Aeq_PG;
constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),YP_Seita)=YP_Aeq_Seita;
constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),pai_4_location)=part_pai_4_C;
if(param.windLoss==1)
    constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),YP_windLoss)=YP_Aeq_windLoss;
end

Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];

Aineq_constraint_pai_4_1=[];
bineq_constraint_pai_4_1=[];

Aeq_constraint_pai_4_1=[];
beq_constraint_pai_4_1=[];
if(param.eq==1)
    Aineq_Aeq_DCPowerFlow=UC_model.Aeq_DCPowerFlow;
    bineq_Aeq_DCPowerFlow=UC_model.beq_DCPowerFlow;
    
    YP_Aeq_PG=sparse(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YP_PG));
    YP_Aeq_Seita=sparse(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YP_Seita));
    if(param.windLoss==1)
        YP_Aeq_windLoss=sparse(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YP_windLoss));
    end
    
    bineq_constraint_pai_4_part=sparse(size(Aineq_Aeq_DCPowerFlow,1),1);
    for i=1:size(Aineq_Aeq_DCPowerFlow,1)
        
        beq_constraint_pai_4_part=sparse(size(C,2),1);
        part_pai_4_d=sparse(blkdiag(part_pai_4_d,d'));
        part_pai_4_C=sparse(blkdiag(part_pai_4_C,C'));
        
        PG_part_location=find(Aineq_Aeq_DCPowerFlow(i,PGit_location)~=0);
        Seita_part_location=find(Aineq_Aeq_DCPowerFlow(i,Seitait_location)~=0);
        PWrt_part_location=find(Aineq_Aeq_DCPowerFlow(i,PWrt_location)~=0);
        if(param.windLoss==1)
            windLoss_part_location=find(Aineq_Aeq_DCPowerFlow(i,windLoss_location)~=0);
        end
        
        for k=1:length(PG_part_location)
            
            [YP_PG_part_location_row,YP_PG_part_location_col]=find(YP_part(PG_part_location(k),:)~=0);
            YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location_col)=-1*Aineq_Aeq_DCPowerFlow(i,PGit_location(PG_part_location(k)))*model_coeficent_YP(:,YP_PG_part_location_col);
            
        end
        for k=1:length(Seita_part_location)
            [YP_Seita_part_location_row,YP_Seita_part_location_col]=find(YP_part(Seita_in_Y0(Seita_part_location(k)),:)~=0);
            YP_Aeq_Seita((i-1)*size(C,2)+1:i*size(C,2),YP_Seita_part_location_col-length(YP_PG))=-1*Aineq_Aeq_DCPowerFlow(i,Seitait_location(Seita_part_location(k)))*model_coeficent_YP(:,YP_Seita_part_location_col);
            
        end
        
        if(~isempty(PWrt_part_location))
            for r=1:length(PWrt_part_location)
                beq_constraint_pai_4_part=beq_constraint_pai_4_part+Aineq_Aeq_DCPowerFlow(i,PWrt_location(PWrt_part_location(r)))*Pwan2PW_coeficent(PWrt_part_location(r),:)';
                bineq_constraint_pai_4_part(i,1)=bineq_constraint_pai_4_part(i,1)+...
                    -1*Aineq_Aeq_DCPowerFlow(i,PWrt_location(PWrt_part_location(r)))*miu_average(PWrt_part_location(r));
            end
        end
        
        if(param.windLoss==1)
            for k=1:length(windLoss_part_location)
                [YP_windLoss_part_location_row,YP_windLoss_part_location_col]=find(YP_part(windLoss_in_Y0(windLoss_part_location(k)),:)~=0);
                YP_Aeq_windLoss((i-1)*size(C,2)+1:i*size(C,2),YP_windLoss_part_location_col-length(YP_PG)-length(YP_Seita))=-1*Aineq_Aeq_DCPowerFlow(i,windLoss_location(windLoss_part_location(k)))*model_coeficent_YP(:,YP_windLoss_part_location_col);
                 
            end
        end
        beq_constraint_pai_4=[beq_constraint_pai_4;beq_constraint_pai_4_part];
    end
    
    constraint_pai_4=sparse(size(Aineq_Aeq_DCPowerFlow,1),total_var_num);
    constraint_pai_4(:,x_location)=Aineq_Aeq_DCPowerFlow(:,x_location);
    constraint_pai_4(:,Y0_PG)=Aineq_Aeq_DCPowerFlow(:,PGit_location);
    constraint_pai_4(:,Y0_Seita)=Aineq_Aeq_DCPowerFlow(:,Seitait_location);
    if(param.windLoss==1)
        constraint_pai_4(:,Y0_windLoss)=Aineq_Aeq_DCPowerFlow(:,windLoss_location);
    end
    
    Aineq_constraint_pai_4=[Aineq_constraint_pai_4;constraint_pai_4];
    bineq_constraint_pai_4=[bineq_constraint_pai_4;bineq_Aeq_DCPowerFlow+bineq_constraint_pai_4_part];
    
    constraint_pai_4=sparse((size(C,2))*size(Aineq_Aeq_DCPowerFlow,1),total_var_num);
    constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),YP_PG)=YP_Aeq_PG;
    constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),YP_Seita)=YP_Aeq_Seita;

    if(param.windLoss==1)
        constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),YP_windLoss)=YP_Aeq_windLoss;
    end
    
    Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];
end


%% Aineq_ramp_limt
Aineq_constraint_pai_5=[];
bineq_constraint_pai_5=[];

Aeq_constraint_pai_5=[];
beq_constraint_pai_5=[];

part_pai_5_d=[];
part_pai_5_C=[];

YP_Aeq_PG=sparse(size(C,2)*size(Aineq_ramp_limt,1),length(YP_PG));

for i=1:size(Aineq_ramp_limt,1)
    part_pai_5_d=sparse(blkdiag(part_pai_5_d,d'));
    part_pai_5_C=sparse(blkdiag(part_pai_5_C,C'));
    
    PG_part_location=find(Aineq_ramp_limt(i,PGit_location)~=0);
    
    
    for k=1:length(PG_part_location)
        [YP_PG_part_location_row,YP_PG_part_location_col]=find(YP_part(PG_part_location(k),:)~=0);
        YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location_col)=-1*Aineq_ramp_limt(i,PGit_location(PG_part_location(k)))*model_coeficent_YP(:,YP_PG_part_location_col);
        
    
    end
    
end

constraint_pai_5=sparse(size(Aineq_ramp_limt,1),total_var_num);
constraint_pai_5(:,x_location)=Aineq_ramp_limt(:,x_location);
constraint_pai_5(:,Y0_PG)=Aineq_ramp_limt(:,PGit_location);
constraint_pai_5(:,pai_5_location)=part_pai_5_d;

Aineq_constraint_pai_5=[Aineq_constraint_pai_5;constraint_pai_5];
bineq_constraint_pai_5=[bineq_constraint_pai_5;bineq_ramp_limt];


constraint_pai_5=sparse((size(C,2))*size(Aineq_ramp_limt,1),total_var_num);
constraint_pai_5(1:size(C,2)*size(Aineq_ramp_limt,1),YP_PG)=YP_Aeq_PG;
constraint_pai_5(1:size(C,2)*size(Aineq_ramp_limt,1),pai_5_location)=part_pai_5_C;

Aeq_constraint_pai_5=[Aeq_constraint_pai_5;constraint_pai_5];
beq_constraint_pai_5=[beq_constraint_pai_5;sparse((size(C,2))*size(Aineq_ramp_limt,1),1)];
%% windLoss
Aineq_constraint_pai_6=[];
bineq_constraint_pai_6=[];

Aeq_constraint_pai_6=[];
beq_constraint_pai_6=[];
if(param.windLoss==1)
    part_pai_6_d=[];
    part_pai_6_C=[];
    
    YP_Aeq_windLoss=sparse(size(C,2)*size(Aineq_windLoss_constraint,1),length(YP_windLoss));
    bineq_constraint_pai_6_part=sparse(size(Aineq_windLoss_constraint,1),1);
    for i=1:size(Aineq_windLoss_constraint,1)
        beq_constraint_pai_6_part=sparse(size(C,2),1);
        part_pai_6_d=sparse(blkdiag(part_pai_6_d,d'));
        part_pai_6_C=sparse(blkdiag(part_pai_6_C,C'));
        
        windLoss_part_location=find(Aineq_windLoss_constraint(i,windLoss_location)~=0);
        
        PWrt_part_location=find(Aineq_windLoss_constraint(i,PWrt_location)~=0);
        
        for k=1:length(windLoss_part_location)
            [YP_windLoss_part_location_row,YP_windLoss_part_location_col]=find(YP_part(windLoss_in_Y0(windLoss_part_location(k)),:)~=0);
            YP_Aeq_windLoss((i-1)*size(C,2)+1:i*size(C,2),YP_windLoss_part_location_col-length(YP_PG)-length(YP_Seita))=-1*Aineq_windLoss_constraint(i,windLoss_location(windLoss_part_location(k)))*model_coeficent_YP(:,YP_windLoss_part_location_col);
            
        end
        
        if(~isempty(PWrt_part_location))
            for r=1:length(PWrt_part_location)
                beq_constraint_pai_6_part=beq_constraint_pai_6_part+Aineq_windLoss_constraint(i,PWrt_location(PWrt_part_location(r)))*Pwan2PW_coeficent(PWrt_part_location(r),:)';
            
                bineq_constraint_pai_6_part(i,1)=bineq_constraint_pai_6_part(i,1)+...
                    -1*Aineq_windLoss_constraint(i,PWrt_location(PWrt_part_location(r)))*miu_average(PWrt_part_location(r));
            end
        end
        beq_constraint_pai_6=[beq_constraint_pai_6;beq_constraint_pai_6_part];
    end
    
    constraint_pai_6=sparse(size(Aineq_windLoss_constraint,1),total_var_num);
    constraint_pai_6(:,Y0_windLoss)=Aineq_windLoss_constraint(:,windLoss_location);
    constraint_pai_6(:,pai_6_location)=part_pai_6_d;
    
    Aineq_constraint_pai_6=[Aineq_constraint_pai_6;constraint_pai_6];
    bineq_constraint_pai_6=[bineq_constraint_pai_6;bineq_windLoss_constraint+bineq_constraint_pai_6_part];
    
    constraint_pai_6=sparse((size(C,2))*size(Aineq_windLoss_constraint,1),total_var_num);
    constraint_pai_6(1:size(C,2)*size(Aineq_windLoss_constraint,1),YP_windLoss)=YP_Aeq_windLoss;
    constraint_pai_6(1:size(C,2)*size(Aineq_windLoss_constraint,1),pai_6_location)=part_pai_6_C;
    
    Aeq_constraint_pai_6=[Aeq_constraint_pai_6;constraint_pai_6];
end
%% DRO model
Aineq_two_bin_var_constraint=[Aineq_constraint_min_upordown_time;Aineq_constraint_start_cost];
bineq_two_bin_var_constraint=[bineq_constraint_min_upordown_time;bineq_constraint_start_cost];

Aeq_two_bin_var_constraint=[Aeq_constraints_state;Aeq_constraints_initial_statues];
beq_two_bin_var_constraint=[beq_constraints_state;beq_constraints_initial_statues];

Aineq_two_bin_var=sparse(size(Aineq_two_bin_var_constraint,1),total_var_num);
Aineq_two_bin_var(:,x_location)=Aineq_two_bin_var_constraint(:,x_location);

Aeq_two_bin_var=sparse(size(Aeq_two_bin_var_constraint,1),total_var_num);
Aeq_two_bin_var(:,x_location)=Aeq_two_bin_var_constraint(:,x_location);

Aineq=[Aineq_two_bin_var;Aineq_constraint_pai_1;Aineq_constraint_pai_2;Aineq_constraint_pai_3;Aineq_constraint_pai_4;Aineq_constraint_pai_5;Aineq_constraint_pai_6];%
bineq=[bineq_two_bin_var_constraint;bineq_constraint_pai_1;bineq_constraint_pai_2;bineq_constraint_pai_3;bineq_constraint_pai_4;bineq_constraint_pai_5;bineq_constraint_pai_6];%
Aeq=[Aeq_two_bin_var;Aeq_constraint_pai_1;Aeq_constraint_pai_2;Aeq_constraint_pai_3;Aeq_constraint_pai_4;Aeq_constraint_pai_5;Aineq_constraint_pai_4_1;Aeq_constraint_pai_4_1;Aeq_constraint_pai_6];%
beq=[beq_two_bin_var_constraint;beq_constraint_pai_1;beq_constraint_pai_2;beq_constraint_pai_3;beq_constraint_pai_4;beq_constraint_pai_5;bineq_constraint_pai_4_1;beq_constraint_pai_4_1;beq_constraint_pai_6];%


lb=sparse(total_var_num,1);
lb(Y0_PG,1)=-inf;
lb(Y0_Seita,1)=-inf;
lb(YP_PG,1)=-inf;
lb(YP_Seita,1)=-inf;
if(param.windLoss==1)
    lb(Y0_windLoss,1)=-inf;
    lb(YP_windLoss,1)=-inf;
end


ub=inf*ones(total_var_num,1);
ub(uit_location,1)=1;
ub(sit_location,1)=1;
ub(dit_location,1)=1;

ctype='';
ctype(1:total_var_num)='C';
ctype(uit_location)='B';
ctype(sit_location)='B';
ctype(dit_location)='B';


%%


model.Q=[];
model.f=f;
model.Aeq=Aeq;
model.beq=beq;
model.Aineq=Aineq;
model.bineq=bineq;
model.lb=lb;
model.ub=ub;
model.ctype=ctype;

model.PG_in_Y0=PG_in_Y0;
model.PG_in_YP=PG_in_YP;



if(param.windLoss==1)
    model.windLoss_in_Y0=windLoss_in_Y0;
    model.windLoss_in_YP=windLoss_in_YP;
else
    model.windLoss_in_Y0=[];
    model.windLoss_in_YP=[];
end

model.Y0_part=Y0_part;
model.YP_part=YP_part;

model.Y0_location=Y0_location;
model.YP_location=YP_location;

model.data_wind_origin=data_wind;
model.Ckl_origin=Ckl;

model.Y0_location_without_PCA=Y0_location;
model.YP_location_without_PCA=YP_location;

model.PG_in_Y0_without_PCA=PG_in_Y0;
model.PG_in_YP_without_PCA=PG_in_YP;

if(param.windLoss==1)
    model.windLoss_in_Y0_without_PCA=windLoss_in_Y0;
    model.windLoss_in_YP_without_PCA=windLoss_in_YP;
end

model.Y0_index_without_PCA=Y0_part;
model.YP_index_without_PCA=YP_part;
model.YPhi_location=[];

model.data_wind_origin=data_wind; 
model.Ckl_origin=Ckl;
model.data_wind_PCA=P_wind_PCA;
model.K=PW2Pwan_coeficent;
model.miu_average=miu_average;
end





function [eq,ineq]=DC_flow_constraint(NodeNum,N,T,Bus_G,Bus_D,ThPimin,ThPimax,B,bus_P,branchI,branchJ,branchX,branchP,wind_node)
Aeq_constraints_DCPowerFlow=[];
beq_constraints_DCPowerFlow=[];

Aineq_constraints_DCPowerFlow=[];
bineq_constraints_DCPowerFlow=[];

R=length(wind_node);

PG=sparse(1,NodeNum);
PD=sparse(1,NodeNum);
PG(1,Bus_G)=1;
PD(1,Bus_D)=1;

P_index=1;
D_index=1;
for i=1:NodeNum
    if(PG(i)==1&&PD(i)==1)
        P_no=find(i==Bus_G);
        D_no=find(i==Bus_D);
        PW_no=find(i==wind_node);
        
        uit=sparse(T,N*T);
        PitWan=sparse(T,N*T);
        Seita=sparse(T,NodeNum*T);
        
        uit(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag(ThPimin(P_no)*ones(1,T)));
        PitWan(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag((ThPimax(P_no)-ThPimin(P_no))*ones(1,T)));
        coefficient=[];
        for j=1:NodeNum
            coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
        end
        Seita=-1*coefficient;
        
        Pit=sparse(T,N*T);
        Pit(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag(ones(1,T)));
        
        PWrt=sparse(T,R*T);
        if(~isempty(PW_no))
            PWrt=[];
            for t=1:T
                PW_part=sparse(1,R);
                PW_part(1,PW_no)=1;
                PWrt=blkdiag(PWrt,PW_part);
            end
        end
        
        
        Aeq_DCPowerFlow=[sparse(T,4*N*T),Pit,Seita,sparse(T,N*T),PWrt];
        beq_DCPowerFlow=[bus_P(:,D_no)];
        
        Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
        beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
        
        P_index=P_index+1;
        D_index=D_index+1;
    end
    if(PG(i)==1&&PD(i)==0)
        P_no=find(i==Bus_G);
        PW_no=find(i==wind_node);
        
        uit=sparse(T,N*T);
        PitWan=sparse(T,N*T);
        Seita=sparse(T,NodeNum*T);
        
        uit(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag(ThPimin(P_no)*ones(1,T)));
        PitWan(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag((ThPimax(P_no)-ThPimin(P_no))*ones(1,T)));
        coefficient=[];
        for j=1:NodeNum
            coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
        end
        Seita=-1*coefficient;
        
        
        Pit=sparse(T,N*T);
        Pit(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag(ones(1,T)));
        
        PWrt=sparse(T,R*T);
        if(~isempty(PW_no))
            PWrt=[];
            for t=1:T
                PW_part=sparse(1,R);
                PW_part(1,PW_no)=1;
                PWrt=blkdiag(PWrt,PW_part);
            end
        end
        
        Aeq_DCPowerFlow=[sparse(T,4*N*T),Pit,Seita,sparse(T,N*T),PWrt];
        beq_DCPowerFlow=[sparse(T,1)];
        
        Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
        beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
        
        
        P_index=P_index+1;
    end
    if(PG(i)==0&&PD(i)==1)
        
        D_no=find(i==Bus_D);
        PW_no=find(i==wind_node);
        Seita=sparse(T,NodeNum*T);
        coefficient=[];
        for j=1:NodeNum
            coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
        end
        Seita=-1*coefficient;
        
        PWrt=sparse(T,R*T);
        if(~isempty(PW_no))
            PWrt=[];
            for t=1:T
                PW_part=sparse(1,R);
                PW_part(1,PW_no)=1;
                PWrt=blkdiag(PWrt,PW_part);
            end
        end
        
        Aeq_DCPowerFlow=[sparse(T,5*N*T),Seita,sparse(T,N*T),PWrt];
        beq_DCPowerFlow=[bus_P(:,D_no)];
        Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
        beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
        D_index=D_index+1;
    end
    if(PG(i)==0&&PD(i)==0)
        Seita=sparse(T,NodeNum*T);
        PW_no=find(i==wind_node);
        
        coefficient=[];
        for j=1:NodeNum
            coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
        end
        Seita=coefficient;
        
        PWrt=sparse(T,R*T);
        if(~isempty(PW_no))
            PWrt=[];
            for t=1:T
                PW_part=sparse(1,R);
                PW_part(1,PW_no)=1;
                PWrt=blkdiag(PWrt,PW_part);
            end
        end
        
        Aeq_DCPowerFlow=[sparse(T,5*N*T),Seita,sparse(T,N*T),PWrt];
        beq_DCPowerFlow=[sparse(T,1)];
        Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
        beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
    end
    
end

%Seita=0
% Seita=sparse(T,NodeNum*T);
% Seita(:,1:T)=sparse(diag(ones(1,T)));
% Aeq_DCPowerFlow=[sparse(T,5*N*T),Seita,sparse(T,N*T),sparse(T,R*T)];
% beq_DCPowerFlow=[sparse(T,1)];
% Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
% beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];

Aineq_DCPowerFlow=[];
bineq_DCPowerFlow=[];


for index=1:length(branchI)
    Seita_i=branchI(index);
    Seita_j=branchJ(index);
    Seita=sparse(T,NodeNum*T);
    
    Seita(1:T,(Seita_i-1)*T+1:Seita_i*T)=diag((1/branchX(index))*ones(1,T));
    Seita(1:T,(Seita_j-1)*T+1:Seita_j*T)=diag(-1*(1/branchX(index))*ones(1,T));
    
    Aineq_DCPowerFlow=sparse([Aineq_DCPowerFlow;sparse(T,5*N*T),Seita,sparse(T,N*T),sparse(T,R*T)]);
    bineq_DCPowerFlow=[bineq_DCPowerFlow;branchP(index)*ones(T,1)];
    
    Aineq_DCPowerFlow=sparse([Aineq_DCPowerFlow;sparse(T,5*N*T),-1*Seita,sparse(T,N*T),sparse(T,R*T)]);
    bineq_DCPowerFlow=[bineq_DCPowerFlow;branchP(index)*ones(T,1)];
    
    
end
Aineq_constraints_DCPowerFlow=[Aineq_constraints_DCPowerFlow;Aineq_DCPowerFlow];
bineq_constraints_DCPowerFlow=[bineq_constraints_DCPowerFlow;bineq_DCPowerFlow];


eq.A=Aeq_constraints_DCPowerFlow;
eq.b=beq_constraints_DCPowerFlow;

ineq.A=Aineq_constraints_DCPowerFlow;
ineq.b=bineq_constraints_DCPowerFlow;


end