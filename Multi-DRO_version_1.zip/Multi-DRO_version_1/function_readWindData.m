function [data_Wind] = function_readWindData(data,Filedir,param)
%FUNCTION_READWINDDATA �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
wind_num=data.Wind.wind_Number;
Month_num=2;
WIND_MAX=200;
WIND_MIN=0;
wind=xlsread(Filedir);
data=wind(1:end,2:end);
if(5+wind_num*Month_num>12)
    data=data(:,1:1+wind_num*Month_num);
else
data=data(:,5:5+wind_num*Month_num);
end

data=rmmissing(data,1);
for i=1:wind_num
data_Wind{i}=reshape(data(:,(i-1)*Month_num+1:i*Month_num),24,[]);%0.0005
std_wind=data_Wind{i}/(WIND_MAX-WIND_MIN);
data_Wind{i}=0.5*param.windcoefficient*ones(size(data_Wind{i},1),size(data_Wind{i},2)).*std_wind+...
    0.5*param.windcoefficient*ones(size(data_Wind{i},1),size(data_Wind{i},2));

% 
% [row_min,col_min]=find(min_data_Wind<5*param.windcoefficient);
% [row_max,col_max]=find(max_data_Wind>1.5);
% 
% for j=1:length(row_min)
%     [row,col]=find(data_Wind{i}(row_min(j),:)==min_data_Wind(row_min(j),1));
%     data_Wind{i}(row_min(j),col)=5*param.windcoefficient;
% end
% for j=1:length(row_max)
%         [row,col]=find(data_Wind{i}(row_max(j),:)==max_data_Wind(row_max(j),1));
%     data_Wind{i}(row_max(j),col)=1.5;
% end
end
% data_Wind;
% data_Wind{1}=0.1*data;
end

