function [DRO_model]=function_UC_MDROmodel_PCA(data,data_wind_history,index)
%2020-12-28 lw
%约束功率上下�?功率平衡 整数变量限制 目标函数线�?化s
%2021-1-17 lw
%加入其他状�?变量和约�?
%2021-3-22
%爬坡约束
%2021-3-27 
%PCA
%多阶�?
%% data
B=DCOPFNodeY(data);
Alpha = data.units.alpha;                           %机组发电函数系数Alpha--N*1矩阵
Beta = data.units.beta;                             %机组发电函数系数Beta--N*1矩阵
Gama = data.units.gamma;                            %机组发电函数系数Gama--N*1矩阵
ThPimin = data.units.PG_low;                         %机组发电功率下界--N*1矩阵
ThPimax = data.units.PG_up;                          %机组发电功率上界--N*1矩阵
Piup = data.units.ramp;                         %机组上坡功率上界--N*1矩阵
Pidown = data.units.ramp;                     %机组下坡功率上界--N*1矩阵
Pt = data.totalLoad.PD_T;                       %有功负荷--T*1矩阵
Qt=data.totalLoad.QD_T;                       %无功负荷--T*1
Bus_G=data.units.bus_G;                           %机组节点�?
N = data.baseparameters.unitN;                 %机组数量--1*1矩阵
T = data.totalLoad.T;                          %时间段数--1*1矩阵
Dt = data.totalLoad.PD_T;                                 %负载�?��--T*1矩阵
bus_P_factor=data.busLoad.bus_P_factor;           %节点有功负荷因子
bus_Q_factor=data.busLoad.bus_Q_factor;            %节点无功负荷因子
bus_P=data.busLoad.node_P;
Spin = data.totalLoad.R_T;                     %旋转热备�?-T*1矩阵
ThTime_on_off_init = data.units.U_ini;        %机组在初始状态前已经�?��/停机的时�?-N*1矩阵
Thon_off_init =  data.units.PG_up*0.7;               %机组机组初始功率--N*1矩阵
ThTime_on_min = data.units.T_on;             %机组�?���?��时间--N*1矩阵
ThTime_off_min = data.units.T_off;           %机组�?��停机时间--N*1矩阵
Th_cost_start = data.units.start_cost;           %机组启动费用--N*1矩阵
ThCold_cost_start = data.units.start_cost*2;           %火电机组冷启动费�?-N*1矩阵
ThHot_cost_start = data.units.start_cost;             %火电机组热启动费�?-N*1矩阵
Pistartup = data.units.PG_low;      %火电机组�?��功率--N*1矩阵
Pishutdown = data.units.PG_low;      %火电机组关机功率--N*1矩阵
Ui0 = full(spones(Thon_off_init));                                  %火电机组机组初始�?停机状�?
Ui = max(0,min(ones(N,1) * T,Ui0 .* (ThTime_on_min - ThTime_on_off_init)));                    %--N*1矩阵
Li = max(0,min(ones(N,1) * T,(ones(N,1) - Ui0) .* (ThTime_off_min + ThTime_on_off_init)));     %--N*1矩阵
ThCold_time_start=min(max(2*ThTime_off_min,1),T);
L=4;

%net
NodeNum=data.baseparameters.busN;
branchI=data.branch.I;
branchJ=data.branch.J;
branchR=data.branch.R;
branchX=data.branch.X;
branchP=data.branch.P;
branchB=data.branch.B;
branchGroundI=0;
branchGroundB=0;
branchTransformerI=data.branchTransformer.I;
branchTransformerJ=data.branchTransformer.J;
branchTransformerR=data.branchTransformer.R;
branchTransformerX=data.branchTransformer.X;
branchTransformerK=data.branchTransformer.K;
branchTransformerP=data.branchTransformer.P;

All_branchI=[branchI;branchTransformerI];
All_branchJ=[branchJ;branchTransformerJ];
All_branchP=[branchP;branchTransformerP];
All_branchX=[branchX;branchTransformerX];
bus_PDQR=data.busLoad.bus_PDQR;
bus_G=data.units.bus_G;
wind_Node=data.Wind.wind_Node; 
R=data.Wind.wind_Number;
%% UC model
% x
uit=N*T;
sit=N*T;
dit=N*T;
Sit=N*T;
x_num=uit+sit+dit+Sit;

%continuous variables and some auxiliary variables
PGit=N*T;
Seitait=NodeNum*T;
Zit=N*T;
y_num=PGit+Zit+Seitait;

%% Constraints without uncertain

%state constraints
%s_(i,t)-d_(i,t)=u_(i,t)-u_(i,t-1)
%sit-dit=uit- uit-1
Aeq_constraints_state=[];
beq_constraints_state=-1*Ui0;

%t=1�?
for i=1:N
    constraint_state=sparse(1,x_num);
    
    uit=sparse(1,N*T);
    sit=sparse(1,N*T);
    dit=sparse(1,N*T);
    
    uit(1,(i-1)*T+1)=-1;
    sit(1,(i-1)*T+1)=1;
    dit(1,(i-1)*T+1)=-1;
    
    constraint_state(1,1:N*T)=uit;
    constraint_state(1,N*T+1:2*N*T)=sit;
    constraint_state(1,2*N*T+1:3*N*T)=dit;
    
    Aeq_constraints_state=[Aeq_constraints_state;constraint_state];

end

%t>1
for i=1:N
    for t=2:T
        constraint_state=sparse(1,x_num);
        
        uit=sparse(1,N*T);
        sit=sparse(1,N*T);
        dit=sparse(1,N*T);
        
        uit(1,(i-1)*T+t)=-1;
        uit(1,(i-1)*T+t-1)=1;
        sit(1,(i-1)*T+t)=1;
        dit(1,(i-1)*T+t)=-1;
        
        constraint_state(1,1:N*T)=uit;
        constraint_state(1,N*T+1:2*N*T)=sit;
        constraint_state(1,2*N*T+1:3*N*T)=dit;
        
        Aeq_constraints_state=[Aeq_constraints_state;constraint_state];
    end
end
beq_constraints_state=[beq_constraints_state;sparse(N*(T-1),1)];

%% initial status
Aeq_constraints_initial_statues=[];
beq_constraints_initial_statues=[];

for i=1:N
    if(Ui(i) + Li(i) >= 1)
        for t=1:Ui(i)+Li(i)
            
            uit=sparse(1,N*T);
            
            uit(1,(i-1)*T+t)=1;
            
            constraints_initial_statues=sparse(1,x_num);
            constraints_initial_statues(1,1:N*T)=uit;
            
            Aeq_constraints_initial_statues=[Aeq_constraints_initial_statues;constraints_initial_statues];
            beq_constraints_initial_statues=[beq_constraints_initial_statues;Ui0(i)];
        end
    end
end
%% start_cost_constraint
%Sit>=Chot,i,t*sit
Aineq_constraint_start_cost=[];

for i=1:N
    for t=1:T
        constraint_start_cost=sparse(1,x_num);
        
        sit=sparse(1,N*T);
        Sit=sparse(1,N*T);
        
        sit(1,(i-1)*T+t)=ThHot_cost_start(i);
        Sit(1,(i-1)*T+t)=-1;
        
        constraint_start_cost(1,N*T+1:2*N*T)=sit;
        constraint_start_cost(1,3*N*T+1:4*N*T)=Sit;
        
        Aineq_constraint_start_cost=[Aineq_constraint_start_cost;constraint_start_cost];
    end
end
bineq_constraint_start_cost=sparse(N*T,1);

%Sit>=Ccold,i,t*[sit-sum(dit)-finint]
for i=1:N
    for t=1:T
        constraint_start_cost=sparse(1,x_num);
        
        sit=sparse(1,N*T);
        dit=sparse(1,N*T);
        Sit=sparse(1,N*T);
        
        sit(1,(i-1)*T+t)=ThCold_cost_start(i);
        dit(1,(i-1)*T+max(t-ThTime_off_min(i)-ThCold_time_start(i),1):(i-1)*T+t-1)=-1*ThCold_cost_start(i);
        Sit(1,(i-1)*T+t)=-1;
        
        constraint_start_cost(1,N*T+1:2*N*T)=sit;
        constraint_start_cost(1,2*N*T+1:3*N*T)=dit;
        constraint_start_cost(1,3*N*T+1:4*N*T)=Sit;
        
        Aineq_constraint_start_cost=[Aineq_constraint_start_cost;constraint_start_cost];
        
        if(t-ThTime_off_min(i)-ThCold_time_start(i))<=0&& max(0,-ThTime_on_off_init(i))<abs(t-ThTime_off_min(i)-ThCold_time_start(i)-1)+1
            bineq_constraint_start_cost=[bineq_constraint_start_cost;ThCold_cost_start(i)];
        else
            bineq_constraint_start_cost=[bineq_constraint_start_cost;0];
        end
    end
end
%% minim up/down time constraint
%∑s_(i,?) ≤u_(i,t)
Aineq_constraint_min_upordown_time=[];
bineq_constraint_min_upordown_time=[];
for i=1:N
    for t=Ui(i) + 1:T
        
        constraint_min_upordown_time=sparse(1,x_num);
        
        uit=sparse(1,N*T);
        sit=sparse(1,N*T);
        
        uit(1,(i-1)*T+t)=-1;
        sit(1,(i-1)*T+max(0,t-ThTime_on_min(i))+1:(i-1)*T+t)=1;
        
        constraint_min_upordown_time(1,1:N*T)=uit;
        constraint_min_upordown_time(1,N*T+1:2*N*T)=sit;
        
        Aineq_constraint_min_upordown_time=[Aineq_constraint_min_upordown_time;constraint_min_upordown_time];
        bineq_constraint_min_upordown_time=[bineq_constraint_min_upordown_time;0];
        
    end
end
%∑d_(i,?) �?-u_(i,t)
for i=1:N
    for t=Li(i)+1:T
        
        constraint_min_upordown_time=sparse(1,x_num);
        
        uit=sparse(1,N*T);
        dit=sparse(1,N*T);
        
        uit(1,(i-1)*T+t)=1;
        dit(1,(i-1)*T+max(0,t-ThTime_off_min(i))+1:(i-1)*T+t)=1;
        
        constraint_min_upordown_time(1,1:N*T)=uit;
        constraint_min_upordown_time(1,2*N*T+1:3*N*T)=dit;
        
        Aineq_constraint_min_upordown_time=[Aineq_constraint_min_upordown_time;constraint_min_upordown_time];
        bineq_constraint_min_upordown_time=[bineq_constraint_min_upordown_time;1];
    end
end
%% ramp_limt

Aineq_ramp_limt_up=[];
bineq_ramp_limt_up=[];
Aineq_ramp_limt_down=[];
bineq_ramp_limt_down=[];
Aineq_genration_limit_lower=[];
bineq_genration_limit_lower=[];
Aineq_genration_limit_upper=[];
bineq_genration_limit_upper=[];
for i=1:N
    %P_(i,t)^G-P_(i,t-1)^G≤u_(i,t-1) P_(i,up)+ s_(i,t)*P_(i,start)
    %t=1
    constraint_ramp_limit=sparse(1,x_num+y_num);
    
    constraint_ramp_limit(1,N*T+(i-1)*T+1)=-1*Pistartup(i);%sit
    constraint_ramp_limit(1,4*N*T+(i-1)*T+1)=1;%
    
    Aineq_ramp_limt_up=[Aineq_ramp_limt_up;constraint_ramp_limit];
    bineq_ramp_limt_up=[bineq_ramp_limt_up;Ui0(i)*Piup(i)+Thon_off_init(i)];
    
    
    %t>1
    constraint_ramp_limit=sparse(T-1,x_num+y_num);
    
    constraint_ramp_limit(:,(i-1)*T+1:(i-1)*T+T-1)=sparse(diag(-1*Piup(i)*ones(T-1,1)));%uit
    constraint_ramp_limit(:,N*T+(i-1)*T+2:N*T+(i-1)*T+T)=sparse(diag(-1*Pistartup(i)*ones(T-1,1)));%sit
    constraint_ramp_limit(:,4*N*T+(i-1)*T+1:4*N*T+(i-1)*T+T)=[sparse(diag(-1*ones(T-1,1))),sparse(T-1,1)]+[sparse(T-1,1),sparse(diag(ones(T-1,1)))];%pit
    Aineq_ramp_limt_up=[Aineq_ramp_limt_up;constraint_ramp_limit];
    bineq_ramp_limt_up=[bineq_ramp_limt_up;sparse(T-1,1)];
    
    %P_(i,t-1)^G-P_(i,t)^G≤u_(i,t) P_(i,down)+d_(i,t) P_(i,shut)
    %t=1
    constraint_ramp_limit=sparse(1,x_num+y_num);
    
    constraint_ramp_limit(1,(i-1)*T+1)=-1*Pidown(i);%uit
    constraint_ramp_limit(1,2*N*T+(i-1)*T+1)=-1*Pishutdown(i);%dit
    constraint_ramp_limit(1,4*N*T+(i-1)*T+1)=-1;%pit
    Aineq_ramp_limt_down=[Aineq_ramp_limt_down;constraint_ramp_limit];
    bineq_ramp_limt_down=[bineq_ramp_limt_down;-1*Thon_off_init(i)];
    
    %t>1
    constraint_ramp_limit=sparse(T-1,x_num+y_num);
    constraint_ramp_limit(:,(i-1)*T+2:(i-1)*T+T)=sparse(diag(-1*Pidown(i)*ones(T-1,1)));%uit
    constraint_ramp_limit(:,2*N*T+(i-1)*T+2:2*N*T+(i-1)*T+T)=sparse(diag(-1*Pishutdown(i)*ones(T-1,1)));%dit
    constraint_ramp_limit(:,4*N*T+(i-1)*T+1:4*N*T+(i-1)*T+T)=[sparse(diag(ones(T-1,1))),sparse(T-1,1)]+[sparse(T-1,1),sparse(diag(-1*ones(T-1,1)))];%pit
    Aineq_ramp_limt_down=[Aineq_ramp_limt_down;constraint_ramp_limit];
    bineq_ramp_limt_down=[bineq_ramp_limt_down;sparse(T-1,1)];
    
    %generation limit
    %u_(i,t) P_min≤P_(i,t)^G≤u_(i,t) P_max

    %uit*Pmin<=Pit
    constraint_genration_limit=sparse(T,x_num+y_num);
    constraint_genration_limit(:,(i-1)*T+1:(i-1)*T+T)=sparse(diag(ThPimin(i)*ones(T,1)));%uit
    constraint_genration_limit(:,4*N*T+(i-1)*T+1:4*N*T+(i-1)*T+T)=sparse(diag(-1*ones(T,1)));%pit
    Aineq_genration_limit_upper=[Aineq_genration_limit_upper;constraint_genration_limit];
    bineq_genration_limit_upper=[bineq_genration_limit_upper;sparse(T,1)];
    
    %uit*Pmax>=Pit
    constraint_genration_limit=sparse(T,x_num+y_num);
    constraint_genration_limit(:,(i-1)*T+1:(i-1)*T+T)=sparse(diag(-1*ThPimax(i)*ones(T,1)));%uit
    constraint_genration_limit(:,4*N*T+(i-1)*T+1:4*N*T+(i-1)*T+T)=sparse(diag(ones(T,1)));%pit
    Aineq_genration_limit_lower=[Aineq_genration_limit_lower;constraint_genration_limit];
    bineq_genration_limit_lower=[bineq_genration_limit_lower;sparse(T,1)];
    
end
%% power balance

if(index==1)
    Aineq_constraint_power_balance_upper=[];
    bineq_constraint_power_balance_upper=[];
    Aineq_constraint_power_balance_lower=[];
    bineq_constraint_power_balance_lower=[];
    
    pit=[];
    pwrt=[];
    
    for t=1:N
        pit=sparse([pit,eye(T)]);
    end
    for t=1:T
        part_pwrt=sparse(1,R*T);
        part_pwrt(1,(t-1)*R+1:t*R)=1;
        pwrt=sparse([pwrt;part_pwrt]);
    end
    Aineq_constraint_power_balance_upper=[pit,pwrt];%pwrt sparse(T,R_wan_len)
    bineq_constraint_power_balance_upper=Dt;
    
    Aineq_constraint_power_balance_lower=[Aineq_constraint_power_balance_lower;-1*pit,-1*pwrt];
    bineq_constraint_power_balance_lower=[bineq_constraint_power_balance_lower;-1*Dt];
    pwrt_location=size(pit,2)+1:size(Aineq_constraint_power_balance_upper,2);
    Aineq_constraint_power_balance=[Aineq_constraint_power_balance_lower;Aineq_constraint_power_balance_upper];%];
    bineq_constraint_power_balance=[bineq_constraint_power_balance_lower;bineq_constraint_power_balance_upper];%];
end
%% 
%objective function linear approximation
Aineq_linear_approximation=[];
bineq_linear_approximation=[];
a_alpha=reshape(repmat(Alpha,1,T)',N*T,1);
b_beta=reshape(repmat(Beta,1,T)',N*T,1);
c_gamma=reshape(repmat(Gama,1,T)',N*T,1);

J=0:L;
for j=1:L+1
    pil=reshape(repmat(ThPimin+(J(j)/L)*(ThPimax-ThPimin),1,T)',N*T,1);
    constraint_linear_approximation=sparse(N*T,x_num+y_num);
    constraint_linear_approximation(:,1:N*T)=sparse(diag(a_alpha-c_gamma.*power(pil,2)));%uit
    constraint_linear_approximation(:,4*N*T+1:5*N*T)=sparse(diag(2*c_gamma.*(pil)+b_beta));%pit
    constraint_linear_approximation(:,5*N*T+NodeNum*T+1:6*N*T+NodeNum*T)=sparse(diag(-1*ones(1,N*T)));%zit
    Aineq_linear_approximation=[Aineq_linear_approximation;constraint_linear_approximation];
    bineq_linear_approximation=[bineq_linear_approximation;sparse(N*T,1)];
end
%% DC flow
if(index==2)
Aineq_DCPowerFlow=[];
bineq_DCPowerFlow=[];
Aeq_DCPowerFlow=[];
beq_DCPowerFlow=[];

[eq_DCPowerFlow,ineq_DCPowerFlow]=DC_flow_constraint(NodeNum,N,T,Bus_G,bus_PDQR,ThPimin,ThPimax,B,bus_P,All_branchI,All_branchJ,All_branchX,All_branchP,wind_Node);
Aeq_DCPowerFlow=eq_DCPowerFlow.A;
beq_DCPowerFlow=eq_DCPowerFlow.b;
Aineq_DCPowerFlow=ineq_DCPowerFlow.A;
bineq_DCPowerFlow=ineq_DCPowerFlow.b;

%x,PGit,Seita_it,Zit,PWrt
Aineq_constraint_DC_flow_upper=Aeq_DCPowerFlow;
bineq_constraint_DC_flow_upper=beq_DCPowerFlow;
Aineq_constraint_DC_flow_lower=-1*Aeq_DCPowerFlow;
bineq_constraint_DC_flow_lower=-1*beq_DCPowerFlow;

Aineq_Aeq_DC_flow=[Aineq_constraint_DC_flow_lower;Aineq_constraint_DC_flow_upper];%];
bineq_Aeq_DC_flow=[bineq_constraint_DC_flow_lower;bineq_constraint_DC_flow_upper];%];

DC_flow_PGit_location=x_num+1:x_num+PGit;
DC_flow_Seita_it_location=x_num+PGit+1:x_num+PGit+Seitait;
DC_flow_PWrt_location=x_num+PGit+Seitait+Zit+1:x_num+PGit+Seitait+Zit+R*T;
end
%% DRO model
Lk=4;
rou=1e-3;

%Wind unit
for i=1:R
    M(i)=length(data_wind_history{i});
end
M_min=min(M);
data_wind=[];
%P_w(1,1) P_w(2,1) P_w(3,1)...
for t=1:T
    for i=1:R
        data_wind=[data_wind;data_wind_history{i}(t,1:M_min)];
    end
end

P_Wind_Max=max(data_wind,[],2);
P_Wind_Min=min(data_wind,[],2);
miu_average=mean(data_wind,2);
covariance=cov(data_wind');
[U,S,V] = svd (covariance);
diag_S=diag(S);
diag_S_1_2=power(diag_S,0.5);
mean_S=mean(diag_S);
S_log=floor(log10(mean_S));
R_wan=find(log10(diag_S)>S_log);
R_wan_len=length(R_wan);

P_wan=(U(:,R_wan)*((S(R_wan,R_wan))^0.5)^(-1))'*(data_wind-repmat(miu_average,1,M_min));
P_wan_Wind_Max=max(P_wan,[],2);
P_wan_Wind_Min=min(P_wan,[],2);

Ckl=repmat(P_wan_Wind_Min,1,Lk)+...
    repmat((P_wan_Wind_Max-P_wan_Wind_Min),1,Lk).*...
    repmat(([1:Lk]/Lk),R_wan_len,1);
gamma_R_T_L=[];

for j=1:Lk-1
    gamma_R_T_L=[gamma_R_T_L,mean(max(P_wan-repmat(Ckl(:,j),1,M_min),0),2)+rou*ones(R_wan_len,1)];
end
gamma_k_l=gamma_R_T_L; 

%uncertain set 
%E(u)<=gamma
%p(Pw,u in Q)=1

%Pw_min<=Pw<=Pw_max
%max{v,0}<=u

C=[];
D=[];
d=[];

%P_wind<=P_wind_max
C=[C;sparse(diag(ones(R_wan_len,1)))];
D=[D;sparse(R_wan_len,R_wan_len*(Lk-1))];
d=[d;P_wan_Wind_Max];

%-P_wind<=-P_wind_min
C=[C;sparse(diag(-1*ones(R_wan_len,1)))];
D=[D;sparse(R_wan_len,R_wan_len*(Lk-1))];
d=[d;-1*P_wan_Wind_Min];

%-phi<=0
C=[C;sparse(R_wan_len*(Lk-1),R_wan_len)];
D=[D;sparse(diag(-1*ones(R_wan_len*(Lk-1),1)))];
d=[d;sparse(R_wan_len*(Lk-1),1)];

% %phi<=P_wind_max
% d_P_Wind_Max=repmat(P_Wind_Max,1,(Lk-1));
% d_P_Wind_Max=reshape(d_P_Wind_Max',(Lk-1)*length(P_Wind_Max),1);
% C=[C;sparse(R_wan_len*(Lk-1),R_wan_len)];
% D=[D;sparse(diag(ones(R_wan_len*(Lk-1),1)))];
% d=[d;d_P_Wind_Max];


%P_wind_r_t - phi_r,t,l <=Cr,t,l
for i=1:R_wan_len
            C_part=sparse(Lk-1,R_wan_len);
            D_part=sparse(Lk-1,R_wan_len*(Lk-1));
            
            C_part(:,i)=1;
            D_part(:,(i-1)*(Lk-1)+1:i*(Lk-1))=sparse(diag(-1*ones((Lk-1),1)));
            
            C=[C;C_part];
            D=[D;D_part];
            
            d=[d;Ckl(i,1:Lk-1)'];
end


%variable location
total_var_num=0;

x_location=1:x_num;
total_var_num=total_var_num+length(x_location);

x_uit=1:N*T;
x_sit=N*T+1:N*T+N*T;
x_dit=N*T+N*T+1:N*T+N*T+N*T;
x_Sit=N*T+N*T+N*T+1:N*T+N*T+N*T+N*T;

Eta_location=total_var_num+1;
total_var_num=total_var_num+length(Eta_location);

lambda_location=total_var_num+1:total_var_num+R_wan_len*(Lk-1);
total_var_num=total_var_num+length(lambda_location);

Y0_PG=total_var_num+1:total_var_num+PGit;
total_var_num=total_var_num+length(Y0_PG);

if(index==2)
    Y0_Seita=total_var_num+1:total_var_num+Seitait;
    total_var_num=total_var_num+length(Y0_Seita);
end

Y0_Zit=total_var_num+1:total_var_num+Zit;
total_var_num=total_var_num+length(Y0_Zit);


YP_PG=total_var_num+1:...
    total_var_num+PGit*R*0.5*(T+1);
total_var_num=total_var_num+length(YP_PG);

if(index==2)
YP_Seita=total_var_num+1:...
    total_var_num+Seitait*R*0.5*(T+1);
total_var_num=total_var_num+length(YP_Seita);
end

YP_Zit=total_var_num+1:...
    total_var_num+Zit*R*0.5*(T+1);
total_var_num=total_var_num+length(YP_Zit);

YPhi_PG=total_var_num+1:...
    total_var_num+PGit*R_wan_len*(Lk-1);
total_var_num=total_var_num+length(YPhi_PG);

if(index==2)
YPhi_Seita=total_var_num+1:...
    total_var_num+Seitait*R_wan_len*(Lk-1);
total_var_num=total_var_num+length(YPhi_Seita);
end

YPhi_Zit=total_var_num+1:...
    total_var_num+Zit*R_wan_len*(Lk-1);
total_var_num=total_var_num+length(YPhi_Zit);

pai_1_location=total_var_num+1:...
    total_var_num+size(C,1);
total_var_num=total_var_num+length(pai_1_location);

pai_2_location_upper=total_var_num+1:...
    total_var_num+size(C,1)*(size(Aineq_genration_limit_upper,1));
total_var_num=total_var_num+length(pai_2_location_upper);

pai_2_location_lower=total_var_num+1:...
    total_var_num+size(C,1)*(size(Aineq_genration_limit_lower,1));
total_var_num=total_var_num+length(pai_2_location_lower);

pai_3_location=total_var_num+1:total_var_num+size(C,1)*size(Aineq_linear_approximation,1);
total_var_num=total_var_num+length(pai_3_location);
if(index==1)
    pai_4_location=total_var_num+1:...
    total_var_num+size(C,1)*(size(Aineq_constraint_power_balance,1));
total_var_num=total_var_num+length(pai_4_location);
end
if(index==2)
pai_4_location_upper=total_var_num+1:...
        total_var_num+size(C,1)*(size(Aineq_constraint_DC_flow_upper,1));
    total_var_num=total_var_num+length(pai_4_location_upper);

pai_4_location_lower=total_var_num+1:...
    total_var_num+size(C,1)*(size(Aineq_constraint_DC_flow_lower,1));
total_var_num=total_var_num+length(pai_4_location_lower);

% pai_4_location=total_var_num+1:...
%     total_var_num+size(C,1)*(size(Aineq_Aeq_DC_flow,1));
% total_var_num=total_var_num+length(pai_4_location);

pai_4_location_seita=total_var_num+1:...
    total_var_num+size(C,1)*(size(Aineq_DCPowerFlow,1));
total_var_num=total_var_num+length(pai_4_location_seita);
end
pai_5_location=total_var_num+1:...
    total_var_num+size(C,1)*(size(Aineq_ramp_limt_up,1))+size(C,1)*(size(Aineq_ramp_limt_down,1));
total_var_num=total_var_num+length(pai_5_location);

% pai_5_location_down=total_var_num+1:...
%     total_var_num+size(C,1)*(size(Aineq_ramp_limt_down,1));
% total_var_num=total_var_num+length(pai_5_location_down);
%% linear decision rule
Y0_part=sparse(diag(ones(y_num,1)));

YP_part=[];
for t=1:T
    YP_part=sparse(blkdiag(YP_part,ones(1,t*R)));
end
YP_part_PG=[];
for i=1:N
    YP_part_PG=sparse(blkdiag(YP_part_PG,YP_part));
end
YP_part_Seita=[];
for i=1:NodeNum
    YP_part_Seita=sparse(blkdiag(YP_part_Seita,YP_part));
end
YP_part_Zit=YP_part_PG;

YP_part=sparse(blkdiag(YP_part_PG,YP_part_Seita,YP_part_Zit));

YPhi_part=[];
for i=1:T
    YPhi_part=sparse(blkdiag(YPhi_part,ones(1,R_wan_len*(Lk-1))));
end
YPhi_part_PG=[];
for i=1:N
    YPhi_part_PG=sparse(blkdiag(YPhi_part_PG,YPhi_part));
end
YPhi_part_Seita=[];
for i=1:NodeNum
    YPhi_part_Seita=sparse(blkdiag(YPhi_part_Seita,YPhi_part));
end
YPhi_part_Zit=YPhi_part_PG;
YPhi_part=sparse(blkdiag(YPhi_part_PG,YPhi_part_Seita,YPhi_part_Zit));

%PCA
Pwan2PW_coeficent=U*power(S,0.5);
Pwan2PW_coeficent=Pwan2PW_coeficent(:,R_wan);

%model variable
model_Pwan2PW_coeficent=[];
model_Pwan2PW_coeficent_part=[];
miu=[];
miu_avarge_part=[];
for t=1:T
    model_Pwan2PW_coeficent_part=[model_Pwan2PW_coeficent_part;Pwan2PW_coeficent(1:t*R,:)];
    miu_avarge_part=[miu_avarge_part;miu_average(1:t*R,:)];
end
%PG
for i=1:N
    model_Pwan2PW_coeficent=[model_Pwan2PW_coeficent;model_Pwan2PW_coeficent_part];
    miu=[miu;miu_avarge_part];
end
%seita
for i=1:NodeNum
    model_Pwan2PW_coeficent=[model_Pwan2PW_coeficent;model_Pwan2PW_coeficent_part];
    miu=[miu;miu_avarge_part];
end
%Zit
for i=1:N
    model_Pwan2PW_coeficent=[model_Pwan2PW_coeficent;model_Pwan2PW_coeficent_part];
    miu=[miu;miu_avarge_part];
end

miu=repmat(miu',y_num,1);
YP_miu=YP_part.*miu;



%% 

%
f=sparse(1,total_var_num);
f(1,x_sit)=reshape(repmat(ThHot_cost_start,1,T)',N*T,1);
f(1,x_Sit)=1;
f(1,Eta_location)=1;
f(1,lambda_location)=reshape(gamma_k_l',size(gamma_k_l,1)*size(gamma_k_l,2),1);

part_YP_Zit=[];
for i=1:N
    for t=1:T
        part_YP_Zit=[part_YP_Zit,miu_average(1:R*t)'];
    end
end


Aineq_constraint_pai_1=sparse(1,total_var_num);
Aineq_constraint_pai_1(1,Eta_location)=-1; %Eta
Aineq_constraint_pai_1(1,Y0_Zit)=1;  
Aineq_constraint_pai_1(1,YP_Zit)=part_YP_Zit;
Aineq_constraint_pai_1(1,pai_1_location)=d';
bineq_constraint_pai_1=0;

%YP Zit
part_YP_Zit=sparse(size(C,2),length(YP_Zit));
coefficience_YP_Zit=U(:,R_wan)*power(S(R_wan,R_wan),0.5);

for i=1:R_wan_len
    m_YP_Zit=[];
    for t=1:T
        m_YP_Zit=[m_YP_Zit,coefficience_YP_Zit(1:t*R,i)'];
    end
    part_YP_Zit(i,:)=-1*repmat(m_YP_Zit,1,N);
end

part_YPhi_Zit=[];
for i=1:N*T
    part_YPhi_Zit=[part_YPhi_Zit,diag(-1*ones(R_wan_len*(Lk-1),1))];
end

Aeq_constraint_pai_1=sparse(size(C,2)+size(D,2),total_var_num);
Aeq_constraint_pai_1(size(C,2)+1:size(C,2)+size(D,2),lambda_location)=diag(ones(length(lambda_location),1));
Aeq_constraint_pai_1(1:size(C,2),YP_Zit)=part_YP_Zit;
Aeq_constraint_pai_1(size(C,2)+1:size(C,2)+size(D,2),YPhi_Zit)=part_YPhi_Zit;
Aeq_constraint_pai_1(:,pai_1_location)=[C';D'];
beq_constraint_pai_1=sparse(size(C,2)+size(D,2),1);

%% Aineq_genration_limit
Aineq_constraint_pai_2=[];
bineq_constraint_pai_2=[];

Aeq_constraint_pai_2=[];
beq_constraint_pai_2=[];

%Aineq_genration_limit_upper
%ineq
part_pai_2=[];
yp_Aineq_part=[];
yp_Aineq=[];

yp_Aeq_PG=[];
yp_Aeq_Phi=[];
part_pai_2_d=[];
part_pai_2_C=[];
part_pai_2_D=[];
for i=1:size(Aineq_genration_limit_upper,1)
        yp_Aeq_PG_part=sparse(size(C,2),size(YP_part,2));
        yp_Aeq_Phi_part=sparse(size(D,2),size(YPhi_part,2));
        part_pai_2_d=blkdiag(part_pai_2_d,d');
        part_pai_2_C=blkdiag(part_pai_2_C,C');
        part_pai_2_D=blkdiag(part_pai_2_D,D');
    y_part_location=find(Aineq_genration_limit_upper(i,x_num+1:x_num+y_num)~=0);  
    for j=1:length(y_part_location)
        yp_Aineq_part=[yp_Aineq_part;Aineq_genration_limit_upper(i,x_num+y_part_location(j))*YP_miu(y_part_location(j),:)];
        
        yp_Aeq_location=find(YP_part(y_part_location(j),:)~=0);
        yp_Aeq_PG_part(:,yp_Aeq_location)=-1*Aineq_genration_limit_upper(i,x_num+y_part_location(j))*model_Pwan2PW_coeficent(yp_Aeq_location,:)';
    
        yphi_Aeq_location=find(YPhi_part(y_part_location(j),:)~=0);
        yp_Aeq_Phi_part(:,yphi_Aeq_location)=-1*Aineq_genration_limit_upper(i,x_num+y_part_location(j))*diag(ones(R_wan_len*(Lk-1),1));
    end
    yp_Aineq_part=sum(yp_Aineq_part,1);
    yp_Aineq=[yp_Aineq;yp_Aineq_part];
    yp_Aeq_PG=[yp_Aeq_PG;yp_Aeq_PG_part];
    yp_Aeq_Phi=[yp_Aeq_Phi;yp_Aeq_Phi_part];
end
constraint_pai_2=sparse(size(Aineq_genration_limit_upper,1),total_var_num);
constraint_pai_2(:,x_location)=Aineq_genration_limit_upper(:,x_location);
constraint_pai_2(:,[Y0_PG,Y0_Seita,Y0_Zit])=Aineq_genration_limit_upper(:,x_num+1:x_num+y_num);
constraint_pai_2(:,[YP_PG,YP_Seita,YP_Zit])=yp_Aineq;
constraint_pai_2(:,pai_2_location_upper)=part_pai_2_d;

Aineq_constraint_pai_2=[Aineq_constraint_pai_2;constraint_pai_2];
bineq_constraint_pai_2=[bineq_constraint_pai_2;bineq_genration_limit_upper];
%eq
constraint_pai_2=sparse((size(C,2)+size(D,2))*size(Aineq_genration_limit_upper,1),total_var_num);
constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_upper,1),[YP_PG,YP_Seita,YP_Zit])=yp_Aeq_PG;
constraint_pai_2(size(C,2)*size(Aineq_genration_limit_upper,1)+1:(size(C,2)+size(D,2))*size(Aineq_genration_limit_upper,1),[YPhi_PG,YPhi_Seita,YPhi_Zit])=yp_Aeq_Phi;
constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_upper,1),pai_2_location_upper)=part_pai_2_C;
constraint_pai_2(size(C,2)*size(Aineq_genration_limit_upper,1)+1:(size(C,2)+size(D,2))*size(Aineq_genration_limit_upper,1),pai_2_location_upper)=part_pai_2_D;

Aeq_constraint_pai_2=[Aeq_constraint_pai_2;constraint_pai_2];
beq_constraint_pai_2=[beq_constraint_pai_2;sparse((size(C,2)+size(D,2))*size(Aineq_genration_limit_upper,1),1)];

%Aineq_genration_limit_lower
part_pai_2=[];
for i=1:size(Aineq_genration_limit_lower,1)
    part_pai_2=blkdiag(part_pai_2,d');
end

part_YP_PG=[];
part_YP_PG_t=[];
for t=1:T
    part_YP_PG_t=blkdiag(part_YP_PG_t,-1*miu_average(1:R*t)');
end
for i=1:N
    part_YP_PG=blkdiag(part_YP_PG,part_YP_PG_t);
end
constraint_pai_2=sparse(size(Aineq_genration_limit_lower,1),total_var_num);
constraint_pai_2(:,x_uit)=diag(reshape(repmat(ThPimin,1,T)',N*T,1));
constraint_pai_2(:,Y0_PG)=diag(-1*ones(N*T,1));
constraint_pai_2(:,YP_PG)=part_YP_PG;
constraint_pai_2(:,pai_2_location_lower)=part_pai_2;

Aineq_constraint_pai_2=[Aineq_constraint_pai_2;constraint_pai_2];
bineq_constraint_pai_2=[bineq_constraint_pai_2;sparse(N*T,1)];

part_pai_2=[];
for i=1:size(Aineq_genration_limit_lower,1)
    part_pai_2=blkdiag(part_pai_2,C');
end

part_YP_PG_t=[];
for t=1:T
     part_YP_PG_t=blkdiag(part_YP_PG_t,repmat(diag_S_1_2(1:R_wan_len),1,t*R).*V(1:R_wan_len,1:t*R));
end
part_YP_PG=[];
for i=1:N
    part_YP_PG=blkdiag(part_YP_PG,part_YP_PG_t);
end

constraint_pai_2=sparse((size(C,2)+size(D,2))*size(Aineq_genration_limit_lower,1),total_var_num);
constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_lower,1),YP_PG)=part_YP_PG;
constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_lower,1),pai_2_location_lower)=part_pai_2;

part_pai_2=[];
for i=1:size(Aineq_genration_limit_lower,1)
    part_pai_2=blkdiag(part_pai_2,D');
end
part_YPhi=[];
for i=1:N
    part_YPhi=sparse(blkdiag(part_YPhi,diag(ones(T*R_wan_len*(Lk-1),1))));
end
constraint_pai_2(size(C,2)*size(Aineq_genration_limit_lower,1)+1:(size(C,2)+size(D,2))*size(Aineq_genration_limit_lower,1),YPhi_PG)=part_YPhi;
constraint_pai_2(size(C,2)*size(Aineq_genration_limit_lower,1)+1:(size(C,2)+size(D,2))*size(Aineq_genration_limit_lower,1),pai_2_location_lower)=part_pai_2;

Aeq_constraint_pai_2=[Aeq_constraint_pai_2;constraint_pai_2];
beq_constraint_pai_2=[beq_constraint_pai_2;sparse((size(C,2)+size(D,2))*size(Aineq_genration_limit_lower,1),1)];

%% Aineq_linear_approximation
Aineq_constraint_pai_3=[];
bineq_constraint_pai_3=[];
Aeq_constraint_pai_3=[];
beq_constraint_pai_3=[];


J=0:L;
for j=1:L+1
    pil=reshape(repmat(ThPimin+(J(j)/L)*(ThPimax-ThPimin),1,T)',N*T,1);    
    
    part_pai_3=[];
    for i=1:Zit
        part_pai_3=blkdiag(part_pai_3,d');
    end
    
    part_YP_PG=[];
    part_YP_PG_t=[];
    part_YP_Zit=[];
    part_YP_Zit_t=[];
    for t=1:T
        part_YP_PG_t=blkdiag(part_YP_PG_t,miu_average(1:R*t)');
        part_YP_Zit_t=blkdiag(part_YP_Zit_t,miu_average(1:R*t)');
    end
    for i=1:N
        part_YP_PG=blkdiag(part_YP_PG,(2*c_gamma((i-1)*T+1).*(pil((i-1)*T+1))+b_beta((i-1)*T+1))*part_YP_PG_t);
        part_YP_Zit=blkdiag(part_YP_Zit,-1*part_YP_Zit_t);
    end

    constraint_pai_3=sparse(Zit,total_var_num);
    constraint_pai_3(:,x_uit)=diag(a_alpha-c_gamma.*power(pil,2));
    constraint_pai_3(:,Y0_PG)=diag(2*c_gamma.*(pil)+b_beta);
    constraint_pai_3(:,Y0_Zit)=diag(-1*ones(Zit,1));
    constraint_pai_3(:,YP_PG)=part_YP_PG;
    constraint_pai_3(:,YP_Zit)=part_YP_Zit;
    constraint_pai_3(:,pai_3_location((j-1)*Zit*size(C,1)+1:j*Zit*size(C,1)))=part_pai_3;
    
    Aineq_constraint_pai_3=[Aineq_constraint_pai_3;constraint_pai_3];
    bineq_constraint_pai_3=[bineq_constraint_pai_3;sparse(Zit,1)];
    

    
    part_pai_3=[];
    for i=1:Zit
        part_pai_3=blkdiag(part_pai_3,C');
    end
    
    part_YP_PG_t=[];
    part_YP_Zit_t=[];
    for t=1:T
        part_YP_PG_t=blkdiag(part_YP_PG_t,repmat(diag_S_1_2(1:R_wan_len),1,t*R).*V(1:R_wan_len,1:t*R));
        part_YP_Zit_t=blkdiag(part_YP_Zit_t,repmat(diag_S_1_2(1:R_wan_len),1,t*R).*V(1:R_wan_len,1:t*R));
    end
    part_YP_PG=[];
    part_YP_Zit=[];
    for i=1:N
        part_YP_PG=blkdiag(part_YP_PG,-1*(2*c_gamma((i-1)*T+1).*(pil((i-1)*T+1))+b_beta((i-1)*T+1))*part_YP_PG_t);
        part_YP_Zit=blkdiag(part_YP_Zit,part_YP_Zit_t);
    end
    
    constraint_pai_3=sparse(Zit*(size(C,2)+size(D,2)),total_var_num);
    constraint_pai_3(1:size(C,2)*Zit,YP_PG)=part_YP_PG;
    constraint_pai_3(1:size(C,2)*Zit,YP_Zit)=part_YP_Zit;
    constraint_pai_3(1:size(C,2)*Zit,pai_3_location((j-1)*Zit*size(C,1)+1:j*Zit*size(C,1)))=part_pai_3;
    
    part_pai_3=[];
    for i=1:Zit
        part_pai_3=blkdiag(part_pai_3,D');
    end
    part_YPhi_PG=sparse((Lk-1)*R_wan_len*Zit,(Lk-1)*R_wan_len*Zit);
    part_YPhi_Zit=sparse((Lk-1)*R_wan_len*Zit,(Lk-1)*R_wan_len*Zit);
    coefficent_YPhi=-1*reshape(repmat(2*c_gamma.*(pil)+b_beta,1,(Lk-1)*R_wan_len),(Lk-1)*R_wan_len*Zit,1);
    for i=1:(Lk-1)*R_wan_len*Zit
        part_YPhi_PG(i,i)=coefficent_YPhi(i);
        part_YPhi_Zit(i,i)=1;
    end
    constraint_pai_3(size(C,2)*Zit+1:(size(C,2)+size(D,2))*Zit,YPhi_PG)=part_YPhi_PG;
    constraint_pai_3(size(C,2)*Zit+1:(size(C,2)+size(D,2))*Zit,YPhi_Zit)=part_YPhi_Zit;    
    constraint_pai_3(size(C,2)*Zit+1:(size(C,2)+size(D,2))*Zit,pai_3_location((j-1)*Zit*size(C,1)+1:j*Zit*size(C,1)))=part_pai_3;
    
    Aeq_constraint_pai_3=[Aeq_constraint_pai_3;constraint_pai_3];
    beq_constraint_pai_3=[beq_constraint_pai_3;sparse(Zit*(size(C,2)+size(D,2)),1)];

end
%% power balance
if(index==1)
Aineq_constraint_pai_4=[];
bineq_constraint_pai_4=[];

Aeq_constraint_pai_4=[];
beq_constraint_pai_4=[];

part_pai_4=[];
YP_PG_part=sparse(size(Aineq_constraint_power_balance,1),length(YP_PG));
Aineq_b=sparse(size(Aineq_constraint_power_balance,1),1);
for i=1:size(Aineq_constraint_power_balance,1)
    part_pai_4=blkdiag(part_pai_4,d');
    PG_part_location=find(Aineq_constraint_power_balance(i,1:N*T)~=0);
    PW_part_location=find(Aineq_constraint_power_balance(i,pwrt_location)~=0);
    if(~isempty(PG_part_location))
       for j=1:length(PG_part_location)
           index_unit_no=ceil(PG_part_location(j)/T);
           index_time_no=mod(PG_part_location(j)-1,T)+1;
           YP_PG_part(i,(index_unit_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+1:...
               (index_unit_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+index_time_no*R)=...
               Aineq_constraint_power_balance(i,PG_part_location(j))*miu_average(1:R*index_time_no)';
       end
    end
    if(~isempty(PW_part_location))
        for j=1:length(PW_part_location)
            index_wind_no=ceil(PW_part_location(j)/T);
            index_time_no=mod(PW_part_location(j)-1,T)+1;
            Aineq_b(i)=Aineq_b(i)+Aineq_constraint_power_balance(i,N*T+PW_part_location(j))*miu_average((index_time_no-1)*R+index_wind_no);
        end
    end
end

Y0_PG_part=Aineq_constraint_power_balance(:,1:N*T);

constraint_pai_4=sparse(size(Aineq_constraint_power_balance,1),total_var_num);
constraint_pai_4(:,Y0_PG)=Y0_PG_part;
constraint_pai_4(:,YP_PG)=YP_PG_part;
constraint_pai_4(:,pai_4_location)=part_pai_4;

Aineq_constraint_pai_4=[Aineq_constraint_pai_4;constraint_pai_4];
bineq_constraint_pai_4=[bineq_constraint_pai_4;bineq_constraint_power_balance-Aineq_b];

%equi
part_pai_4=[];
YP_PG_part=sparse(size(C,2)*size(Aineq_constraint_power_balance,1),length(YP_PG));
Aeq_b=sparse(size(C,2)*size(Aineq_constraint_power_balance,1),1);
for i=1:size(Aineq_constraint_power_balance,1)
    part_pai_4=blkdiag(part_pai_4,C');
    
    PG_part_location=find(Aineq_constraint_power_balance(i,1:N*T)~=0);
    PW_part_location=find(Aineq_constraint_power_balance(i,pwrt_location)~=0);
    if(~isempty(PG_part_location))
       for j=1:length(PG_part_location)
           index_unit_no=ceil(PG_part_location(j)/T);
           index_time_no=mod(PG_part_location(j)-1,T)+1;
           YP_PG_part((i-1)*size(C,2)+1:i*size(C,2),(index_unit_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+1:...
               (index_unit_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+index_time_no*R)=...
               -1*Aineq_constraint_power_balance(i,PG_part_location(j))*repmat(diag_S_1_2(1:R_wan_len),1,index_time_no*R).*V(1:R_wan_len,1:index_time_no*R);
       end
    end
   
    if(~isempty(PW_part_location))
         for j=1:length(PW_part_location)
            index_wind_no=ceil(PW_part_location(j)/T);
            index_time_no=mod(PW_part_location(j)-1,T)+1;
            Aeq_b((i-1)*size(C,2)+1:i*size(C,2))=Aeq_b((i-1)*size(C,2)+1:i*size(C,2))-Aineq_constraint_power_balance(i,pwrt_location(PW_part_location(j)))*diag_S_1_2(1:R_wan_len).*V((index_time_no-1)*R+index_wind_no,1:R_wan_len)';
        end
    end

end
beq_constraint_pai_4=[beq_constraint_pai_4;-1*Aeq_b];
    
constraint_pai_4=sparse((size(C,2)+size(D,2))*size(Aineq_constraint_power_balance,1),total_var_num);
constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance,1),YP_PG)=YP_PG_part;
constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance,1),pai_4_location)=part_pai_4;


part_pai_4=[];
YPhi_PG_part=sparse(size(D,2)*size(Aineq_constraint_power_balance,1),length(YPhi_PG));
for i=1:size(Aineq_constraint_power_balance,1)
    part_pai_4=blkdiag(part_pai_4,D');
    
    PG_part_location=find(Aineq_constraint_power_balance(i,1:N*T)~=0);
     if(~isempty(PG_part_location))
       for j=1:length(PG_part_location)
           index_unit_no=ceil(PG_part_location(j)/T);
           index_time_no=mod(PG_part_location(j)-1,T)+1;
           YPhi_PG_part((i-1)*size(D,2)+1:i*size(D,2),(index_unit_no-1)*R_wan_len*(Lk-1)*T+(index_time_no-1)*R_wan_len*(Lk-1)+1:...
               (index_unit_no-1)*R_wan_len*(Lk-1)*T+index_time_no*R_wan_len*(Lk-1))=...
               -1*Aineq_constraint_power_balance(i,PG_part_location(j))*diag(R_wan_len*(Lk-1));
       end
    end

    b_part_4=sparse(size(D,2),1);
    beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
end

constraint_pai_4(size(C,2)*size(Aineq_constraint_power_balance,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_power_balance,1),YPhi_PG)=YPhi_PG_part;
constraint_pai_4(size(C,2)*size(Aineq_constraint_power_balance,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_power_balance,1),pai_4_location)=part_pai_4;

Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];
end


%% Aineq_constraint_DC_flow 
if(index==2)
Aineq_constraint_pai_4=[];
bineq_constraint_pai_4=[];

Aeq_constraint_pai_4=[];
beq_constraint_pai_4=[];

% upper
% inequi
part_pai_4=[];
YP_PG_part=sparse(size(Aineq_constraint_DC_flow_upper,1),length(YP_PG));
YP_Seita_part=sparse(size(Aineq_constraint_DC_flow_upper,1),length(YP_Seita));
Aineq_b_upper=sparse(size(Aineq_constraint_DC_flow_upper,1),1);
for i=1:size(Aineq_constraint_DC_flow_upper,1)
    part_pai_4=blkdiag(part_pai_4,d');
    PG_part_location=find(Aineq_constraint_DC_flow_upper(i,DC_flow_PGit_location)~=0);
    Seita_part_location=find(Aineq_constraint_DC_flow_upper(i,DC_flow_Seita_it_location)~=0);
    PW_part_location=find(Aineq_constraint_DC_flow_upper(i,DC_flow_PWrt_location)~=0);
    if(~isempty(PG_part_location))
       for j=1:length(PG_part_location)
           index_unit_no=ceil(PG_part_location(j)/T);
           index_time_no=mod(PG_part_location(j)-1,T)+1;
           YP_PG_part(i,(index_unit_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+1:...
               (index_unit_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+index_time_no*R)=miu_average(1:R*index_time_no)';
       end
    end
    if(~isempty(Seita_part_location))
        for j=1:length(Seita_part_location)
           index_bus_no=ceil(Seita_part_location(j)/T);
           index_time_no=mod(Seita_part_location(j)-1,T)+1;
           YP_Seita_part(i,(index_bus_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+1:...
               (index_bus_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+index_time_no*R)=...
               Aineq_constraint_DC_flow_upper(i,DC_flow_Seita_it_location(Seita_part_location(j)))*miu_average(1:R*index_time_no)';
       end
    end
    if(~isempty(PW_part_location))
        for j=1:length(PW_part_location)
            index_wind_no=ceil(PW_part_location(j)/T);
            index_time_no=mod(PW_part_location(j)-1,T)+1;
            Aineq_b_upper(i)=Aineq_b_upper(i)+miu_average((index_time_no-1)*R+index_wind_no);
        end
    end
end

Y0_PG_part=Aineq_constraint_DC_flow_upper(:,DC_flow_PGit_location);
Y0_Seita_part=Aineq_constraint_DC_flow_upper(:,DC_flow_Seita_it_location);


constraint_pai_4=sparse(size(Aineq_constraint_DC_flow_upper,1),total_var_num);
constraint_pai_4(:,Y0_PG)=Y0_PG_part;
constraint_pai_4(:,Y0_Seita)=Y0_Seita_part;
constraint_pai_4(:,YP_PG)=YP_PG_part;
constraint_pai_4(:,YP_Seita)=YP_Seita_part;
constraint_pai_4(:,pai_4_location_upper)=part_pai_4;

Aineq_constraint_pai_4=[Aineq_constraint_pai_4;constraint_pai_4];
bineq_constraint_pai_4=[bineq_constraint_pai_4;bineq_constraint_DC_flow_upper-Aineq_b_upper];

% %equi
part_pai_4=[];
YP_PG_part=sparse(size(C,2)*size(Aineq_constraint_DC_flow_upper,1),length(YP_PG));
YP_Seita_part=sparse(size(C,2)*size(Aineq_constraint_DC_flow_upper,1),length(YP_Seita));
Aeq_b_upper=sparse(size(C,2)*size(Aineq_constraint_DC_flow_upper,1),1);
for i=1:size(Aineq_constraint_DC_flow_upper,1)
    part_pai_4=blkdiag(part_pai_4,C');
    
    PG_part_location=find(Aineq_constraint_DC_flow_upper(i,DC_flow_PGit_location)~=0);
    Seita_part_location=find(Aineq_constraint_DC_flow_upper(i,DC_flow_Seita_it_location)~=0);
    PW_part_location=find(Aineq_constraint_DC_flow_upper(i,DC_flow_PWrt_location)~=0);
    if(~isempty(PG_part_location))
       for j=1:length(PG_part_location)
           index_unit_no=ceil(PG_part_location(j)/T);
           index_time_no=mod(PG_part_location(j)-1,T)+1;
           YP_PG_part((i-1)*size(C,2)+1:i*size(C,2),(index_unit_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+1:...
               (index_unit_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+index_time_no*R)=-1*repmat(diag_S_1_2(1:R_wan_len),1,index_time_no*R).*V(1:R_wan_len,1:index_time_no*R);
       end
    end
    if(~isempty(Seita_part_location))
        for j=1:length(Seita_part_location)
           index_bus_no=ceil(Seita_part_location(j)/T);
           index_time_no=mod(Seita_part_location(j)-1,T)+1;
           YP_Seita_part((i-1)*size(C,2)+1:i*size(C,2),(index_bus_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+1:...
               (index_bus_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+index_time_no*R)=...
               -1*Aineq_constraint_DC_flow_upper(i,DC_flow_Seita_it_location(Seita_part_location(j)))*repmat(diag_S_1_2(1:R_wan_len),1,index_time_no*R).*V(1:R_wan_len,1:index_time_no*R);
       end
    end
    if(~isempty(PW_part_location))
         for j=1:length(PW_part_location)
            index_wind_no=ceil(PW_part_location(j)/T);
            index_time_no=mod(PW_part_location(j)-1,T)+1;
            Aeq_b_upper((i-1)*size(C,2)+1:i*size(C,2))=Aeq_b_upper((i-1)*size(C,2)+1:i*size(C,2))+diag_S_1_2(1:R_wan_len).*V((index_time_no-1)*R+index_wind_no,1:R_wan_len)';
        end
    end
 
end


constraint_pai_4=sparse((size(C,2)+size(D,2))*size(Aineq_constraint_DC_flow_upper,1),total_var_num);
constraint_pai_4(1:size(C,2)*size(Aineq_constraint_DC_flow_upper,1),YP_PG)=YP_PG_part;
constraint_pai_4(1:size(C,2)*size(Aineq_constraint_DC_flow_upper,1),YP_Seita)=YP_Seita_part;
constraint_pai_4(1:size(C,2)*size(Aineq_constraint_DC_flow_upper,1),pai_4_location_upper)=part_pai_4;
beq_constraint_pai_4=[beq_constraint_pai_4;Aeq_b_upper];





part_pai_4=[];
YPhi_PG_part=sparse(size(D,2)*size(Aineq_constraint_DC_flow_upper,1),length(YPhi_PG));
YPhi_Seita_part=sparse(size(D,2)*size(Aineq_constraint_DC_flow_upper,1),length(YPhi_Seita));
for i=1:size(Aineq_constraint_DC_flow_upper,1)
    part_pai_4=blkdiag(part_pai_4,D');
    
    PG_part_location=find(Aineq_constraint_DC_flow_upper(i,DC_flow_PGit_location)~=0);
    Seita_part_location=find(Aineq_constraint_DC_flow_upper(i,DC_flow_Seita_it_location)~=0);
     if(~isempty(PG_part_location))
       for j=1:length(PG_part_location)
           index_unit_no=ceil(PG_part_location(j)/T);
           index_time_no=mod(PG_part_location(j)-1,T)+1;
           YPhi_PG_part((i-1)*size(D,2)+1:i*size(D,2),(index_unit_no-1)*R_wan_len*(Lk-1)*T+(index_time_no-1)*R_wan_len*(Lk-1)+1:...
               (index_unit_no-1)*R_wan_len*(Lk-1)*T+index_time_no*R_wan_len*(Lk-1))=-1*diag(R_wan_len*(Lk-1));
       end
    end
    if(~isempty(Seita_part_location))
        for j=1:length(Seita_part_location)
           index_bus_no=ceil(Seita_part_location(j)/T);
           index_time_no=mod(Seita_part_location(j)-1,T)+1;
           YPhi_Seita_part((i-1)*size(D,2)+1:i*size(D,2),(index_bus_no-1)*R_wan_len*(Lk-1)*T+(index_time_no-1)*R_wan_len*(Lk-1)+1:...
               (index_bus_no-1)*R_wan_len*(Lk-1)*T+index_time_no*R_wan_len*(Lk-1))=...
               -1*Aineq_constraint_DC_flow_upper(i,DC_flow_Seita_it_location(Seita_part_location(j)))*diag(R_wan_len*(Lk-1));
       end
    end
    b_part_4=sparse(size(D,2),1);
    beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
end


constraint_pai_4(size(C,2)*size(Aineq_constraint_DC_flow_upper,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_DC_flow_upper,1),YPhi_PG)=YPhi_PG_part;
constraint_pai_4(size(C,2)*size(Aineq_constraint_DC_flow_upper,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_DC_flow_upper,1),YPhi_Seita)=YPhi_Seita_part;
constraint_pai_4(size(C,2)*size(Aineq_constraint_DC_flow_upper,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_DC_flow_upper,1),pai_4_location_upper)=part_pai_4;

Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];

%down
beq_constraint_pai_4_dowm=-1*beq_constraint_pai_4;
constraint_pai_4_down=sparse((size(C,2)+size(D,2))*size(Aineq_constraint_DC_flow_lower,1),total_var_num);
constraint_pai_4_down(:,YP_PG)=-1*constraint_pai_4(:,YP_PG);
constraint_pai_4_down(:,YP_Seita)=-1*constraint_pai_4(:,YP_Seita);
constraint_pai_4_down(:,pai_4_location_lower)=constraint_pai_4(:,pai_4_location_upper);

Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4_down];
beq_constraint_pai_4=[beq_constraint_pai_4;beq_constraint_pai_4_dowm];

part_pai_4=[];
YP_PG_part=sparse(size(Aineq_constraint_DC_flow_lower,1),length(YP_PG));
YP_Seita_part=sparse(size(Aineq_constraint_DC_flow_lower,1),length(YP_Seita));
Aineq_b_upper=sparse(size(Aineq_constraint_DC_flow_lower,1),1);
for i=1:size(Aineq_constraint_DC_flow_lower,1)
    part_pai_4=blkdiag(part_pai_4,d');
    PG_part_location=find(Aineq_constraint_DC_flow_lower(i,DC_flow_PGit_location)~=0);
    Seita_part_location=find(Aineq_constraint_DC_flow_lower(i,DC_flow_Seita_it_location)~=0);
    PW_part_location=find(Aineq_constraint_DC_flow_lower(i,DC_flow_PWrt_location)~=0);
    if(~isempty(PG_part_location))
       for j=1:length(PG_part_location)
           index_unit_no=ceil(PG_part_location(j)/T);
           index_time_no=mod(PG_part_location(j)-1,T)+1;
           YP_PG_part(i,(index_unit_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+1:...
               (index_unit_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+index_time_no*R)=-1*miu_average(1:R*index_time_no)';
       end
    end
    if(~isempty(Seita_part_location))
        for j=1:length(Seita_part_location)
           index_bus_no=ceil(Seita_part_location(j)/T);
           index_time_no=mod(Seita_part_location(j)-1,T)+1;
           YP_Seita_part(i,(index_bus_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+1:...
               (index_bus_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+index_time_no*R)=...
               Aineq_constraint_DC_flow_lower(i,DC_flow_Seita_it_location(Seita_part_location(j)))*miu_average(1:R*index_time_no)';
       end
    end
    if(~isempty(PW_part_location))
        for j=1:length(PW_part_location)
            index_wind_no=ceil(PW_part_location(j)/T);
            index_time_no=mod(PW_part_location(j)-1,T)+1;
            Aineq_b_upper(i)=Aineq_b_upper(i)+miu_average((index_time_no-1)*R+index_wind_no);
        end
    end
end

Y0_PG_part=Aineq_constraint_DC_flow_lower(:,DC_flow_PGit_location);
Y0_Seita_part=Aineq_constraint_DC_flow_lower(:,DC_flow_Seita_it_location);


constraint_pai_4=sparse(size(Aineq_constraint_DC_flow_lower,1),total_var_num);
constraint_pai_4(:,Y0_PG)=Y0_PG_part;
constraint_pai_4(:,Y0_Seita)=Y0_Seita_part;
constraint_pai_4(:,YP_PG)=YP_PG_part;
constraint_pai_4(:,YP_Seita)=YP_Seita_part;
constraint_pai_4(:,pai_4_location_lower)=part_pai_4;

Aineq_constraint_pai_4=[Aineq_constraint_pai_4;constraint_pai_4];
bineq_constraint_pai_4=[bineq_constraint_pai_4;bineq_constraint_DC_flow_lower+Aineq_b_upper];


% part_pai_4=[];
% YP_PG_part=sparse(size(Aineq_Aeq_DC_flow,1),length(YP_PG));
% YP_Seita_part=sparse(size(Aineq_Aeq_DC_flow,1),length(YP_Seita));
% Aineq_b=sparse(size(Aineq_Aeq_DC_flow,1),1);
% for i=1:size(Aineq_Aeq_DC_flow,1)
%     part_pai_4=blkdiag(part_pai_4,d');
%     PG_part_location=find(Aineq_Aeq_DC_flow(i,DC_flow_PGit_location)~=0);
%     Seita_part_location=find(Aineq_Aeq_DC_flow(i,DC_flow_Seita_it_location)~=0);
%     PW_part_location=find(Aineq_Aeq_DC_flow(i,DC_flow_PWrt_location)~=0);
%     if(~isempty(PG_part_location))
%        for j=1:length(PG_part_location)
%            index_unit_no=ceil(PG_part_location(j)/T);
%            index_time_no=mod(PG_part_location(j)-1,T)+1;
%            YP_PG_part(i,(index_unit_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+1:...
%                (index_unit_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+index_time_no*R)=...
%                Aineq_Aeq_DC_flow(i,DC_flow_PGit_location(PG_part_location(j)))*miu_average(1:R*index_time_no)';
%        end
%     end
%     if(~isempty(Seita_part_location))
%         for j=1:length(Seita_part_location)
%            index_bus_no=ceil(Seita_part_location(j)/T);
%            index_time_no=mod(Seita_part_location(j)-1,T)+1;
%            YP_Seita_part(i,(index_bus_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+1:...
%                (index_bus_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+index_time_no*R)=...
%                Aineq_Aeq_DC_flow(i,DC_flow_Seita_it_location(Seita_part_location(j)))*miu_average(1:R*index_time_no)';
%        end
%     end
%     if(~isempty(PW_part_location))
%         for j=1:length(PW_part_location)
%             index_wind_no=ceil(PW_part_location(j)/T);
%             index_time_no=mod(PW_part_location(j)-1,T)+1;
%             Aineq_b(i)=Aineq_b(i)+Aineq_Aeq_DC_flow(i,DC_flow_PWrt_location(PW_part_location(j)))*miu_average((index_time_no-1)*R+index_wind_no);
%         end
%     end
% end
% 
% Y0_PG_part=Aineq_Aeq_DC_flow(:,DC_flow_PGit_location);
% Y0_Seita_part=Aineq_Aeq_DC_flow(:,DC_flow_Seita_it_location);
% 
% constraint_pai_4=sparse(size(Aineq_Aeq_DC_flow,1),total_var_num);
% constraint_pai_4(:,Y0_PG)=Y0_PG_part;
% constraint_pai_4(:,Y0_Seita)=Y0_Seita_part;
% constraint_pai_4(:,YP_PG)=YP_PG_part;
% constraint_pai_4(:,YP_Seita)=YP_Seita_part;
% constraint_pai_4(:,pai_4_location)=part_pai_4;
% 
% Aineq_constraint_pai_4=[Aineq_constraint_pai_4;constraint_pai_4];
% bineq_constraint_pai_4=[bineq_constraint_pai_4;bineq_Aeq_DC_flow-Aineq_b];
% 
% %equi
% part_pai_4=[];
% YP_PG_part=sparse(size(C,2)*size(Aineq_Aeq_DC_flow,1),length(YP_PG));
% YP_Seita_part=sparse(size(C,2)*size(Aineq_Aeq_DC_flow,1),length(YP_Seita));
% Aeq_b=sparse(size(C,2)*size(Aineq_Aeq_DC_flow,1),1);
% for i=1:size(Aineq_Aeq_DC_flow,1)
%     part_pai_4=blkdiag(part_pai_4,C');
%     
%     PG_part_location=find(Aineq_Aeq_DC_flow(i,DC_flow_PGit_location)~=0);
%     Seita_part_location=find(Aineq_Aeq_DC_flow(i,DC_flow_Seita_it_location)~=0);
%     PW_part_location=find(Aineq_Aeq_DC_flow(i,DC_flow_PWrt_location)~=0);
%     if(~isempty(PG_part_location))
%        for j=1:length(PG_part_location)
%            index_unit_no=ceil(PG_part_location(j)/T);
%            index_time_no=mod(PG_part_location(j)-1,T)+1;
%            YP_PG_part((i-1)*size(C,2)+1:i*size(C,2),(index_unit_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+1:...
%                (index_unit_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+index_time_no*R)=...
%                -1*Aineq_Aeq_DC_flow(i,DC_flow_PGit_location(PG_part_location(j)))*repmat(diag_S_1_2(1:R_wan_len),1,index_time_no*R).*V(1:R_wan_len,1:index_time_no*R);
%        end
%     end
%     if(~isempty(Seita_part_location))
%         for j=1:length(Seita_part_location)
%            index_bus_no=ceil(Seita_part_location(j)/T);
%            index_time_no=mod(Seita_part_location(j)-1,T)+1;
%            YP_Seita_part((i-1)*size(C,2)+1:i*size(C,2),(index_bus_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+1:...
%                (index_bus_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+index_time_no*R)=...
%                -1*Aineq_Aeq_DC_flow(i,DC_flow_Seita_it_location(Seita_part_location(j)))*repmat(diag_S_1_2(1:R_wan_len),1,index_time_no*R).*V(1:R_wan_len,1:index_time_no*R);
%        end
%     end
%     if(~isempty(PW_part_location))
%          for j=1:length(PW_part_location)
%             index_wind_no=ceil(PW_part_location(j)/T);
%             index_time_no=mod(PW_part_location(j)-1,T)+1;
%             Aeq_b((i-1)*size(C,2)+1:i*size(C,2))=Aeq_b((i-1)*size(C,2)+1:i*size(C,2))-Aineq_Aeq_DC_flow(i,DC_flow_PWrt_location(PW_part_location(j)))*diag_S_1_2(1:R_wan_len).*V((index_time_no-1)*R+index_wind_no,1:R_wan_len)';
%         end
%     end
% 
% end
% beq_constraint_pai_4=[beq_constraint_pai_4;-1*Aeq_b];
%     
% constraint_pai_4=sparse((size(C,2)+size(D,2))*size(Aineq_Aeq_DC_flow,1),total_var_num);
% constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DC_flow,1),YP_PG)=YP_PG_part;
% constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DC_flow,1),YP_Seita)=YP_Seita_part;
% constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DC_flow,1),pai_4_location)=part_pai_4;
% 
% 
% part_pai_4=[];
% YPhi_PG_part=sparse(size(D,2)*size(Aineq_Aeq_DC_flow,1),length(YPhi_PG));
% YPhi_Seita_part=sparse(size(D,2)*size(Aineq_Aeq_DC_flow,1),length(YPhi_Seita));
% for i=1:size(Aineq_Aeq_DC_flow,1)
%     part_pai_4=blkdiag(part_pai_4,D');
%     
%     PG_part_location=find(Aineq_Aeq_DC_flow(i,DC_flow_PGit_location)~=0);
%     Seita_part_location=find(Aineq_Aeq_DC_flow(i,DC_flow_Seita_it_location)~=0);
%      if(~isempty(PG_part_location))
%        for j=1:length(PG_part_location)
%            index_unit_no=ceil(PG_part_location(j)/T);
%            index_time_no=mod(PG_part_location(j)-1,T)+1;
%            YPhi_PG_part((i-1)*size(D,2)+1:i*size(D,2),(index_unit_no-1)*R_wan_len*(Lk-1)*T+(index_time_no-1)*R_wan_len*(Lk-1)+1:...
%                (index_unit_no-1)*R_wan_len*(Lk-1)*T+index_time_no*R_wan_len*(Lk-1))=...
%                -1*Aineq_Aeq_DC_flow(i,DC_flow_PGit_location(PG_part_location(j)))*diag(R_wan_len*(Lk-1));
%        end
%     end
%     if(~isempty(Seita_part_location))
%         for j=1:length(Seita_part_location)
%            index_bus_no=ceil(Seita_part_location(j)/T);
%            index_time_no=mod(Seita_part_location(j)-1,T)+1;
%            YPhi_Seita_part((i-1)*size(D,2)+1:i*size(D,2),(index_bus_no-1)*R_wan_len*(Lk-1)*T+(index_time_no-1)*R_wan_len*(Lk-1)+1:...
%                (index_bus_no-1)*R_wan_len*(Lk-1)*T+index_time_no*R_wan_len*(Lk-1))=...
%                -1*Aineq_Aeq_DC_flow(i,DC_flow_Seita_it_location(Seita_part_location(j)))*diag(R_wan_len*(Lk-1));
%        end
%     end
%     b_part_4=sparse(size(D,2),1);
%     beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
% end
% 
% constraint_pai_4(size(C,2)*size(Aineq_Aeq_DC_flow,1)+1:(size(C,2)+size(D,2))*size(Aineq_Aeq_DC_flow,1),YPhi_PG)=YPhi_PG_part;
% constraint_pai_4(size(C,2)*size(Aineq_Aeq_DC_flow,1)+1:(size(C,2)+size(D,2))*size(Aineq_Aeq_DC_flow,1),YPhi_Seita)=YPhi_Seita_part;
% constraint_pai_4(size(C,2)*size(Aineq_Aeq_DC_flow,1)+1:(size(C,2)+size(D,2))*size(Aineq_Aeq_DC_flow,1),pai_4_location)=part_pai_4;
% 
% Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];

% Aineq_DCPowerFlow   %%%
part_pai_4=[];
YP_Seita_part=sparse(size(Aineq_DCPowerFlow,1),length(YP_Seita));
for i=1:size(Aineq_DCPowerFlow,1)
    part_pai_4=blkdiag(part_pai_4,d');
    Seita_part_location=find(Aineq_DCPowerFlow(i,DC_flow_Seita_it_location)~=0);
    if(~isempty(Seita_part_location))
        for j=1:length(Seita_part_location)
           index_bus_no=ceil(Seita_part_location(j)/T);
           index_time_no=mod(Seita_part_location(j)-1,T)+1;
           YP_Seita_part(i,(index_bus_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+1:...
               (index_bus_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+index_time_no*R)=...
               Aineq_DCPowerFlow(i,DC_flow_Seita_it_location(Seita_part_location(j)))*miu_average(1:R*index_time_no)';

       end
    end
end

Y0_Seita_part=Aineq_DCPowerFlow(:,DC_flow_Seita_it_location);


constraint_pai_4=sparse(size(Aineq_DCPowerFlow,1),total_var_num);
constraint_pai_4(:,Y0_Seita)=Y0_Seita_part;
constraint_pai_4(:,YP_Seita)=YP_Seita_part;
constraint_pai_4(:,pai_4_location_seita)=part_pai_4;

Aineq_constraint_pai_4=[Aineq_constraint_pai_4;constraint_pai_4];
bineq_constraint_pai_4=[bineq_constraint_pai_4;bineq_DCPowerFlow];

%equi
part_pai_4=[];
YP_Seita_part=sparse(size(C,2)*size(Aineq_DCPowerFlow,1),length(YP_Seita));
for i=1:size(Aineq_DCPowerFlow,1)
    part_pai_4=blkdiag(part_pai_4,C');
    Seita_part_location=find(Aineq_DCPowerFlow(i,DC_flow_Seita_it_location)~=0);
    if(~isempty(Seita_part_location))
        for j=1:length(Seita_part_location)
           index_bus_no=ceil(Seita_part_location(j)/T);
           index_time_no=mod(Seita_part_location(j)-1,T)+1;
           YP_Seita_part((i-1)*size(C,2)+1:i*size(C,2),(index_bus_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+1:...
               (index_bus_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+index_time_no*R)=...
               -1*Aineq_DCPowerFlow(i,DC_flow_Seita_it_location(Seita_part_location(j)))*repmat(diag_S_1_2(1:R_wan_len),1,index_time_no*R).*V(1:R_wan_len,1:index_time_no*R);
       end
    end

end
beq_constraint_pai_4=[beq_constraint_pai_4;sparse(size(C,2)*size(Aineq_DCPowerFlow,1),1)];

constraint_pai_4=sparse((size(C,2)+size(D,2))*size(Aineq_DCPowerFlow,1),total_var_num);
constraint_pai_4(1:size(C,2)*size(Aineq_DCPowerFlow,1),YP_Seita)=YP_Seita_part;
constraint_pai_4(1:size(C,2)*size(Aineq_DCPowerFlow,1),pai_4_location_seita)=part_pai_4;


part_pai_4=[];
YPhi_Seita_part=sparse(size(D,2)*size(Aineq_DCPowerFlow,1),length(YPhi_Seita));
for i=1:size(Aineq_DCPowerFlow,1)
    part_pai_4=blkdiag(part_pai_4,D');  
    Seita_part_location=find(Aineq_DCPowerFlow(i,DC_flow_Seita_it_location)~=0);
    if(~isempty(Seita_part_location))
        for j=1:length(Seita_part_location)
           index_bus_no=ceil(Seita_part_location(j)/T);
           index_time_no=mod(Seita_part_location(j)-1,T)+1;
           YPhi_Seita_part((i-1)*size(D,2)+1:i*size(D,2),(index_bus_no-1)*R_wan_len*(Lk-1)*T+(index_time_no-1)*R_wan_len*(Lk-1)+1:...
               (index_bus_no-1)*R_wan_len*(Lk-1)*T+index_time_no*R_wan_len*(Lk-1))=...
               -1*Aineq_DCPowerFlow(i,DC_flow_Seita_it_location(Seita_part_location(j)))*diag(R_wan_len*(Lk-1));
       end
    end
    b_part_4=sparse(size(D,2),1);
    beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
end


constraint_pai_4(size(C,2)*size(Aineq_DCPowerFlow,1)+1:(size(C,2)+size(D,2))*size(Aineq_DCPowerFlow,1),YPhi_Seita)=YPhi_Seita_part;
constraint_pai_4(size(C,2)*size(Aineq_DCPowerFlow,1)+1:(size(C,2)+size(D,2))*size(Aineq_DCPowerFlow,1),pai_4_location_seita)=part_pai_4;

Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];
end
%% Aineq_ramp_limt
Aineq_constraint_pai_5=[];
bineq_constraint_pai_5=[];

Aeq_constraint_pai_5=[];
beq_constraint_pai_5=[];

Aineq_constraint_ramp=[Aineq_ramp_limt_up;Aineq_ramp_limt_down];
bineq_constraint_ramp=[bineq_ramp_limt_up;bineq_ramp_limt_down];

part_pai_5=[];
YP_PGit_part=sparse(size(Aineq_constraint_ramp,1),length(YP_PG));
for i=1:size(Aineq_constraint_ramp,1)
    part_pai_5=blkdiag(part_pai_5,d');
    PG_part_location=find(Aineq_constraint_ramp(i,x_num+1:x_num+PGit)~=0);
    if(~isempty(PG_part_location))
        for j=1:length(PG_part_location)
           index_unit_no=ceil(PG_part_location(j)/T);
           index_time_no=mod(PG_part_location(j)-1,T)+1;
           YP_PGit_part(i,(index_unit_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+1:...
               (index_unit_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+index_time_no*R)=...
               Aineq_constraint_ramp(i,x_num+PG_part_location(j))*miu_average(1:R*index_time_no)';
       end
    end
end


constraint_pai_5=sparse(size(Aineq_constraint_ramp,1),total_var_num);
constraint_pai_5(:,x_location)=Aineq_constraint_ramp(:,1:x_num);
constraint_pai_5(:,Y0_PG)=Aineq_constraint_ramp(:,x_num+1:x_num+PGit);
constraint_pai_5(:,YP_PG)=YP_PGit_part;
constraint_pai_5(:,pai_5_location)=part_pai_5;

Aineq_constraint_pai_5=[Aineq_constraint_pai_5;constraint_pai_5];
bineq_constraint_pai_5=[bineq_constraint_pai_5;bineq_constraint_ramp];

%equi
part_pai_5=[];
YP_PGit_part=sparse(size(C,2)*size(Aineq_constraint_ramp,1),length(YP_PG));
Aeq_b=sparse(size(C,2)*size(Aineq_constraint_ramp,1),1);
for i=1:size(Aineq_constraint_ramp,1)
    part_pai_5=blkdiag(part_pai_5,C');
    PGit_part_location=find(Aineq_constraint_ramp(i,x_num+1:x_num+PGit)~=0);
    if(~isempty(PGit_part_location))
        for j=1:length(PGit_part_location)
           index_unit_no=ceil(PGit_part_location(j)/T);
           index_time_no=mod(PGit_part_location(j)-1,T)+1;
           YP_PGit_part((i-1)*size(C,2)+1:i*size(C,2),(index_unit_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+1:...
               (index_unit_no-1)*(0.5*power(T,2)*R+0.5*T*R)+0.5*index_time_no*(index_time_no-1)*R+index_time_no*R)=...
               -1*Aineq_constraint_ramp(i,x_num+PGit_part_location(j))*repmat(diag_S_1_2(1:R_wan_len),1,index_time_no*R).*V(1:R_wan_len,1:index_time_no*R);
       end
    end

end
    beq_constraint_pai_5=[beq_constraint_pai_5;Aeq_b];

constraint_pai_5=sparse((size(C,2)+size(D,2))*size(Aineq_constraint_ramp,1),total_var_num);
constraint_pai_5(1:size(C,2)*size(Aineq_constraint_ramp,1),YP_PG)=YP_PGit_part;
constraint_pai_5(1:size(C,2)*size(Aineq_constraint_ramp,1),pai_5_location)=part_pai_5;


part_pai_5=[];
YPhi_PGit_part=sparse(size(D,2)*size(Aineq_constraint_ramp,1),length(YPhi_PG));
for i=1:size(Aineq_constraint_ramp,1)
    part_pai_5=blkdiag(part_pai_5,D');  
    PG_part_location=find(Aineq_constraint_ramp(i,x_num+1:x_num+PGit)~=0);
    if(~isempty(PG_part_location))
        for j=1:length(PG_part_location)
           index_unit_no=ceil(PG_part_location(j)/T);
           index_time_no=mod(PG_part_location(j)-1,T)+1;
           YPhi_PGit_part((i-1)*size(D,2)+1:i*size(D,2),(index_unit_no-1)*R_wan_len*(Lk-1)*T+(index_time_no-1)*R_wan_len*(Lk-1)+1:...
               (index_unit_no-1)*R_wan_len*(Lk-1)*T+index_time_no*R_wan_len*(Lk-1))=...
               -1*Aineq_constraint_ramp(i,x_num+PG_part_location(j))*diag(R_wan_len*(Lk-1));
       end
    end
    b_part_5=sparse(size(D,2),1);
    beq_constraint_pai_5=[beq_constraint_pai_5;b_part_5];
end


constraint_pai_5(size(C,2)*size(Aineq_constraint_ramp,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_ramp,1),YPhi_PG)=YPhi_PGit_part;
constraint_pai_5(size(C,2)*size(Aineq_constraint_ramp,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_ramp,1),pai_5_location)=part_pai_5;

Aeq_constraint_pai_5=[Aeq_constraint_pai_5;constraint_pai_5];
    
%% test
%uncertain set 
%E(v)=0
%p(v,u in Q)=1
%E(u)<=70


% f=[b;1;70;60;... %x,Eta,gamma,rou
%     0;0;0;... Y0,Yv,Yu
%     sparse(size(C,1)*5,1)]; %pai_1,pai_2,pai_3,pai_4,,pai_5 
% 
% Aineq=[];
% bineq=[];
% Aeq=[];
% beq=[];
% 
% %pai_1
% Aineq=[Aineq;0,-1,0,0,...%x,Eta,gamma,rou
%     3,0,0,...Y0_1,Yv_1,Yu_1
%     d',sparse(1,size(C,1)*4)]; 
% bineq=[bineq;0];
% 
% Aeq=[Aeq;[0,0,0,1;0,0,1,0],...
%     sparse(2,1),[-3;0],[0;-3],...
%     C',sparse(2,size(C,1)*4)];
% beq=[beq;0;0];
% 
% %pai_2
% Aineq=[Aineq;-1*Pmax,0,0,0,...%x,Eta,gamma,rou
%     1,0,0,...Y0_1,Yv_1,Yu_1
%     sparse(1,size(C,1)),d',sparse(1,size(C,1)*3)]; 
% bineq=[bineq;0];
% 
% Aeq=[Aeq;sparse(2,4),...
%     sparse(2,1),[-1;0],[0;-1],...
%     sparse(2,size(C,1)),C',sparse(2,size(C,1)*3)];
% beq=[beq;0;0];
% 
% %pai_3
% Aineq=[Aineq;Pmin,0,0,0,...%x,Eta,gamma,rou
%     -1,0,0,...Y0_1,Yv_1,Yu_1
%     sparse(1,size(C,1)*2),d',sparse(1,size(C,1)*2)]; 
% bineq=[bineq;0];
% 
% Aeq=[Aeq;sparse(2,4),...
%     sparse(2,1),[1;0],[0;1],...
%     sparse(2,size(C,1)*2),C',sparse(2,size(C,1)*2)];
% beq=[beq;0;0];
% 
% 
% %pai_5
% Aineq=[Aineq;0,0,0,0,...%x,Eta,gamma,rou
%     1,0,0,...Y0_1,Yv_1,Yu_1
%     sparse(1,size(C,1)*3),d',sparse(1,size(C,1))]; 
% bineq=[bineq;310];
% 
% Aeq=[Aeq;sparse(2,4),...
%     sparse(2,1),[-1;0],[0;-1],...
%     sparse(2,size(C,1)*3),C',sparse(2,size(C,1))];
% beq=[beq;1;0];
% 
% %pai_6
% Aineq=[Aineq;0,0,0,0,...%Eta,gamma,rou
%     -1,0,0,...Y0_1,Yv_1,Yu_1,
%     sparse(1,size(C,1)*4),d']; 
% bineq=[bineq;-310];
% 
% Aeq=[Aeq;sparse(2,4),...
%     sparse(2,1),[1;0],[0;1],...
%     sparse(2,size(C,1)*4),C'];
% beq=[beq;-1;0];
% 
% % Aeq=[Aeq;sparse(3,4),...
% %     [0,1;0,0;0,0],[0,0;0,1;0,0],[0,0;0,0;0,1],...
% %     sparse(3,size(C,1)*6)];
% % beq=[beq;0;0;0];
% 
% 
% lb=[0;-inf;0;-inf;...
%     -inf*ones(1,1);-inf*ones(1,1);-inf*ones(1,1);...
%      zeros(size(C,1)*5,1)];
% ub=[1;inf;inf;inf;...
%      inf*ones(1,1);inf*ones(1,1);inf*ones(1,1);...
%      inf*ones(size(C,1)*5,1)];
% ctype='';
% ctype(1:length(f))='C';
% ctype(1)='B';
Aineq_two_bin_var_constraint=[Aineq_constraint_min_upordown_time;Aineq_constraint_start_cost];
bineq_two_bin_var_constraint=[bineq_constraint_min_upordown_time;bineq_constraint_start_cost];

Aeq_two_bin_var_constraint=[Aeq_constraints_state;Aeq_constraints_initial_statues];
beq_two_bin_var_constraint=[beq_constraints_state;beq_constraints_initial_statues];

Aineq_two_bin_var=sparse(size(Aineq_two_bin_var_constraint,1),total_var_num);
Aineq_two_bin_var(:,x_location)=Aineq_two_bin_var_constraint;

Aeq_two_bin_var=sparse(size(Aeq_two_bin_var_constraint,1),total_var_num);
Aeq_two_bin_var(:,x_location)=Aeq_two_bin_var_constraint;

Aineq=[Aineq_two_bin_var;Aineq_constraint_pai_1;Aineq_constraint_pai_2;Aineq_constraint_pai_3];%;Aineq_constraint_pai_4;Aineq_constraint_pai_5];%
bineq=[bineq_two_bin_var_constraint;bineq_constraint_pai_1;bineq_constraint_pai_2;bineq_constraint_pai_3];%;bineq_constraint_pai_4;bineq_constraint_pai_5];%
Aeq=[Aeq_two_bin_var;Aeq_constraint_pai_1;Aeq_constraint_pai_2;Aeq_constraint_pai_3];%;Aeq_constraint_pai_4;Aeq_constraint_pai_5];%
beq=[beq_two_bin_var_constraint;beq_constraint_pai_1;beq_constraint_pai_2;beq_constraint_pai_3];%;beq_constraint_pai_4;beq_constraint_pai_5];%


lb=sparse(total_var_num,1);
lb(Eta_location,1)=-inf;
lb(Y0_PG,1)=-inf;
lb(Y0_Zit,1)=-inf;
lb(YP_PG,1)=-inf;
lb(YP_Zit,1)=-inf;
lb(YPhi_PG,1)=-inf;
lb(YPhi_Zit,1)=-inf;
if(index==2)
    lb(Y0_Seita,1)=-inf;
    lb(YP_Seita,1)=-inf;
    lb(YPhi_Seita,1)=-inf;
end

ub=inf*ones(total_var_num,1);
ub(x_uit,1)=1;
ub(x_sit,1)=1;
ub(x_dit,1)=1;

ctype='';
ctype(1:total_var_num)='C';
ctype(1,x_uit)='B';
ctype(1,x_sit)='B';
ctype(1,x_dit)='B';

DRO_model.f=f;
DRO_model.Aeq=Aeq;
DRO_model.beq=beq;
DRO_model.Aineq=Aineq;
DRO_model.bineq=bineq;
DRO_model.lb=lb;
DRO_model.ub=ub;
DRO_model.ctype=ctype;

DRO_model.location.x_uit=x_uit;
DRO_model.location.Eta_location=Eta_location;
DRO_model.location.lambda_location=lambda_location;
DRO_model.location.Y0_PG=Y0_PG;
DRO_model.location.Y0_Zit=Y0_Zit;
DRO_model.location.YP_PG=YP_PG;
DRO_model.location.YP_Zit=YP_Zit;
DRO_model.location.YPhi_PG=YPhi_PG;
DRO_model.location.YPhi_Zit=YPhi_Zit;
DRO_model.location.pai_1_location=pai_1_location;
DRO_model.location.pai_2_location_upper=pai_2_location_upper;
DRO_model.location.pai_2_location_lower=pai_2_location_lower;
DRO_model.location.pai_3_location=pai_3_location;
% DRO_model.location.pai_4_location=pai_4_location;
DRO_model.location.pai_5_location=pai_5_location;
% DRO_model.location.pai_5_location_down=pai_5_location_down;
end

function [eq,ineq]=DC_flow_constraint(NodeNum,N,T,Bus_G,Bus_D,ThPimin,ThPimax,B,bus_P,branchI,branchJ,branchX,branchP,wind_node)
Aeq_constraints_DCPowerFlow=[];
beq_constraints_DCPowerFlow=[];

Aineq_constraints_DCPowerFlow=[];
bineq_constraints_DCPowerFlow=[];

R=length(wind_node);

PG=sparse(1,NodeNum);
PD=sparse(1,NodeNum);
PG(1,Bus_G)=1;
PD(1,Bus_D)=1;

P_index=1;
D_index=1;
for i=1:NodeNum
    if(PG(i)==1&&PD(i)==1)
        P_no=find(i==Bus_G);
        D_no=find(i==Bus_D);
        PW_no=find(i==wind_node);
        
        uit=sparse(T,N*T);
        PitWan=sparse(T,N*T);
        Seita=sparse(T,NodeNum*T);
        
        uit(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag(ThPimin(P_no)*ones(1,T)));
        PitWan(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag((ThPimax(P_no)-ThPimin(P_no))*ones(1,T)));
        coefficient=[];
        for j=1:NodeNum
            coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
        end
        Seita=-1*coefficient;
        
        Pit=sparse(T,N*T);
        Pit(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag(ones(1,T)));
        
        PWrt=sparse(T,R*T);
        if(~isempty(PW_no))
            PWrt=[];
            for t=1:T
                PW_part=sparse(1,R);
                PW_part(1,PW_no)=1;
                PWrt=blkdiag(PWrt,PW_part);
            end
        end
        
        
        Aeq_DCPowerFlow=[sparse(T,4*N*T),Pit,Seita,sparse(T,N*T),PWrt];
        beq_DCPowerFlow=[bus_P(:,D_no)];
        
        Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
        beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
        
        P_index=P_index+1;
        D_index=D_index+1;
    end
    if(PG(i)==1&&PD(i)==0)
        P_no=find(i==Bus_G);
        PW_no=find(i==wind_node);
        
        uit=sparse(T,N*T);
        PitWan=sparse(T,N*T);
        Seita=sparse(T,NodeNum*T);
        
        uit(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag(ThPimin(P_no)*ones(1,T)));
        PitWan(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag((ThPimax(P_no)-ThPimin(P_no))*ones(1,T)));
        coefficient=[];
        for j=1:NodeNum
            coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
        end
        Seita=-1*coefficient;
        
        
        Pit=sparse(T,N*T);
        Pit(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag(ones(1,T)));
        
        PWrt=sparse(T,R*T);
        if(~isempty(PW_no))
            PWrt=[];
            for t=1:T
                PW_part=sparse(1,R);
                PW_part(1,PW_no)=1;
                PWrt=blkdiag(PWrt,PW_part);
            end
        end
        
        Aeq_DCPowerFlow=[sparse(T,4*N*T),Pit,Seita,sparse(T,N*T),PWrt];
        beq_DCPowerFlow=[sparse(T,1)];
        
        Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
        beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
        
        
        P_index=P_index+1;
    end
    if(PG(i)==0&&PD(i)==1)
        
        D_no=find(i==Bus_D);
        PW_no=find(i==wind_node);
        Seita=sparse(T,NodeNum*T);
        coefficient=[];
        for j=1:NodeNum
            coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
        end
        Seita=-1*coefficient;
        
        PWrt=sparse(T,R*T);
        if(~isempty(PW_no))
            PWrt=[];
            for t=1:T
                PW_part=sparse(1,R);
                PW_part(1,PW_no)=1;
                PWrt=blkdiag(PWrt,PW_part);
            end
        end
        
        Aeq_DCPowerFlow=[sparse(T,5*N*T),Seita,sparse(T,N*T),PWrt];
        beq_DCPowerFlow=[bus_P(:,D_no)];
        Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
        beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
        D_index=D_index+1;
    end
    if(PG(i)==0&&PD(i)==0)
        Seita=sparse(T,NodeNum*T);
        PW_no=find(i==wind_node);
        
        coefficient=[];
        for j=1:NodeNum
            coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
        end
        Seita=coefficient;
        
        PWrt=sparse(T,R*T);
        if(~isempty(PW_no))
            PWrt=[];
            for t=1:T
                PW_part=sparse(1,R);
                PW_part(1,PW_no)=1;
                PWrt=blkdiag(PWrt,PW_part);
            end
        end
        
        Aeq_DCPowerFlow=[sparse(T,5*N*T),Seita,sparse(T,N*T),PWrt];
        beq_DCPowerFlow=[sparse(T,1)];
        Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
        beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
    end
    
end

%Seita=0
% Seita=sparse(T,NodeNum*T);
% Seita(:,1:T)=sparse(diag(ones(1,T)));
% Aeq_DCPowerFlow=[sparse(T,5*N*T),Seita,sparse(T,N*T),sparse(T,R*T)];
% beq_DCPowerFlow=[sparse(T,1)];
% Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
% beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];

Aineq_DCPowerFlow=[];
bineq_DCPowerFlow=[];


for index=1:length(branchI)
    Seita_i=branchI(index);
    Seita_j=branchJ(index);
    Seita=sparse(T,NodeNum*T);
    index
    Seita(1:T,(Seita_i-1)*T+1:Seita_i*T)=diag((1/branchX(index))*ones(1,T));
    Seita(1:T,(Seita_j-1)*T+1:Seita_j*T)=diag(-1*(1/branchX(index))*ones(1,T));
    
    Aineq_DCPowerFlow=sparse([Aineq_DCPowerFlow;sparse(T,5*N*T),Seita,sparse(T,N*T),sparse(T,R*T)]);
    bineq_DCPowerFlow=[bineq_DCPowerFlow;branchP(index)*ones(T,1)];
    
    Aineq_DCPowerFlow=sparse([Aineq_DCPowerFlow;sparse(T,5*N*T),-1*Seita,sparse(T,N*T),sparse(T,R*T)]);
    bineq_DCPowerFlow=[bineq_DCPowerFlow;branchP(index)*ones(T,1)];
    
    
end
Aineq_constraints_DCPowerFlow=[Aineq_constraints_DCPowerFlow;Aineq_DCPowerFlow];
bineq_constraints_DCPowerFlow=[bineq_constraints_DCPowerFlow;bineq_DCPowerFlow];


eq.A=Aeq_constraints_DCPowerFlow;
eq.b=beq_constraints_DCPowerFlow;

ineq.A=Aineq_constraints_DCPowerFlow;
ineq.b=bineq_constraints_DCPowerFlow;


end

