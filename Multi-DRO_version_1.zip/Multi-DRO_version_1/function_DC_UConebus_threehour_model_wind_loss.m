function [DRO_model] = function_DC_UConebus_threehour_model_wind_loss(data,data_wind_history,param)
%FUNCTION_BUILD_DROMODEL �˴���ʾ�йش˺�����ժҪ
%   ���׶� ����PCA�ķֲ�³���Ż�
% DC +wind
%����windloss
T=param.T_windows;
%thermal unit
B=data.B(1,1);
Alpha = data.units.alpha;                           %���鷢�纯��ϵ��Alpha--N*1����
Beta = data.units.beta;                             %���鷢�纯��ϵ��Beta--N*1����
Gama = data.units.gamma;                            %���鷢�纯��ϵ��Gama--N*1����
ThPimin = data.units.PG_low;                         %���鷢�繦���½�--N*1����
ThPimax = data.units.PG_up;                          %���鷢�繦���Ͻ�--N*1����
Piup = data.units.ramp;                         %�������¹����Ͻ�--N*1����
Pidown = data.units.ramp;                     %�������¹����Ͻ�--N*1����
Pt = data.totalLoad.PD_T(1:T);                       %�й�����--T*1����
Qt=data.totalLoad.QD_T(1:T);                       %�޹�����--T*1
Bus_G=data.units.bus_G;                           %����ڵ��
N = data.baseparameters.unitN;                 %��������--1*1����
Dt = data.totalLoad.PD_T(1:T);                                 %��������--T*1����
bus_P_factor=data.busLoad.bus_P_factor;           %�ڵ��й���������
bus_Q_factor=data.busLoad.bus_Q_factor;            %�ڵ��޹���������
bus_P=data.busLoad.node_P(1:T,:);
Spin = data.totalLoad.R_T(1:T);                     %��ת�ȱ���--T*1����
ThTime_on_off_init = data.units.U_ini;        %�����ڳ�ʼ״̬ǰ�Ѿ�����/ͣ����ʱ��--N*1����
Thon_off_init =  data.units.PG_up*0.7;               %��������ʼ����--N*1����
ThTime_on_min = data.units.T_on;             %������С����ʱ��--N*1����
ThTime_off_min = data.units.T_off;           %������Сͣ��ʱ��--N*1����
Th_cost_start = data.units.start_cost;           %������������--N*1����
ThCold_cost_start = data.units.start_cost*2;           %����������������--N*1����
ThHot_cost_start = data.units.start_cost;             %����������������--N*1����
Pistartup = data.units.PG_low;      %�����鿪������--N*1����
Pishutdown = data.units.PG_low;      %������ػ�����--N*1����
Ui0 = full(spones(Thon_off_init));                                  %����������ʼ��/ͣ��״̬
Ui = max(0,min(ones(N,1) * T,Ui0 .* (ThTime_on_min - ThTime_on_off_init)));                    %--N*1����
Li = max(0,min(ones(N,1) * T,(ones(N,1) - Ui0) .* (ThTime_off_min + ThTime_on_off_init)));     %--N*1����
ThCold_time_start=min(max(2*ThTime_off_min,1),T);
L=4;
LossCost=param.LossCost;
%net
NodeNum=1;
branchI=data.branch.I;
branchJ=data.branch.J;
branchR=data.branch.R;
branchX=data.branch.X;
branchP=data.branch.P;
branchB=data.branch.B;
branchGroundI=0;
branchGroundB=0;
branchTransformerI=data.branchTransformer.I;
branchTransformerJ=data.branchTransformer.J;
branchTransformerR=data.branchTransformer.R;
branchTransformerX=data.branchTransformer.X;
branchTransformerK=data.branchTransformer.K;
branchTransformerP=data.branchTransformer.P;

All_branchI=[branchI;branchTransformerI];
All_branchJ=[branchJ;branchTransformerJ];
All_branchP=[branchP;branchTransformerP];
bus_PDQR=data.busLoad.bus_PDQR;
bus_G=1;
%Wind unit
wind_Node=[1]; 
R=1;

for i=1:R
    M(i)=length(data_wind_history{i});
end
M_min=min(M);
data_wind=[];
%P_w(1,1) P_w(2,1) P_w(3,1)...
for t=1:T
    data_wind_part=[];
    for i=1:R
        data_wind_part=[data_wind_part;data_wind_history{i}(t,1:M_min)];
    end
    data_wind=[data_wind;data_wind_part];
end

P_Wind_Max=max(data_wind,[],2);
P_Wind_Min=min(data_wind,[],2);
miu_average=mean(data_wind,2);

%% uit,sit,dit,Sit_wan,PGit,Seitait,Zit
% x
uit_num=3;
x_num=uit_num;

%continuous variables and some auxiliary variables
PGit_num=3;
PWrt_num=3;
LoadLoss_num=3;
y_num=PGit_num+PWrt_num+LoadLoss_num;

%location
%x
total_num=0;
uit_location=1:uit_num;
total_num=total_num+length(uit_location);

%y
PGit_location=total_num+1:total_num+PGit_num;
PGit_in_y_location=1:PGit_num;
total_num=total_num+length(PGit_location);

PWrt_location=total_num+1:total_num+PWrt_num;
PWrt_in_y_location=PGit_num+1:PGit_num+PWrt_num;
total_num=total_num+length(PWrt_location);

LoadLoss_location=total_num+1:total_num+LoadLoss_num;
LoadLoss_in_y_location=PGit_num+PWrt_num+1:PGit_num+PWrt_num+LoadLoss_num;
total_num=total_num+length(LoadLoss_location);

y_location=[PGit_location,PWrt_location,LoadLoss_location];

N=1;
%% Constraints with uncertain
% uit=sparse(1,N*T);
% sit=sparse(1,N*T);
% dit=sparse(1,N*T);
% Sit=sparse(1,N*T);
% PGit=sparse(1,N*T);
% Seitait=sparse(1,NodeNum*T);
% Zit=sparse(1,N*T);
%ramping limit

Aineq_genration_limit=[];
bineq_genration_limit=[];

Aineq_genration_limit_upper=[];
bineq_genration_limit_upper=[];
Aineq_genration_limit_lower=[];
bineq_genration_limit_lower=[];
for i=1:1
    
    %generation limit
    %u_(i,t) P_min��P_(i,t)^G��u_(i,t) P_max

    
    %uit*Pmin<=Pit
    constraint_genration_limit=sparse(T,x_num+y_num);
    constraint_genration_limit(:,(i-1)*T+1:(i-1)*T+T)=sparse(diag(ThPimin(i)*ones(T,1)));%uit
    constraint_genration_limit(:,N*T+(i-1)*T+1:N*T+(i-1)*T+T)=sparse(diag(-1*ones(T,1)));%pit
    Aineq_genration_limit=[Aineq_genration_limit;constraint_genration_limit];
    bineq_genration_limit=[bineq_genration_limit;sparse(T,1)];
    Aineq_genration_limit_upper=[Aineq_genration_limit_upper;constraint_genration_limit];
    bineq_genration_limit_upper=[bineq_genration_limit_upper;sparse(T,1)];
    %uit*Pmax>=Pit
    constraint_genration_limit=sparse(T,x_num+y_num);
    constraint_genration_limit(:,(i-1)*T+1:(i-1)*T+T)=sparse(diag(-1*ThPimax(i)*ones(T,1)));%uit
    constraint_genration_limit(:,N*T+(i-1)*T+1:N*T+(i-1)*T+T)=sparse(diag(ones(T,1)));%pit
    Aineq_genration_limit=[Aineq_genration_limit;constraint_genration_limit];
    bineq_genration_limit=[bineq_genration_limit;sparse(T,1)];
    Aineq_genration_limit_lower=[Aineq_genration_limit_lower;constraint_genration_limit];
    bineq_genration_limit_lower=[bineq_genration_limit_lower;sparse(T,1)];
end


%DC
[eq_DCPowerFlow,ineq_DCPowerFlow]=DC_flow_constraint(NodeNum,N,T,[1],[1],ThPimin(1),ThPimax(1),B,bus_P(:,1),1,1,0,0,wind_Node);
Aeq_DCPowerFlow=eq_DCPowerFlow.A;
beq_DCPowerFlow=eq_DCPowerFlow.b;
Aineq_DCPowerFlow=ineq_DCPowerFlow.A;
bineq_DCPowerFlow=ineq_DCPowerFlow.b;

Aineq_DCPowerFlow_upper=Aeq_DCPowerFlow;
bineq_DCPowerFlow_upper=beq_DCPowerFlow;
Aineq_DCPowerFlow_lower=-1*Aeq_DCPowerFlow;
bineq_DCPowerFlow_lower=-1*beq_DCPowerFlow;

Aineq_Aeq_DCPowerFlow=[Aineq_DCPowerFlow_upper;Aineq_DCPowerFlow_lower;Aineq_DCPowerFlow];
bineq_Aeq_DCPowerFlow=[bineq_DCPowerFlow_upper;bineq_DCPowerFlow_lower;bineq_DCPowerFlow];

%% Wind loss
Aineq_LoadLoss_constraint=[];
bineq_LoadLoss_constraint=[];
Aineq_LoadLoss_constraint=[Aineq_LoadLoss_constraint;sparse(3,3),sparse(3,3),...
    sparse(3,3),-1*diag(ones(1,3))];
bineq_LoadLoss_constraint=[bineq_LoadLoss_constraint;0*ones(3,1)];%sparse(R*T,1)


PWrt=[];
for i=1:1
    PWrt_part=[];
    for j=1:3
        part=sparse(1,1);
        part(1,i)=-1;
        PWrt_part=blkdiag(PWrt_part,part);
    end
    PWrt=[PWrt;PWrt_part];
end
Aineq_LoadLoss_constraint=[Aineq_LoadLoss_constraint;sparse(3,3),sparse(3,3),PWrt,diag(ones(1,3))];%diag(ones(1,R*T)) sparse(R*T,R*T)
bineq_LoadLoss_constraint=[bineq_LoadLoss_constraint;0*ones(3,1)];%sparse



%% objective function

% first-order uit sit dit Sit  
f_uit=[Alpha(1)*ones(3,1)];

f=[f_uit;Beta(1)*ones(3,1);sparse(3,1);LossCost*ones(3,1)];% PGit(N*T) Setait(NodeNum*T) Zit(N*T)



%% DRO model


Aeq=[Aeq_DCPowerFlow];
beq=[beq_DCPowerFlow];
Aineq=[Aineq_genration_limit;Aineq_DCPowerFlow;Aineq_LoadLoss_constraint];
bineq=[bineq_genration_limit;bineq_DCPowerFlow;bineq_LoadLoss_constraint];
lb=[sparse(3,1);0*ones((1)*3,1);miu_average;sparse(3,1)];%data_wind(:,1)
ub=[ones(3,1);inf*ones(3,1);miu_average;inf*ones(3,1)];%data_wind(:,1)
ctype='';
ctype(1:3)='B';
ctype(3+1:size(ub,1))='C';

DRO_model.f=f;
DRO_model.Aeq=Aeq;
DRO_model.beq=beq;
DRO_model.Aineq=Aineq;
DRO_model.bineq=bineq;
DRO_model.lb=lb;
DRO_model.ub=ub;
DRO_model.ctype=ctype;


DRO_model.Aeq_y=[Aeq_DCPowerFlow];%
DRO_model.beq_y=[beq_DCPowerFlow];%
DRO_model.Aineq_y=[Aineq_genration_limit;Aineq_DCPowerFlow];%
DRO_model.bineq_y=[bineq_genration_limit;bineq_DCPowerFlow];%
DRO_model.Aineq_DCPowerFlow=Aineq_DCPowerFlow;
DRO_model.bineq_DCPowerFlow=bineq_DCPowerFlow;
DRO_model.Aeq_DCPowerFlow=Aeq_DCPowerFlow;
DRO_model.beq_DCPowerFlow=beq_DCPowerFlow;

DRO_model.Aineq_constraint_genration_limit_upper=Aineq_genration_limit_upper;
DRO_model.bineq_constraint_genration_limit_upper=bineq_genration_limit_upper;
DRO_model.Aineq_constraint_genration_limit_lower=Aineq_genration_limit_lower;
DRO_model.bineq_constraint_genration_limit_lower=bineq_genration_limit_lower;

DRO_model.Aineq_constraint_DCPowerFlow=Aineq_Aeq_DCPowerFlow;
DRO_model.bineq_constraint_DCPowerFlow=bineq_Aeq_DCPowerFlow;


DRO_model.Aineq_LoadLoss_constraint=Aineq_LoadLoss_constraint;
DRO_model.bineq_LoadLoss_constraint=bineq_LoadLoss_constraint;

DRO_model.uit_location=uit_location;


DRO_model.PGit_location=PGit_location;
DRO_model.PWrt_location=PWrt_location;
DRO_model.windLoss_location=LoadLoss_location;

end

function [eq,ineq]=DC_flow_constraint(NodeNum,N,T,Bus_G,Bus_D,ThPimin,ThPimax,B,bus_P,branchI,branchJ,branchX,branchP,wind_node)
Aeq_constraints_DCPowerFlow=[];
beq_constraints_DCPowerFlow=[];

Aineq_constraints_DCPowerFlow=[];
bineq_constraints_DCPowerFlow=[];

R=1;

PG=sparse(1,NodeNum);
PD=sparse(1,NodeNum);
PG(1,Bus_G)=1;
PD(1,Bus_D)=1;

P_index=1;
D_index=1;
for i=1:1
    if(PG(i)==1&&PD(i)==1)
        P_no=find(i==Bus_G);
        D_no=find(i==Bus_D);
        PW_no=find(i==wind_node);
        
        uit=sparse(T,N*T);
        PitWan=sparse(T,N*T);
        
        uit(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag(ThPimin(P_no)*ones(1,T)));
        PitWan(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag((ThPimax(P_no)-ThPimin(P_no))*ones(1,T)));
        coefficient=[];
        for j=1:NodeNum
            coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
        end
        
        Pit=sparse(T,N*T);
        Pit(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag(ones(1,T)));
        
        PWrt=sparse(T,R*T);
        LoadLoss=sparse(T,R*T);
        if(~isempty(PW_no))
            PWrt=[];
            LoadLoss(:,(PW_no-1)*T+1:PW_no*T)=-1*diag(ones(1,T));
            for t=1:T
                PW_part=sparse(1,R);
                
                PW_part(1,PW_no)=1;
                
                PWrt=blkdiag(PWrt,PW_part);
            end
        end
        
        
        Aeq_DCPowerFlow=[sparse(T,N*T),Pit,PWrt,LoadLoss];
        beq_DCPowerFlow=[bus_P(:,D_no)*7];
        
        Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
        beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
        
        P_index=P_index+1;
        D_index=D_index+1;
    end
    if(PG(i)==1&&PD(i)==0)
        P_no=find(i==Bus_G);
        PW_no=find(i==wind_node);
        
        uit=sparse(T,N*T);
        PitWan=sparse(T,N*T);
        Seita=sparse(T,NodeNum*T);
        
        coefficient=[];
        for j=1:NodeNum
            coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
        end
        Seita=-1*coefficient;
        
        
        Pit=sparse(T,N*T);
        Pit(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag(ones(1,T)));
        
        PWrt=sparse(T,R*T);
        LoadLoss=sparse(T,R*T);
        if(~isempty(PW_no))
            PWrt=[];
            LoadLoss(:,(PW_no-1)*T+1:PW_no*T)=-1*diag(ones(1,T));
            for t=1:T
                PW_part=sparse(1,R);
                
                PW_part(1,PW_no)=1;
                
                PWrt=blkdiag(PWrt,PW_part);
            end
        end
        
        Aeq_DCPowerFlow=[sparse(T,4*N*T),Pit,Seita,sparse(T,N*T),PWrt,LoadLoss];
        beq_DCPowerFlow=[sparse(T,1)];
        
        Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
        beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
        
        
        P_index=P_index+1;
    end
    if(PG(i)==0&&PD(i)==1)

        D_no=find(i==Bus_D);
        PW_no=find(i==wind_node);
        Seita=sparse(T,NodeNum*T);
        coefficient=[];
        for j=1:NodeNum
            coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
        end
        Seita=-1*coefficient;
        
        PWrt=sparse(T,R*T);
        LoadLoss=sparse(T,R*T);
        if(~isempty(PW_no))
            PWrt=[];
            LoadLoss(:,(PW_no-1)*T+1:PW_no*T)=-1*diag(ones(1,T));
            for t=1:T
                PW_part=sparse(1,R);
                
                PW_part(1,PW_no)=1;
                
                PWrt=blkdiag(PWrt,PW_part);
            end
        end
        
        Aeq_DCPowerFlow=[sparse(T,5*N*T),Seita,sparse(T,N*T),PWrt,LoadLoss];
        beq_DCPowerFlow=[bus_P(:,D_no)];
                Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
        beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
        D_index=D_index+1;
    end
    if(PG(i)==0&&PD(i)==0)
        Seita=sparse(T,NodeNum*T);
        PW_no=find(i==wind_node);
        
        coefficient=[];
        for j=1:NodeNum
            coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
        end
        Seita=coefficient;
        
        PWrt=sparse(T,R*T);
        LoadLoss=sparse(T,R*T);
        if(~isempty(PW_no))
            PWrt=[];
            LoadLoss(:,(PW_no-1)*T+1:PW_no*T)=-1*diag(ones(1,T));
            for t=1:T
                PW_part=sparse(1,R);
                
                PW_part(1,PW_no)=1;
                
                PWrt=blkdiag(PWrt,PW_part);
            end
        end
        
        Aeq_DCPowerFlow=[sparse(T,5*N*T),Seita,sparse(T,N*T),PWrt,LoadLoss];
        beq_DCPowerFlow=[sparse(T,1)];
         Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
        beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
    end
    
end

%Seita=0
% Seita=sparse(T,NodeNum*T);
% Seita(:,1:T)=sparse(diag(ones(1,T)));
% Aeq_DCPowerFlow=[sparse(T,5*N*T),Seita,sparse(T,N*T),sparse(T,R*T)];
% beq_DCPowerFlow=[sparse(T,1)];
% Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
% beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];


eq.A=Aeq_constraints_DCPowerFlow;
eq.b=beq_constraints_DCPowerFlow;

ineq.A=Aineq_constraints_DCPowerFlow;
ineq.b=bineq_constraints_DCPowerFlow;


end