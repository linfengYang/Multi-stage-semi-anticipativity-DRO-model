function [model] = function_construct_DRO_MILP_model(UC_model,data,data_wind_history,param)
%FUNCTION_BUILD_DROMODEL �˴���ʾ�йش˺�����ժҪ
%   ���׶� ����PCA�ķֲ�³���Ż�
% DC +wind

%thermal unit
N = data.baseparameters.unitN;                 %��������--1*1����
T = param.T_windows;                          %ʱ�����--1*1����
ThHot_cost_start = data.units.start_cost;             %����������������--N*1����
NodeNum=data.baseparameters.busN;
PWnode=data.Wind.wind_Node;
rho = param.rho;
gap_pri = param.gap_pri;
gap_dual =param.gap_dual;

bool_partition=param.partition;
T_wan=param.T_wan;
T_windows=param.T_windows;

% PI=param.PI;
% allNodes=param.allNodes;
% PINumber=param.PINumber;

T=T_windows;


%partition




%%

R=length(PWnode);
Lk=3;
rou=1e-3;
%Wind unit
for i=1:R
    M(i)=length(data_wind_history{i});
end
M_min=min(M);
data_wind=[];
%P_w(1,1) P_w(2,1) P_w(3,1)...
for t=1:T
    data_wind_part=[];
    for i=1:R
        data_wind_part=[data_wind_part;data_wind_history{i}(t,1:M_min)];
    end
    if(bool_partition==1)
        data_wind_part=sum(data_wind_part,1);
    end
    data_wind=[data_wind;data_wind_part];
end

P_Wind_Max=max(data_wind,[],2);
P_Wind_Min=min(data_wind,[],2);
miu_average=mean(data_wind,2);
covariance=cov(data_wind');
[U,S,V] = svd (covariance);
diag_S=diag(S);
diag_S_1_2=power(diag_S,0.5);
mean_S=mean(diag_S);
S_log=floor(log10(mean_S));
R_wan=0;
if(param.PCA==0)
    R_wan=find(log10(diag_S)>S_log);
    R_wan_len=length(R_wan);
else
    R_wan=[1:param.PCA];
    R_wan_len=length(R_wan);
end
if(bool_partition==1)
    R=1;
else
    R=length(PWnode);
end
P_wan=(U(:,R_wan)*((S(R_wan,R_wan))^0.5)^(-1))'*(data_wind-repmat(miu_average,1,M_min));
P_wind_PCA=(U(:,R_wan)*((S(R_wan,R_wan))^0.5))*P_wan+repmat(miu_average,1,M_min);
% data_wind_1=data_wind(1:2:end,1);
% data_wind_wan_1=P_wind(1:2:end,1);
P_wan_Wind_Max=max(P_wan,[],2);
P_wan_Wind_Min=min(P_wan,[],2);

Ckl=repmat(P_wan_Wind_Min,1,Lk)+...
    repmat((P_wan_Wind_Max-P_wan_Wind_Min),1,Lk).*...
    repmat(([1:Lk]/Lk),R_wan_len,1);
gamma_R_T_L=[];

for j=1:Lk-1
    gamma_R_T_L=[gamma_R_T_L,mean(max(P_wan-repmat(Ckl(:,j),1,M_min),0),2)+rou*ones(R_wan_len,1)];
end
gamma_k_l=gamma_R_T_L;
%% uit,sit,dit,Sit_wan,PGit,Seitait,Zit,PWrt
% x
x_num=0;
uit_num=N*T;
sit_num=N*T;
dit_num=N*T;
Sit_num=N*T;
x_num=uit_num+sit_num+dit_num+Sit_num;

%other variables
PGit_num=N*T;
Seitait_num=NodeNum*T;
Zit_num=N*T;
PWrt_num=R*T;

if(param.windLoss==1)
    windLoss_num=R*T;
    y_num=PGit_num+Seitait_num+Zit_num+PWrt_num+windLoss_num;
else
    y_num=PGit_num+Seitait_num+Zit_num+PWrt_num;
end
y_location=x_num+1:x_num+y_num;
%location
%x
total_num=0;
uit_location=1:uit_num;
total_num=total_num+length(uit_location);

sit_location=total_num+1:total_num+sit_num;
total_num=total_num+length(sit_location);

dit_location=total_num+1:total_num+dit_num;
total_num=total_num+length(dit_location);

Sit_location=total_num+1:total_num+Sit_num;
total_num=total_num+length(Sit_location);
%y
PGit_location=total_num+1:total_num+PGit_num;
PGit_in_y_location=1:PGit_num;
total_num=total_num+length(PGit_location);

Seitait_location=total_num+1:total_num+Seitait_num;
Seitait_in_y_location=1+PGit_num:PGit_num+Seitait_num;
total_num=total_num+length(Seitait_location);

Zit_location=total_num+1:total_num+Zit_num;
Zit_in_y_location=1+PGit_num+Seitait_num:PGit_num+Seitait_num+Zit_num;
total_num=total_num+length(Zit_location);

PWrt_location=total_num+1:total_num+PWrt_num;
PWrt_in_y_location=PGit_num+Seitait_num+Zit_num+1:PGit_num+Seitait_num+Zit_num+PWrt_num;
total_num=total_num+length(PWrt_location);

if(param.windLoss==1)
    windLoss_location=total_num+1:total_num+windLoss_num;
    windLoss_in_y_location=PGit_num+Seitait_num+Zit_num+PWrt_num+1:PGit_num+Seitait_num+Zit_num+PWrt_num+windLoss_num;
    total_num=total_num+length(windLoss_location);
end

%% Constraints without uncertain

Aeq_constraints_state=UC_model.Aeq_constraints_state;
beq_constraints_state=UC_model.beq_constraints_state;


%% initial status

Aeq_constraints_initial_statues=[UC_model.Aeq_constraints_initial_statues];
beq_constraints_initial_statues=[UC_model.beq_constraints_initial_statues];


%% start_cost_constraint

Aineq_constraint_start_cost=[UC_model.Aineq_constraint_start_cost];
bineq_constraint_start_cost=UC_model.bineq_constraint_start_cost;


%% minim up/down time constraint

Aineq_constraint_min_upordown_time=[UC_model.Aineq_constraint_min_upordown_time];
bineq_constraint_min_upordown_time=[UC_model.bineq_constraint_min_upordown_time];

%% Constraints with uncertain
% uit=sparse(1,N*T);
% sit=sparse(1,N*T);
% dit=sparse(1,N*T);
% Sit=sparse(1,N*T);
% PGit=sparse(1,N*T);
% Seitait=sparse(1,NodeNum*T);
% Zit=sparse(1,N*T);
%ramping limit
Aineq_ramp_limt=[UC_model.Aineq_constraint_ramp_limt_up;UC_model.Aineq_constraint_ramp_limt_down];
bineq_ramp_limt=[UC_model.bineq_constraint_ramp_limt_up;UC_model.bineq_constraint_ramp_limt_down];
Aineq_genration_limit=[UC_model.Aineq_constraint_genration_limit_upper;UC_model.Aineq_constraint_genration_limit_lower];
bineq_genration_limit=[UC_model.bineq_constraint_genration_limit_upper;UC_model.bineq_constraint_genration_limit_lower];

Aineq_ramp_limt_up=[UC_model.Aineq_constraint_ramp_limt_up];
bineq_ramp_limt_up=[UC_model.bineq_constraint_ramp_limt_up];
Aineq_ramp_limt_down=[UC_model.Aineq_constraint_ramp_limt_down];
bineq_ramp_limt_down=[UC_model.bineq_constraint_ramp_limt_down];

Aineq_genration_limit_upper=[UC_model.Aineq_constraint_genration_limit_upper];
bineq_genration_limit_upper=[UC_model.bineq_constraint_genration_limit_upper];
Aineq_genration_limit_lower=[UC_model.Aineq_constraint_genration_limit_lower];
bineq_genration_limit_lower=[UC_model.bineq_constraint_genration_limit_lower];




% Aineq_ramp_limt=[];
% bineq_ramp_limt=[];
% Aineq_genration_limit=[];
% bineq_genration_limit=[];

% Aineq_ramp_limt_up=[];
% bineq_ramp_limt_up=[];
% Aineq_ramp_limt_down=[];
% bineq_ramp_limt_down=[];
%
% Aineq_genration_limit_upper=[];
% bineq_genration_limit_upper=[];
% Aineq_genration_limit_lower=[];
% bineq_genration_limit_lower=[];


%%

%DC
% Aeq_DCPowerFlow=UC_model.Aeq_DCPowerFlow;
% beq_DCPowerFlow=UC_model.beq_DCPowerFlow;

% Aineq_DCPowerFlow_upper=Aeq_DCPowerFlow;
% bineq_DCPowerFlow_upper=beq_DCPowerFlow;
% Aineq_DCPowerFlow_lower=-1*Aeq_DCPowerFlow;
% bineq_DCPowerFlow_lower=-1*beq_DCPowerFlow;

if(param.eq==1)
Aineq_Aeq_DCPowerFlow=[UC_model.Aineq_DCPowerFlow];
bineq_Aeq_DCPowerFlow=[UC_model.bineq_DCPowerFlow];
else
    Aineq_Aeq_DCPowerFlow=[UC_model.Aineq_constraint_DCPowerFlow];
    bineq_Aeq_DCPowerFlow=[UC_model.bineq_constraint_DCPowerFlow];
end

%%

%objective function linear approximation
Aineq_linear_approximation=[UC_model.Aineq_constraint_linear_approximation];
bineq_linear_approximation=[UC_model.bineq_constraint_linear_approximation];

% Aineq_linear_approximation=[];
% bineq_linear_approximation=[];
%% 
Aineq_windLoss_constraint=[UC_model.Aineq_LoadLoss_constraint];
bineq_windLoss_constraint=[UC_model.bineq_LoadLoss_constraint];
%% DRO
%uncertain set

%E(u)<=gamma
%p(Pw,u in Q)=1

%Pw_min<=Pw<=Pw_max
%max{v,0}<=u

C=[];
D=[];
d=[];

%P_wind<=P_wind_max
C=[C;sparse(diag(ones(R_wan_len,1)))];
D=[D;sparse(R_wan_len,R_wan_len*(Lk-1))];
d=[d;P_wan_Wind_Max];

%-P_wind<=-P_wind_min
C=[C;sparse(diag(-1*ones(R_wan_len,1)))];
D=[D;sparse(R_wan_len,R_wan_len*(Lk-1))];
d=[d;-1*P_wan_Wind_Min];

%-phi<=0
C=[C;sparse(R_wan_len*(Lk-1),R_wan_len)];
D=[D;sparse(diag(-1*ones(R_wan_len*(Lk-1),1)))];
d=[d;sparse(R_wan_len*(Lk-1),1)];

% P_wind>=0
C=[C;-1*U(:,R_wan)*power(S(R_wan,R_wan),0.5)];
D=[D;sparse(R*T,R_wan_len*(Lk-1))];
d=[d;miu_average];

%P_wind_r_t - phi_r,t,l <=Cr,t,l
for i=1:R_wan_len
    C_part=sparse(Lk-1,R_wan_len);
    D_part=sparse(Lk-1,R_wan_len*(Lk-1));
    
    C_part(:,i)=1;
    D_part(:,(i-1)*(Lk-1)+1:i*(Lk-1))=sparse(diag(-1*ones((Lk-1),1)));
    
    C=[C;C_part];
    D=[D;D_part];
    
    d=[d;Ckl(i,1:Lk-1)'];
end

%%

DRO_total_var_num=0;
Y0_num=0;
YP_num=0;
YPhi_num=0;

x_location=1:x_num;
DRO_total_var_num=DRO_total_var_num+length(x_location);

Eta_location=DRO_total_var_num+1;
DRO_total_var_num=DRO_total_var_num+length(Eta_location);

lambda_location=DRO_total_var_num+1:DRO_total_var_num+R_wan_len*(Lk-1);
DRO_total_var_num=DRO_total_var_num+length(lambda_location);

Y0_PG=DRO_total_var_num+1:DRO_total_var_num+PGit_num;
DRO_total_var_num=DRO_total_var_num+length(Y0_PG);
PG_in_Y0=Y0_num+1:Y0_num+length(Y0_PG);
Y0_num=length(Y0_PG)+Y0_num;

Y0_Seita=DRO_total_var_num+1:DRO_total_var_num+Seitait_num;
DRO_total_var_num=DRO_total_var_num+length(Y0_Seita);
Seita_in_Y0=Y0_num+1:Y0_num+length(Y0_Seita);
Y0_num=length(Y0_Seita)+Y0_num;

Y0_Zit=DRO_total_var_num+1:DRO_total_var_num+Zit_num;
DRO_total_var_num=DRO_total_var_num+length(Y0_Zit);
Zit_in_Y0=Y0_num+1:Y0_num+length(Y0_Zit);
Y0_num=length(Y0_Zit)+Y0_num;

if(param.windLoss==1) 
    Y0_windLoss=DRO_total_var_num+1:DRO_total_var_num+windLoss_num;
    DRO_total_var_num=DRO_total_var_num+length(Y0_windLoss);
    windLoss_in_Y0=Y0_num+1:Y0_num+length(Y0_windLoss);
    Y0_num=length(Y0_windLoss)+Y0_num;
end

if(param.windLoss==1)
    Y0_location=[Y0_PG,Y0_Seita,Y0_Zit,Y0_windLoss];
else
    Y0_location=[Y0_PG,Y0_Seita,Y0_Zit];
end

if(T_wan<T)
    YP_PG=DRO_total_var_num+1:...
        DRO_total_var_num+N*(R*T_wan+0.5*T_wan*(T_wan-1)*R+(T-T_wan)*T_wan*R);
    DRO_total_var_num=DRO_total_var_num+length(YP_PG);
    PG_in_YP=YP_num+1:YP_num+length(YP_PG);
    YP_num=YP_num+length(YP_PG);
    
    YP_Seita=DRO_total_var_num+1:...
        DRO_total_var_num+NodeNum*(R*T_wan+0.5*T_wan*(T_wan-1)*R+(T-T_wan)*T_wan*R);
    DRO_total_var_num=DRO_total_var_num+length(YP_Seita);
    Seita_in_YP=YP_num+1:YP_num+length(YP_Seita);
    YP_num=YP_num+length(YP_Seita);
    
    YP_Zit=DRO_total_var_num+1:...
        DRO_total_var_num+N*(R*T_wan+0.5*T_wan*(T_wan-1)*R+(T-T_wan)*T_wan*R);
    DRO_total_var_num=DRO_total_var_num+length(YP_Zit);
    Zit_in_YP=YP_num+1:YP_num+length(YP_Zit);
    YP_num=YP_num+length(YP_Zit);
    
%     YP_LoadLoss=DRO_total_var_num+1:...
%         DRO_total_var_num+R*(R*T_wan+0.5*T_wan*(T_wan-1)*R+(T-T_wan)*T_wan*R);
%     DRO_total_var_num=DRO_total_var_num+length(YP_LoadLoss);
%     LoadLoss_in_YP=YP_num+1:YP_num+length(YP_LoadLoss);
%     YP_num=YP_num+length(YP_LoadLoss);
    
if(param.windLoss==1)
    YP_windLoss=DRO_total_var_num+1:...
        DRO_total_var_num+R*(R*T_wan+0.5*T_wan*(T_wan-1)*R+(T-T_wan)*T_wan*R);
    DRO_total_var_num=DRO_total_var_num+length(YP_windLoss);
    windLoss_in_YP=YP_num+1:YP_num+length(YP_windLoss);
    YP_num=YP_num+length(YP_windLoss);
end
    
    
else
    YP_PG=DRO_total_var_num+1:...
        DRO_total_var_num+N*T_wan*R*(0.5-0.5*T_wan+T);
    DRO_total_var_num=DRO_total_var_num+length(YP_PG);
    PG_in_YP=YP_num+1:YP_num+length(YP_PG);
    YP_num=YP_num+N*T_wan*R*(0.5-0.5*T_wan+T);
    
    YP_Seita=DRO_total_var_num+1:...
        DRO_total_var_num+NodeNum*T_wan*R*(0.5-0.5*T_wan+T);
    DRO_total_var_num=DRO_total_var_num+length(YP_Seita);
    Seita_in_YP=YP_num+1:YP_num+length(YP_Seita);
    YP_num=YP_num+NodeNum*T_wan*R*(0.5-0.5*T_wan+T);
    
    YP_Zit=DRO_total_var_num+1:...
        DRO_total_var_num+N*T_wan*R*(0.5-0.5*T_wan+T);
    DRO_total_var_num=DRO_total_var_num+length(YP_Zit);
    Zit_in_YP=YP_num+1:YP_num+length(YP_Zit);
    YP_num=YP_num+N*T_wan*R*(0.5-0.5*T_wan+T);
    
%     YP_LoadLoss=DRO_total_var_num+1:...
%         DRO_total_var_num+R*T_wan*R*(0.5-0.5*T_wan+T);
%     DRO_total_var_num=DRO_total_var_num+length(YP_LoadLoss);
%     LoadLoss_in_YP=YP_num+1:YP_num+length(YP_LoadLoss);
%     YP_num=YP_num+length(YP_LoadLoss);
    
if(param.windLoss==1)
    YP_windLoss=DRO_total_var_num+1:...
        DRO_total_var_num+R*T_wan*R*(0.5-0.5*T_wan+T);
    DRO_total_var_num=DRO_total_var_num+length(YP_windLoss);
    windLoss_in_YP=YP_num+1:YP_num+length(YP_windLoss);
    YP_num=YP_num+length(YP_windLoss);
end
    
end
if(param.windLoss==1)
    YP_location=[YP_PG,YP_Seita,YP_Zit,YP_windLoss];
else
    YP_location=[YP_PG,YP_Seita,YP_Zit];
end

YPhi_PG=DRO_total_var_num+1:...
    DRO_total_var_num+PGit_num*R_wan_len*(Lk-1);
DRO_total_var_num=DRO_total_var_num+length(YPhi_PG);
PG_in_YPhi=YPhi_num+1:YPhi_num+length(YPhi_PG);
YPhi_num=YPhi_num+length(YPhi_PG);

YPhi_Seita=DRO_total_var_num+1:...
    DRO_total_var_num+Seitait_num*R_wan_len*(Lk-1);
DRO_total_var_num=DRO_total_var_num+length(YPhi_Seita);
Seita_in_YPhi=YPhi_num+1:YPhi_num+length(YPhi_Seita);
YPhi_num=YPhi_num+length(YPhi_Seita);

YPhi_Zit=DRO_total_var_num+1:...
    DRO_total_var_num+Zit_num*R_wan_len*(Lk-1);
DRO_total_var_num=DRO_total_var_num+length(YPhi_Zit);
Zit_in_YPhi=YPhi_num+1:YPhi_num+length(YPhi_Zit);
YPhi_num=YPhi_num+length(YPhi_Zit);

% YPhi_LoadLoss=DRO_total_var_num+1:...
%     DRO_total_var_num+LoadLoss_num*R_wan_len*(Lk-1);
% DRO_total_var_num=DRO_total_var_num+length(YPhi_LoadLoss);
% LoadLoss_in_YPhi=YPhi_num+1:YPhi_num+length(YPhi_LoadLoss);
% YPhi_num=YPhi_num+length(YPhi_LoadLoss); 
if(param.windLoss==1)
    YPhi_windLoss=DRO_total_var_num+1:...
        DRO_total_var_num+windLoss_num*R_wan_len*(Lk-1);
    DRO_total_var_num=DRO_total_var_num+length(YPhi_windLoss);
    windLoss_in_YPhi=YPhi_num+1:YPhi_num+length(YPhi_windLoss);
    YPhi_num=YPhi_num+length(YPhi_windLoss);
end
if(param.windLoss==1)
YPhi_location=[YPhi_PG,YPhi_Seita,YPhi_Zit,YPhi_windLoss];
else
    YPhi_location=[YPhi_PG,YPhi_Seita,YPhi_Zit];
end
Y_location=[Y0_location,YP_location,YPhi_location];

pai_1_location=DRO_total_var_num+1:...
    DRO_total_var_num+size(C,1);
DRO_total_var_num=DRO_total_var_num+length(pai_1_location);

if(~isempty(Aineq_genration_limit_upper)&~isempty(Aineq_genration_limit_lower))
    pai_2_location_upper=DRO_total_var_num+1:...
        DRO_total_var_num+size(C,1)*(size(Aineq_genration_limit_upper,1));
    DRO_total_var_num=DRO_total_var_num+length(pai_2_location_upper);
    
    pai_2_location_lower=DRO_total_var_num+1:...
        DRO_total_var_num+size(C,1)*(size(Aineq_genration_limit_lower,1));
    DRO_total_var_num=DRO_total_var_num+length(pai_2_location_lower);
else
    pai_2_location_upper=[];
    pai_2_location_lower=[];
end

if(~isempty(Aineq_linear_approximation))
    pai_3_location=DRO_total_var_num+1:DRO_total_var_num+size(C,1)*size(Aineq_linear_approximation,1);
    DRO_total_var_num=DRO_total_var_num+length(pai_3_location);
else
    pai_3_location=[];
end

% pai_4_location_upper=DRO_total_var_num+1:...
%     DRO_total_var_num+size(C,1)*(size(Aineq_constraint_power_balance_upper,1));
% DRO_total_var_num=DRO_total_var_num+length(pai_4_location_upper);
%
% pai_4_location_lower=DRO_total_var_num+1:...
%     DRO_total_var_num+size(C,1)*(size(Aineq_constraint_power_balance_lower,1));
% DRO_total_var_num=DRO_total_var_num+length(pai_4_location_lower);
if(~isempty(Aineq_Aeq_DCPowerFlow))
    pai_4_location=DRO_total_var_num+1:...
        DRO_total_var_num+size(C,1)*(size(Aineq_Aeq_DCPowerFlow,1));
    DRO_total_var_num=DRO_total_var_num+length(pai_4_location);
else
    pai_4_location=[];
end

% pai_4_location=DRO_total_var_num+1:...
%     DRO_total_var_num+size(C,1)*(size(Aineq_constraint_power_balance,1));
% DRO_total_var_num=DRO_total_var_num+length(pai_4_location);
if(~isempty(Aineq_ramp_limt_up)&~isempty(Aineq_ramp_limt_down))
    pai_5_location_upper=DRO_total_var_num+1:...
        DRO_total_var_num+size(C,1)*(size(Aineq_ramp_limt_up,1));
    DRO_total_var_num=DRO_total_var_num+length(pai_5_location_upper);
    
    pai_5_location_down=DRO_total_var_num+1:...
        DRO_total_var_num+size(C,1)*(size(Aineq_ramp_limt_down,1));
    DRO_total_var_num=DRO_total_var_num+length(pai_5_location_down);
    
    pai_5_location=[pai_5_location_upper,pai_5_location_down];
else
    pai_5_location=[];
end

if(param.windLoss==1)
    pai_6_location=DRO_total_var_num+1:...
       DRO_total_var_num+size(C,1)*(size(Aineq_windLoss_constraint,1));
    DRO_total_var_num=DRO_total_var_num+length(pai_6_location);
end

total_var_num=DRO_total_var_num;

%z u init
% z=sparse(Y0_num+YP_num+YPhi_num,1);
% u=sparse(Y0_num+YP_num+YPhi_num,1);

%% linear decision rule
Y0_part=sparse(diag(ones(y_num-PWrt_num,1)));

YP_part=[];
for t=1:T
    if(t<=T_wan)
        YP_part=sparse(blkdiag(YP_part,ones(1,t*R)));
    else
        YP_part=sparse(blkdiag(YP_part,ones(1,T_wan*R)));
    end
end
YP_part_PG=[];
for i=1:N
    YP_part_PG=sparse(blkdiag(YP_part_PG,YP_part));
end
YP_part_Seita=[];
for i=1:NodeNum
    YP_part_Seita=sparse(blkdiag(YP_part_Seita,YP_part));
end
YP_part_Zit=YP_part_PG;
if(param.windLoss==1)
    YP_part_windLoss=[];
    for i=1:R
        YP_part_windLoss=sparse(blkdiag(YP_part_windLoss,YP_part));
    end
end

YP_part=sparse(y_num-PWrt_num,YP_num);
YP_part(PGit_location-x_num,YP_PG-x_num-length(Eta_location)-length(lambda_location)-Y0_num)=YP_part_PG;
YP_part(Seitait_location-x_num,YP_Seita-x_num-length(Eta_location)-length(lambda_location)-Y0_num)=YP_part_Seita;
YP_part(Zit_location-x_num,YP_Zit-x_num-length(Eta_location)-length(lambda_location)-Y0_num)=YP_part_Zit;
    if(param.windLoss==1)
YP_part(windLoss_location-x_num-PWrt_num,YP_windLoss-x_num-length(Eta_location)-length(lambda_location)-Y0_num)=YP_part_windLoss;
    end


YPhi_part=[];
for i=1:T
    YPhi_part=sparse(blkdiag(YPhi_part,ones(1,R_wan_len*(Lk-1))));
end
YPhi_part_PG=[];
for i=1:N
    YPhi_part_PG=sparse(blkdiag(YPhi_part_PG,YPhi_part));
end
YPhi_part_Seita=[];
for i=1:NodeNum
    YPhi_part_Seita=sparse(blkdiag(YPhi_part_Seita,YPhi_part));
end
YPhi_part_Zit=YPhi_part_PG;

% YPhi_part_Load=[];
% for i=1:R
%     YPhi_part_Load=sparse(blkdiag(YPhi_part_Load,YPhi_part));
% end
if(param.windLoss==1)
    YPhi_part_windLoss=[];
    for i=1:R
        YPhi_part_windLoss=sparse(blkdiag(YPhi_part_windLoss,YPhi_part));
    end
end

YPhi_part=sparse(y_num-PWrt_num,YPhi_num);
YPhi_part(PGit_location-x_num,YPhi_PG-x_num-length(Eta_location)-length(lambda_location)-Y0_num-YP_num)=YPhi_part_PG;
YPhi_part(Seitait_location-x_num,YPhi_Seita-x_num-length(Eta_location)-length(lambda_location)-Y0_num-YP_num)=YPhi_part_Seita;
YPhi_part(Zit_location-x_num,YPhi_Zit-x_num-length(Eta_location)-length(lambda_location)-Y0_num-YP_num)=YPhi_part_Zit;
% YPhi_part(LoadLoss_location-x_num-PWrt_num,YPhi_LoadLoss-x_num-length(Eta_location)-length(lambda_location)-Y0_num-YP_num)=YPhi_part_Load;
if(param.windLoss==1)
    YPhi_part(windLoss_location-x_num-PWrt_num,YPhi_windLoss-x_num-length(Eta_location)-length(lambda_location)-Y0_num-YP_num)=YPhi_part_windLoss;
end
%PCA
Pwan2PW_coeficent=U*power(S,0.5);
Pwan2PW_coeficent=Pwan2PW_coeficent(:,R_wan);

PW2Pwan_coeficent=(U*diag(power(diag(S),-0.5)))';
PW2Pwan_coeficent=PW2Pwan_coeficent(R_wan,:);
%model variable
model_Pwan2PW_coeficent=[];
model_Pwan2PW_coeficent_part=[];
miu=[];
K=[];
miu_avarge_part=[];
K_part=[];
for t=1:T
    if(t>T_wan)
        model_Pwan2PW_coeficent_part=sparse(blkdiag(model_Pwan2PW_coeficent_part,Pwan2PW_coeficent((t-T_wan)*R+1:t*R,:)'));
        miu_avarge_part=[miu_avarge_part;miu_average((t-T_wan)*R+1:t*R,:)];
        K_part=[K_part,PW2Pwan_coeficent(:,(t-T_wan)*R+1:t*R)];
    else
        model_Pwan2PW_coeficent_part=sparse(blkdiag(model_Pwan2PW_coeficent_part,Pwan2PW_coeficent(1:t*R,:)'));
        miu_avarge_part=[miu_avarge_part;miu_average(1:t*R,:)];
        K_part=[K_part,PW2Pwan_coeficent(:,1:t*R)];
    end
end
%PG
for i=1:N
    model_Pwan2PW_coeficent=sparse(blkdiag(model_Pwan2PW_coeficent,model_Pwan2PW_coeficent_part));
    miu=[miu;miu_avarge_part];
    K=[K,K_part];
end
%seita
for i=1:NodeNum
    model_Pwan2PW_coeficent=sparse(blkdiag(model_Pwan2PW_coeficent,model_Pwan2PW_coeficent_part));
    miu=[miu;miu_avarge_part];
    K=[K,K_part];
end
%Zit
for i=1:N
    model_Pwan2PW_coeficent=sparse(blkdiag(model_Pwan2PW_coeficent,model_Pwan2PW_coeficent_part));
    miu=[miu;miu_avarge_part];
    K=[K,K_part];
end
%LoadLoss
% for i=1:R
%     model_Pwan2PW_coeficent=sparse(blkdiag(model_Pwan2PW_coeficent,model_Pwan2PW_coeficent_part));
%     miu=[miu;miu_avarge_part];
% end
if(param.windLoss==1)
    for i=1:R
        model_Pwan2PW_coeficent=sparse(blkdiag(model_Pwan2PW_coeficent,model_Pwan2PW_coeficent_part));
        miu=[miu;miu_avarge_part];
        K=[K,K_part];
    end
end

miu=sparse(repmat(miu',y_num-PWrt_num,1));
YP_miu=sparse(size(miu,1),size(miu,2));
for i=1:size(miu,1)
YP_miu(i,:)=sparse(YP_part(i,:).*miu(i,:));
end

%%

%
Q=[];
% Q(Y_location,Y_location)=0.5*rho;
f=sparse(1,total_var_num);
f(1,sit_location)=reshape(repmat(ThHot_cost_start,1,T)',N*T,1);
f(1,Sit_location)=1;
f(1,Eta_location)=1;
f(1,lambda_location)=reshape(gamma_k_l',size(gamma_k_l,1)*size(gamma_k_l,2),1);
% f(1,Y_location)=rho*(u-z);


part_YP_Zit_T=[];
part_YP_Zit=[];
part_YP_windLoss_T=[];
part_YP_windLoss=[];
for t=1:T
    if(t>T_wan)
        part_YP_Zit_T=[part_YP_Zit_T,miu_average((t-T_wan)*R+1:t*R)'];
        part_YP_windLoss_T=[part_YP_windLoss_T,miu_average((t-T_wan)*R+1:t*R)'];
    else
        part_YP_Zit_T=[part_YP_Zit_T,miu_average(1:R*t)'];
        part_YP_windLoss_T=[part_YP_windLoss_T,miu_average(1:R*t)'];
    end
end
for i=1:N
    part_YP_Zit=[part_YP_Zit,part_YP_Zit_T];
    
end
for i=1:R
    part_YP_windLoss=[part_YP_windLoss,part_YP_windLoss_T];
end

Aineq_constraint_pai_1=sparse(1,total_var_num);
Aineq_constraint_pai_1(1,Eta_location)=-1; %Eta
Aineq_constraint_pai_1(1,Y0_Zit)=1;

Aineq_constraint_pai_1(1,YP_Zit)=part_YP_Zit;
if(param.windLoss==1)
    Aineq_constraint_pai_1(1,Y0_windLoss)=UC_model.f(windLoss_location);
    Aineq_constraint_pai_1(1,YP_windLoss)=UC_model.f(windLoss_location(1))*part_YP_windLoss;
end
Aineq_constraint_pai_1(1,pai_1_location)=d';
bineq_constraint_pai_1=0;

%YP Zit
% part_YP_Zit=[];
% for i=1:N*T
%     part_YP_Zit=[part_YP_Zit,diag(-1*ones(R*T,1))];
% end
%
% part_YPhi_Zit=[];
% for i=1:N*T
%     part_YPhi_Zit=[part_YPhi_Zit,diag(-1*ones(R*T*(Lk-1),1))];
% end
%
%
% Aeq_constraint_pai_1=sparse(size(C,2)+size(D,2),total_var_num);
% Aeq_constraint_pai_1(size(C,2)+1:size(C,2)+size(D,2),lambda_location)=diag(ones(length(lambda_location),1));
% Aeq_constraint_pai_1(1:size(C,2),YP_Zit)=part_YP_Zit;
% Aeq_constraint_pai_1(size(C,2)+1:size(C,2)+size(D,2),YPhi_Zit)=part_YPhi_Zit;
% Aeq_constraint_pai_1(:,pai_1_location)=[C';D'];
% beq_constraint_pai_1=sparse(size(C,2)+size(D,2),1);

%PCA

%YP Zit
part_YP_Zit=sparse(size(C,2),length(YP_Zit));
coefficience_YP_Zit=U(:,R_wan)*power(S(R_wan,R_wan),0.5);
%loadloss
if(param.windLoss==1)
part_YP_windLoss=sparse(size(C,2),length(YP_windLoss));
coefficience_YP_windLoss=U(:,R_wan)*power(S(R_wan,R_wan),0.5);
end

for i=1:R_wan_len
    m_YP_Zit=[];
    m_YP_windLoss=[];
    for t=1:T
        if(t>T_wan)
            m_YP_Zit=[m_YP_Zit,coefficience_YP_Zit((t-T_wan)*R+1:t*R,i)'];
            if(param.windLoss==1)
                m_YP_windLoss=[m_YP_windLoss,coefficience_YP_windLoss((t-T_wan)*R+1:t*R,i)'];
            end
        else
            m_YP_Zit=[m_YP_Zit,coefficience_YP_Zit(1:t*R,i)'];
            if(param.windLoss==1)
                m_YP_windLoss=[m_YP_windLoss,coefficience_YP_windLoss(1:t*R,i)'];
            end
        end
    end
    part_YP_Zit(i,:)=-1*repmat(m_YP_Zit,1,N);
    if(param.windLoss==1)
    part_YP_windLoss(i,:)=-1*repmat(m_YP_windLoss,1,R);
    end
end

part_YPhi_Zit=[];
part_YPhi_windLoss=[];
for i=1:N*T
    part_YPhi_Zit=[part_YPhi_Zit,diag(-1*ones(R_wan_len*(Lk-1),1))];
end
if(param.windLoss==1)
for i=1:R*T
    part_YPhi_windLoss=[part_YPhi_windLoss,diag(-1*ones(R_wan_len*(Lk-1),1))];
end
end

Aeq_constraint_pai_1=sparse(size(C,2)+size(D,2),total_var_num);
Aeq_constraint_pai_1(size(C,2)+1:size(C,2)+size(D,2),lambda_location)=diag(ones(length(lambda_location),1));
Aeq_constraint_pai_1(1:size(C,2),YP_Zit)=part_YP_Zit;
if(param.windLoss==1)
Aeq_constraint_pai_1(1:size(C,2),YP_windLoss)=UC_model.f(windLoss_location(1)).*part_YP_windLoss;
Aeq_constraint_pai_1(size(C,2)+1:size(C,2)+size(D,2),YPhi_windLoss)=part_YPhi_windLoss;
end
Aeq_constraint_pai_1(size(C,2)+1:size(C,2)+size(D,2),YPhi_Zit)=part_YPhi_Zit;

Aeq_constraint_pai_1(:,pai_1_location)=[C';D'];
beq_constraint_pai_1=sparse(size(C,2)+size(D,2),1);

%% Aineq_genration_limit
Aineq_constraint_pai_2=[];
bineq_constraint_pai_2=[];

Aeq_constraint_pai_2=[];
beq_constraint_pai_2=[];

if(~isempty(pai_2_location_upper)&~isempty(pai_2_location_lower))
    part_pai_2_d=[];
    part_pai_2_C=[];
    part_pai_2_D=[];
    YP_Aineq_PG=sparse(size(Aineq_genration_limit_upper,1),length(YP_PG));
    YP_Aeq_PG=sparse(size(C,2)*size(Aineq_genration_limit_upper,1),length(YP_PG));
    YPhi_Aeq_PG=sparse(size(D,2)*size(Aineq_genration_limit_upper,1),length(YPhi_PG));
    for i=1:size(Aineq_genration_limit_upper,1)
        part_pai_2_d=blkdiag(part_pai_2_d,d');
        part_pai_2_C=blkdiag(part_pai_2_C,C');
        part_pai_2_D=blkdiag(part_pai_2_D,D');
        
        PG_part_location=find(Aineq_genration_limit_upper(i,PGit_location)~=0);
        
        YP_Aineq_PG(i,:)=Aineq_genration_limit_upper(i,PGit_location(PG_part_location))*...
            YP_miu(PG_part_location,PG_in_YP);
        
        YP_PG_part_location=find(YP_part(PG_part_location,:)~=0);
        YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location)=-1*Aineq_genration_limit_upper(i,PGit_location(PG_part_location))*...
            model_Pwan2PW_coeficent((PG_part_location-1)*size(C,2)+1:PG_part_location*size(C,2),PG_in_YP(1,YP_PG_part_location));
        
        YPhi_PG_part_location=find(YPhi_part(PG_part_location,:)~=0);
        YPhi_Aeq_PG((i-1)*size(D,2)+1:i*size(D,2),YPhi_PG_part_location)=-1*Aineq_genration_limit_upper(i,PGit_location(PG_part_location))*diag(ones(R_wan_len*(Lk-1),1));
    end
    
    constraint_pai_2=sparse(size(Aineq_genration_limit_upper,1),total_var_num);
    constraint_pai_2(:,x_location)=Aineq_genration_limit_upper(:,x_location);
    constraint_pai_2(:,Y0_PG)=Aineq_genration_limit_upper(:,PGit_location);
    constraint_pai_2(:,YP_PG)=YP_Aineq_PG;
    constraint_pai_2(:,pai_2_location_upper)=part_pai_2_d;
    
    Aineq_constraint_pai_2=[Aineq_constraint_pai_2;constraint_pai_2];
    bineq_constraint_pai_2=[bineq_constraint_pai_2;bineq_genration_limit_upper];
    
    %eq
    constraint_pai_2=sparse((size(C,2)+size(D,2))*size(Aineq_genration_limit_upper,1),total_var_num);
    constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_upper,1),YP_PG)=YP_Aeq_PG;
    constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_upper,1),pai_2_location_upper)=part_pai_2_C;
    constraint_pai_2(size(C,2)*size(Aineq_genration_limit_upper,1)+1:(size(C,2)+size(D,2))*size(Aineq_genration_limit_upper,1),YPhi_PG)=YPhi_Aeq_PG;
    constraint_pai_2(size(C,2)*size(Aineq_genration_limit_upper,1)+1:(size(C,2)+size(D,2))*size(Aineq_genration_limit_upper,1),pai_2_location_upper)=part_pai_2_D;
    
    Aeq_constraint_pai_2=[Aeq_constraint_pai_2;constraint_pai_2];
    beq_constraint_pai_2=[beq_constraint_pai_2;sparse((size(C,2)+size(D,2))*size(Aineq_genration_limit_upper,1),1)];
    
    %Aineq_genration_limit_lower
    part_pai_2_d=[];
    part_pai_2_C=[];
    part_pai_2_D=[];
    YP_Aineq_PG=sparse(size(Aineq_genration_limit_lower,1),length(YP_PG));
    YP_Aeq_PG=sparse(size(C,2)*size(Aineq_genration_limit_lower,1),length(YP_PG));
    YPhi_Aeq_PG=sparse(size(D,2)*size(Aineq_genration_limit_lower,1),length(YPhi_PG));
    for i=1:size(Aineq_genration_limit_lower,1)
        part_pai_2_d=blkdiag(part_pai_2_d,d');
        part_pai_2_C=blkdiag(part_pai_2_C,C');
        part_pai_2_D=blkdiag(part_pai_2_D,D');
        
        PG_part_location=find(Aineq_genration_limit_lower(i,PGit_location)~=0);
        
        YP_Aineq_PG(i,:)=Aineq_genration_limit_lower(i,PGit_location(PG_part_location))*YP_miu(PG_part_location,PG_in_YP);
        
        YP_PG_part_location=find(YP_part(PG_part_location,:)~=0);
        YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location)=-1*Aineq_genration_limit_lower(i,PGit_location(PG_part_location))*...
            model_Pwan2PW_coeficent((PG_part_location-1)*size(C,2)+1:PG_part_location*size(C,2),PG_in_YP(1,YP_PG_part_location));
        
        YPhi_PG_part_location=find(YPhi_part(PG_part_location,:)~=0);
        YPhi_Aeq_PG((i-1)*size(D,2)+1:i*size(D,2),YPhi_PG_part_location)=-1*Aineq_genration_limit_lower(i,PGit_location(PG_part_location))*diag(ones(R_wan_len*(Lk-1),1));
    end
    
    constraint_pai_2=sparse(size(Aineq_genration_limit_lower,1),total_var_num);
    constraint_pai_2(:,x_location)=Aineq_genration_limit_lower(:,x_location);
    constraint_pai_2(:,Y0_PG)=Aineq_genration_limit_lower(:,PGit_location);
    constraint_pai_2(:,YP_PG)=YP_Aineq_PG;
    constraint_pai_2(:,pai_2_location_lower)=part_pai_2_d;
    
    Aineq_constraint_pai_2=[Aineq_constraint_pai_2;constraint_pai_2];
    bineq_constraint_pai_2=[bineq_constraint_pai_2;bineq_genration_limit_lower];
    
    %eq
    constraint_pai_2=sparse((size(C,2)+size(D,2))*size(Aineq_genration_limit_lower,1),total_var_num);
    constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_lower,1),YP_PG)=YP_Aeq_PG;
    constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_lower,1),pai_2_location_lower)=part_pai_2_C;
    constraint_pai_2(size(C,2)*size(Aineq_genration_limit_lower,1)+1:(size(C,2)+size(D,2))*size(Aineq_genration_limit_lower,1),YPhi_PG)=YPhi_Aeq_PG;
    constraint_pai_2(size(C,2)*size(Aineq_genration_limit_lower,1)+1:(size(C,2)+size(D,2))*size(Aineq_genration_limit_lower,1),pai_2_location_lower)=part_pai_2_D;
    
    Aeq_constraint_pai_2=[Aeq_constraint_pai_2;constraint_pai_2];
    beq_constraint_pai_2=[beq_constraint_pai_2;sparse((size(C,2)+size(D,2))*size(Aineq_genration_limit_lower,1),1)];
end

%% Aineq_linear_approximation
Aineq_constraint_pai_3=[];
bineq_constraint_pai_3=[];
Aeq_constraint_pai_3=[];
beq_constraint_pai_3=[];

if(~isempty(pai_3_location))
    part_pai_3_d=[];
    part_pai_3_C=[];
    part_pai_3_D=[];
    
    YP_Aineq_PG=sparse(size(Aineq_linear_approximation,1),length(YP_PG));
    YP_Aineq_Zit=sparse(size(Aineq_linear_approximation,1),length(YP_Zit));
    
    YP_Aeq_PG=sparse(size(C,2)*size(Aineq_linear_approximation,1),length(YP_PG));
    YP_Aeq_Zit=sparse(size(C,2)*size(Aineq_linear_approximation,1),length(YP_Zit));
    
    YPhi_Aeq_PG=sparse(size(D,2)*size(Aineq_linear_approximation,1),length(YPhi_PG));
    YPhi_Aeq_Zit=sparse(size(D,2)*size(Aineq_linear_approximation,1),length(YPhi_Zit));
    
    for i=1:size(Aineq_linear_approximation,1)
        part_pai_3_d=blkdiag(part_pai_3_d,d');
        part_pai_3_C=blkdiag(part_pai_3_C,C');
        part_pai_3_D=blkdiag(part_pai_3_D,D');
        
        PG_part_location=find(Aineq_linear_approximation(i,PGit_location)~=0);
        Zit_part_location=find(Aineq_linear_approximation(i,Zit_location)~=0);
        
        YP_Aineq_PG(i,:)=Aineq_linear_approximation(i,PGit_location(PG_part_location))*...
            YP_miu(PG_part_location,PG_in_YP);
        
        YP_Aineq_Zit(i,:)=Aineq_linear_approximation(i,Zit_location(Zit_part_location))*...
            YP_miu(Zit_in_Y0(Zit_part_location),Zit_in_YP);
        
        YP_PG_part_location=find(YP_part(PG_part_location,:)~=0);
        YP_Zit_part_location=find(YP_part(Zit_in_Y0(Zit_part_location),:)~=0);
        
        YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location)=-1*Aineq_linear_approximation(i,PGit_location(PG_part_location))*...
            model_Pwan2PW_coeficent((PG_part_location-1)*size(C,2)+1:PG_part_location*size(C,2),...
            PG_in_YP(1,YP_PG_part_location));
        
        YP_Aeq_Zit((i-1)*size(C,2)+1:i*size(C,2),YP_Zit_part_location-length(YP_PG)-length(YP_Seita))=-1*Aineq_linear_approximation(i,Zit_location(Zit_part_location))*...
            model_Pwan2PW_coeficent((Zit_in_Y0(Zit_part_location)-1)*size(C,2)+1:Zit_in_Y0(Zit_part_location)*size(C,2),...
            YP_Zit_part_location);
        
        YPhi_PG_part_location=find(YPhi_part(PG_part_location,:)~=0);
        YPhi_Zit_part_location=find(YPhi_part(Zit_in_Y0(Zit_part_location),:)~=0);
        YPhi_Aeq_PG((i-1)*size(D,2)+1:i*size(D,2),YPhi_PG_part_location)=-1*Aineq_linear_approximation(i,PGit_location(PG_part_location))*...
            diag(ones(R_wan_len*(Lk-1),1));
        YPhi_Aeq_Zit((i-1)*size(D,2)+1:i*size(D,2),YPhi_Zit_part_location-length(YPhi_PG)-length(YPhi_Seita))=-1*Aineq_linear_approximation(i,Zit_location(Zit_part_location))*diag(ones(R_wan_len*(Lk-1),1));
    end
    
    constraint_pai_3=sparse(size(Aineq_linear_approximation,1),total_var_num);
    constraint_pai_3(:,x_location)=Aineq_linear_approximation(:,x_location);
    constraint_pai_3(:,Y0_PG)=Aineq_linear_approximation(:,PGit_location);
    constraint_pai_3(:,Y0_Zit)=Aineq_linear_approximation(:,Zit_location);
    constraint_pai_3(:,YP_PG)=YP_Aineq_PG;
    constraint_pai_3(:,YP_Zit)=YP_Aineq_Zit;
    constraint_pai_3(:,pai_3_location)=part_pai_3_d;
    
    Aineq_constraint_pai_3=[Aineq_constraint_pai_3;constraint_pai_3];
    bineq_constraint_pai_3=[bineq_constraint_pai_3;bineq_linear_approximation];
    
    %eq
    constraint_pai_3=sparse((size(C,2)+size(D,2))*size(Aineq_linear_approximation,1),total_var_num);
    constraint_pai_3(1:size(C,2)*size(Aineq_linear_approximation,1),YP_PG)=YP_Aeq_PG;
    constraint_pai_3(1:size(C,2)*size(Aineq_linear_approximation,1),YP_Zit)=YP_Aeq_Zit;
    constraint_pai_3(1:size(C,2)*size(Aineq_linear_approximation,1),pai_3_location)=part_pai_3_C;
    constraint_pai_3(size(C,2)*size(Aineq_linear_approximation,1)+1:(size(C,2)+size(D,2))*size(Aineq_linear_approximation,1),YPhi_PG)=YPhi_Aeq_PG;
    constraint_pai_3(size(C,2)*size(Aineq_linear_approximation,1)+1:(size(C,2)+size(D,2))*size(Aineq_linear_approximation,1),YPhi_Zit)=YPhi_Aeq_Zit;
    constraint_pai_3(size(C,2)*size(Aineq_linear_approximation,1)+1:(size(C,2)+size(D,2))*size(Aineq_linear_approximation,1),pai_3_location)=part_pai_3_D;
    
    Aeq_constraint_pai_3=[Aeq_constraint_pai_3;constraint_pai_3];
    beq_constraint_pai_3=[beq_constraint_pai_3;sparse((size(C,2)+size(D,2))*size(Aineq_linear_approximation,1),1)];
    
    % J=0:L;
    % for j=1:L+1
    %     pil=reshape(repmat(ThPimin+(J(j)/L)*(ThPimax-ThPimin),1,T)',N*T,1);
    %
    %     part_pai_3=[];
    %     for i=1:Zit_num
    %         part_pai_3=blkdiag(part_pai_3,d');
    %     end
    %
    %     part_YP_PG=[];
    %     part_YP_PG_t=[];
    %     part_YP_Zit=[];
    %     part_YP_Zit_t=[];
    %     for t=1:T
    %         part_YP_PG_t=blkdiag(part_YP_PG_t,miu_average(1:R*t)');
    %         part_YP_Zit_t=blkdiag(part_YP_Zit_t,miu_average(1:R*t)');
    %     end
    %     for i=1:N
    %         part_YP_PG=blkdiag(part_YP_PG,(2*c_gamma((i-1)*T+1).*(pil((i-1)*T+1))+b_beta((i-1)*T+1))*part_YP_PG_t);
    %         part_YP_Zit=blkdiag(part_YP_Zit,-1*part_YP_Zit_t);
    %     end
    %
    %     constraint_pai_3=sparse(Zit_num,total_var_num);
    %     constraint_pai_3(:,uit_location)=diag(a_alpha-c_gamma.*power(pil,2));
    %     constraint_pai_3(:,Y0_PG)=diag(2*c_gamma.*(pil)+b_beta);
    %     constraint_pai_3(:,Y0_Zit)=diag(-1*ones(Zit_num,1));
    %     constraint_pai_3(:,YP_PG)=part_YP_PG;
    %     constraint_pai_3(:,YP_Zit)=part_YP_Zit;
    %     constraint_pai_3(:,pai_3_location((j-1)*Zit_num*size(C,1)+1:j*Zit_num*size(C,1)))=part_pai_3;
    %
    %     Aineq_constraint_pai_3=[Aineq_constraint_pai_3;constraint_pai_3];
    %     bineq_constraint_pai_3=[bineq_constraint_pai_3;sparse(Zit_num,1)];
    %
    %
    %
    %     part_pai_3=[];
    %     for i=1:Zit_num
    %         part_pai_3=blkdiag(part_pai_3,C');
    %     end
    %
    %     part_YP_PG_t=[];
    %     part_YP_Zit_t=[];
    %     for t=1:T
    %         part_YP_PG_t=blkdiag(part_YP_PG_t,repmat(diag_S_1_2(1:R_wan_len),1,t*R).*V(1:R_wan_len,1:t*R));
    %         part_YP_Zit_t=blkdiag(part_YP_Zit_t,repmat(diag_S_1_2(1:R_wan_len),1,t*R).*V(1:R_wan_len,1:t*R));
    %     end
    %     part_YP_PG=[];
    %     part_YP_Zit=[];
    %     for i=1:N
    %         part_YP_PG=blkdiag(part_YP_PG,-1*(2*c_gamma((i-1)*T+1).*(pil((i-1)*T+1))+b_beta((i-1)*T+1))*part_YP_PG_t);
    %         part_YP_Zit=blkdiag(part_YP_Zit,part_YP_Zit_t);
    %     end
    %
    %     constraint_pai_3=sparse(Zit_num*(size(C,2)+size(D,2)),total_var_num);
    %     constraint_pai_3(1:size(C,2)*Zit_num,YP_PG)=part_YP_PG;
    %     constraint_pai_3(1:size(C,2)*Zit_num,YP_Zit)=part_YP_Zit;
    %     constraint_pai_3(1:size(C,2)*Zit_num,pai_3_location((j-1)*Zit_num*size(C,1)+1:j*Zit_num*size(C,1)))=part_pai_3;
    %
    %     part_pai_3=[];
    %     for i=1:Zit_num
    %         part_pai_3=blkdiag(part_pai_3,D');
    %     end
    %     part_YPhi_PG=sparse((Lk-1)*R_wan_len*Zit_num,(Lk-1)*R_wan_len*Zit_num);
    %     part_YPhi_Zit=sparse((Lk-1)*R_wan_len*Zit_num,(Lk-1)*R_wan_len*Zit_num);
    %     coefficent_YPhi=-1*reshape(repmat(2*c_gamma.*(pil)+b_beta,1,(Lk-1)*R_wan_len),(Lk-1)*R_wan_len*Zit_num,1);
    %     for i=1:(Lk-1)*R_wan_len*Zit_num
    %         part_YPhi_PG(i,i)=coefficent_YPhi(i);
    %         part_YPhi_Zit(i,i)=1;
    %     end
    %     constraint_pai_3(size(C,2)*Zit_num+1:(size(C,2)+size(D,2))*Zit_num,YPhi_PG)=part_YPhi_PG;
    %     constraint_pai_3(size(C,2)*Zit_num+1:(size(C,2)+size(D,2))*Zit_num,YPhi_Zit)=part_YPhi_Zit;
    %     constraint_pai_3(size(C,2)*Zit_num+1:(size(C,2)+size(D,2))*Zit_num,pai_3_location((j-1)*Zit_num*size(C,1)+1:j*Zit_num*size(C,1)))=part_pai_3;
    %
    %     Aeq_constraint_pai_3=[Aeq_constraint_pai_3;constraint_pai_3];
    %     beq_constraint_pai_3=[beq_constraint_pai_3;sparse(Zit_num*(size(C,2)+size(D,2)),1)];
    %
    % end
    
    
end

%% Aineq_constraint_power_balance
% Aineq_constraint_pai_4=[];
% bineq_constraint_pai_4=[];
%
% Aeq_constraint_pai_4=[];
% beq_constraint_pai_4=[];
%
% part_pai_4=[];
% for i=1:size(Aineq_constraint_power_balance_upper,1)
%     part_pai_4=blkdiag(part_pai_4,d');
% end
%
% Y0_part=[];
% for i=1:N
%     Y0_part=[Y0_part,eye(T)];
% end
%
% constraint_pai_4=sparse(size(Aineq_constraint_power_balance_upper,1),total_var_num);
% constraint_pai_4(:,Y0_PG)=Y0_part;
% constraint_pai_4(:,pai_4_location_upper)=part_pai_4;
% %
% Aineq_constraint_pai_4=[Aineq_constraint_pai_4;constraint_pai_4];
% bineq_constraint_pai_4=[bineq_constraint_pai_4;bineq_constraint_power_balance_upper];

% part_pai_4=[];
% for i=1:size(Aineq_constraint_power_balance_upper,1)
%     part_pai_4=blkdiag(part_pai_4,C');
%     b_part_4=sparse(size(C',1),1);
%     Pw_location=find(Aineq_constraint_power_balance_upper(i,PWrt_location)~=0);
%     b_part_4(Pw_location,1)=1;
%     beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
% end
%
% YP_part=[];
% for i=1:N
%     YP_part=[YP_part,-1*eye(T*R*T)];
% end
%
% constraint_pai_4=sparse((size(C,2)+size(D,2))*size(Aineq_constraint_power_balance_upper,1),total_var_num);
% constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance_upper,1),YP_PG)=YP_part;
% constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance_upper,1),pai_4_location_upper)=part_pai_4;

% part_pai_4=[];
% YP_PG_part=sparse(size(C,2)*size(Aineq_constraint_power_balance_upper,1),length(YP_PG));
% YP_Seita_part=sparse(size(C,2)*size(Aineq_constraint_power_balance_upper,1),length(YP_Seita));
% for i=1:size(Aineq_constraint_power_balance_upper,1)
%     part_pai_4=blkdiag(part_pai_4,C');
%     b_part_4=sparse(size(C',1),1);
%
%     PG_part_location=find(Aineq_constraint_power_balance_upper(i,PGit_location)~=0);
%     Seita_part_location=find(Aineq_constraint_power_balance_upper(i,Seitait_location)~=0);
%     Pw_location=find(Aineq_constraint_power_balance_upper(i,PWrt_location)~=0);
%
%     if(~isempty(PG_part_location))
%         for j=1:length(PG_part_location)
%             index_unit_no=ceil(PG_part_location(j)/T);
%             index_time_no=mod(PG_part_location(j)-1,T)+1;
%             YP_PG_part((i-1)*size(C,2)+1:i*size(C,2),(index_unit_no-1)*T*R*T+(index_time_no-1)*R*T+1:(index_unit_no-1)*T*R*T+index_time_no*R*T)=...
%                 -1*Aineq_constraint_power_balance_upper(i,PGit_location(PG_part_location(j)))*diag(ones(R*T,1));
%         end
%     end
%     if(~isempty(Seita_part_location))
%         for j=1:length(Seita_part_location)
%             index_bus_no=ceil(Seita_part_location(j)/T);
%             index_time_no=mod(Seita_part_location(j)-1,T)+1;
%             YP_Seita_part((i-1)*size(C,2)+1:i*size(C,2),(index_bus_no-1)*T*R*T+(index_time_no-1)*R*T+1:(index_bus_no-1)*T*R*T+index_time_no*R*T)=...
%                 -1*Aineq_constraint_power_balance_upper(i,Seitait_location(Seita_part_location(j)))*diag(ones(R*T,1));
%         end
%     end
%     if(~isempty(Pw_location))
%         for j=1:length(Pw_location)
%             index_wind_no=ceil(Pw_location(j)/T);
%             index_time_no=mod(Pw_location(j)-1,T)+1;
%             b_part_4(Pw_location(j),1)=1;
%         end
%     end
%     beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
% end
%
% constraint_pai_4=sparse((size(C,2)+size(D,2))*size(Aineq_constraint_power_balance_upper,1),total_var_num);
% constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance_upper,1),YP_PG)=YP_PG_part;
% constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance_upper,1),YP_Seita)=YP_Seita_part;
% constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance_upper,1),pai_4_location_upper)=part_pai_4;
%
% part_pai_4=[];
% for i=1:size(Aineq_constraint_power_balance_upper,1)
%     part_pai_4=blkdiag(part_pai_4,D');
%     b_part_4=sparse(size(D,2),1);
%     beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
% end
%
% YPhi_part=[];
% for i=1:N
%     YPhi_part=[YPhi_part,-1*eye(T*R*T*(Lk-1))];
% end
% constraint_pai_4(size(C,2)*size(Aineq_constraint_power_balance_upper,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_power_balance_upper,1),YPhi_PG)=YPhi_part;
% constraint_pai_4(size(C,2)*size(Aineq_constraint_power_balance_upper,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_power_balance_upper,1),pai_4_location_upper)=part_pai_4;
%
% Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];

%test
% constraint_pai_4_part=sparse((size(C,2)+size(D,2))*size(Aineq_constraint_power_balance_lower,1),total_var_num);
% constraint_pai_4_part(:,YP_PG)=-1*constraint_pai_4(:,YP_PG);
% constraint_pai_4_part(:,YP_Seita)=-1*constraint_pai_4(:,YP_Seita);
% constraint_pai_4_part(:,YPhi_PG)=-1*constraint_pai_4(:,YPhi_PG);
% constraint_pai_4_part(:,pai_4_location_lower)=constraint_pai_4(:,pai_4_location_upper);
% beq_constraint_pai_4_part=-1*beq_constraint_pai_4;
%
% Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4_part];
% beq_constraint_pai_4=[beq_constraint_pai_4;beq_constraint_pai_4_part];


%
%Aineq_constraint_power_balance_lower
% part_pai_4=[];
% for i=1:size(Aineq_constraint_power_balance_lower,1)
%     part_pai_4=blkdiag(part_pai_4,d');
% end
%
% Y0_part=[];
% for i=1:N
%     Y0_part=[Y0_part,-1*eye(T)];
% end
% constraint_pai_4=sparse(size(Aineq_constraint_power_balance_lower,1),total_var_num);
% constraint_pai_4(:,Y0_PG)=Y0_part;
% constraint_pai_4(:,pai_4_location_lower)=part_pai_4;
%
% Aineq_constraint_pai_4=[Aineq_constraint_pai_4;constraint_pai_4];
% bineq_constraint_pai_4=[bineq_constraint_pai_4;bineq_constraint_power_balance_lower];

% part_pai_4=[];
% for i=1:size(Aineq_constraint_power_balance_lower,1)
%     part_pai_4=blkdiag(part_pai_4,C');
%     b_part_4=sparse(size(C,2),1);
%     Pw_location=find(Aineq_constraint_power_balance_lower(i,PWrt_location)~=0);
%     b_part_4(Pw_location,1)=-1;
%     beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
% end
%
% YP_part=[];
% for i=1:N
%     YP_part=[YP_part,eye(T*R*T)];
% end
%
% constraint_pai_4=sparse((size(C,2)+size(D,2))*size(Aineq_constraint_power_balance_lower,1),total_var_num);
% constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance_lower,1),YP_PG)=YP_part;
% constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance_lower,1),pai_4_location_lower)=part_pai_4;

% part_pai_4=[];
% YP_PG_part=sparse(size(C,2)*size(Aineq_constraint_power_balance_lower,1),length(YP_PG));
% YP_Seita_part=sparse(size(C,2)*size(Aineq_constraint_power_balance_lower,1),length(YP_Seita));
% for i=1:size(Aineq_constraint_power_balance_lower,1)
%     part_pai_4=blkdiag(part_pai_4,C');
%     b_part_4=sparse(size(C',1),1);
%
%     PG_part_location=find(Aineq_constraint_power_balance_lower(i,PGit_location)~=0);
%     Seita_part_location=find(Aineq_constraint_power_balance_lower(i,Seitait_location)~=0);
%     Pw_location=find(Aineq_constraint_power_balance_lower(i,PWrt_location)~=0);
%
%     if(~isempty(PG_part_location))
%         for j=1:length(PG_part_location)
%             index_unit_no=ceil(PG_part_location(j)/T);
%             index_time_no=mod(PG_part_location(j)-1,T)+1;
%             YP_PG_part((i-1)*size(C,2)+1:i*size(C,2),(index_unit_no-1)*T*R*T+(index_time_no-1)*R*T+1:(index_unit_no-1)*T*R*T+index_time_no*R*T)=...
%                 -1*Aineq_constraint_power_balance_lower(i,PGit_location(PG_part_location(j)))*diag(ones(R*T,1));
%         end
%     end
%     if(~isempty(Pw_location))
%         for j=1:length(Pw_location)
%             index_wind_no=ceil(Pw_location(j)/T);
%             index_time_no=mod(Pw_location(j)-1,T)+1;
%             b_part_4(Pw_location(j),1)=-1;
%         end
%     end
%     beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
% end
%
% constraint_pai_4=sparse((size(C,2)+size(D,2))*size(Aineq_constraint_power_balance_lower,1),total_var_num);
% constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance_lower,1),YP_PG)=YP_PG_part;
% constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance_lower,1),YP_Seita)=YP_Seita_part;
% constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance_lower,1),pai_4_location_lower)=part_pai_4;


% part_pai_4=[];
% for i=1:size(Aineq_constraint_power_balance_lower,1)
%     part_pai_4=blkdiag(part_pai_4,D');
%     b_part_4=sparse(size(D,2),1);
%     beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
% end
%
% YPhi_part=[];
% for i=1:N
%     YPhi_part=[YPhi_part,eye(T*R*T*(Lk-1))];
% end
% constraint_pai_4(size(C,2)*size(Aineq_constraint_power_balance_lower,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_power_balance_lower,1),YPhi_PG)=YPhi_part;
% constraint_pai_4(size(C,2)*size(Aineq_constraint_power_balance_lower,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_power_balance_lower,1),pai_4_location_lower)=part_pai_4;
%
% Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];

% Aineq_constraint_pai_4=[];
% bineq_constraint_pai_4=[];
%
% Aeq_constraint_pai_4=[];
% beq_constraint_pai_4=[];
%
% part_pai_4=[];
% for i=1:size(Aineq_constraint_power_balance,1)
%     part_pai_4=blkdiag(part_pai_4,d');
% end
%
% constraint_pai_4=sparse(size(Aineq_constraint_power_balance,1),total_var_num);
% constraint_pai_4(:,Y0_PG)=Aineq_constraint_power_balance(:,PGit_location);
% constraint_pai_4(:,Y0_Seita)=Aineq_constraint_power_balance(:,Seitait_location);
% constraint_pai_4(:,pai_4_location)=part_pai_4;
%
% Aineq_constraint_pai_4=[Aineq_constraint_pai_4;constraint_pai_4];
% bineq_constraint_pai_4=[bineq_constraint_pai_4;bineq_constraint_power_balance];

%eq


% %eq
% part_pai_4=[];
% YP_PG_part=sparse(size(C,2)*size(Aineq_constraint_power_balance,1),length(YP_PG));
% YP_Seita_part=sparse(size(C,2)*size(Aineq_constraint_power_balance,1),length(YP_Seita));
% for i=1:size(Aineq_constraint_power_balance,1)
%     part_pai_4=blkdiag(part_pai_4,C');
%     b_part_4=sparse(size(C',1),1);
%
%     PG_part_location=find(Aineq_constraint_power_balance(i,PGit_location)~=0);
%     Seita_part_location=find(Aineq_constraint_power_balance(i,Seitait_location)~=0);
%     Pw_location=find(Aineq_constraint_power_balance(i,PWrt_location)~=0);
%
%     if(~isempty(PG_part_location))
%         for j=1:length(PG_part_location)
%             index_unit_no=ceil(PG_part_location(j)/T);
%             index_time_no=mod(PG_part_location(j)-1,T)+1;
%             YP_PG_part((i-1)*size(C,2)+1:i*size(C,2),(index_unit_no-1)*T*R*T+(index_time_no-1)*R*T+1:(index_unit_no-1)*T*R*T+index_time_no*R*T)=...
%                 -1*Aineq_constraint_power_balance(i,PGit_location(PG_part_location(j)))*diag(ones(R*T,1));
%         end
%     end
%     if(~isempty(Seita_part_location))
%         for j=1:length(Seita_part_location)
%             index_bus_no=ceil(Seita_part_location(j)/T);
%             index_time_no=mod(Seita_part_location(j)-1,T)+1;
%             YP_Seita_part((i-1)*size(C,2)+1:i*size(C,2),(index_bus_no-1)*T*R*T+(index_time_no-1)*R*T+1:(index_bus_no-1)*T*R*T+index_time_no*R*T)=...
%                 -1*Aineq_constraint_power_balance(i,Seitait_location(Seita_part_location(j)))*diag(ones(R*T,1));
%         end
%     end
%     if(~isempty(Pw_location))
%         for j=1:length(Pw_location)
%             index_wind_no=ceil(Pw_location(j)/T);
%             index_time_no=mod(Pw_location(j)-1,T)+1;
%             b_part_4((index_time_no-1)*R+index_wind_no,1)=1;
%         end
%     end
%     beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
% end
%
% constraint_pai_4=sparse((size(C,2)+size(D,2))*size(Aineq_constraint_power_balance,1),total_var_num);
% constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance,1),YP_PG)=YP_PG_part;
% constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance,1),YP_Seita)=YP_Seita_part;
% constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance,1),pai_4_location)=part_pai_4;
%
%
% part_pai_4=[];
% YPhi_PG_part=sparse(size(D,2)*size(Aineq_constraint_power_balance,1),length(YPhi_PG));
% YPhi_Seita_part=sparse(size(D,2)*size(Aineq_constraint_power_balance,1),length(YPhi_Seita));
% for i=1:size(Aineq_constraint_power_balance,1)
%     part_pai_4=blkdiag(part_pai_4,D');
%
%     PG_part_location=find(Aineq_constraint_power_balance(i,PGit_location)~=0);
%     Seita_part_location=find(Aineq_constraint_power_balance(i,Seitait_location)~=0);
%     if(~isempty(PG_part_location))
%         for j=1:length(PG_part_location)
%             index_unit_no=ceil(PG_part_location(j)/T);
%             index_time_no=mod(PG_part_location(j)-1,T)+1;
%             YPhi_PG_part((i-1)*size(D,2)+1:i*size(D,2),(index_unit_no-1)*T*R*(Lk-1)*T+(index_time_no-1)*T*R*(Lk-1)+1:...
%                 (index_unit_no-1)*T*R*(Lk-1)*T+index_time_no*T*R*(Lk-1))=...
%                 -1*Aineq_constraint_power_balance(i,PGit_location(PG_part_location(j)))*diag(R*T*(Lk-1));
%         end
%     end
%     if(~isempty(Seita_part_location))
%         for j=1:length(Seita_part_location)
%             index_bus_no=ceil(Seita_part_location(j)/T);
%             index_time_no=mod(Seita_part_location(j)-1,T)+1;
%             YPhi_Seita_part((i-1)*size(D,2)+1:i*size(D,2),(index_bus_no-1)*T*R*(Lk-1)*T+(index_time_no-1)*R*(Lk-1)*T+1:(index_bus_no-1)*T*R*(Lk-1)*T+index_time_no*R*(Lk-1)*T)=...
%                 -1*Aineq_constraint_power_balance(i,Seitait_location(Seita_part_location(j)))*diag(ones(R*(Lk-1)*T,1));
%         end
%     end
%     b_part_4=sparse(size(D,2),1);
%
%     beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
% end
%
% constraint_pai_4(size(C,2)*size(Aineq_constraint_power_balance,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_power_balance,1),YPhi_PG)=YPhi_PG_part;
% constraint_pai_4(size(C,2)*size(Aineq_constraint_power_balance,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_power_balance,1),YPhi_Seita)=YPhi_Seita_part;
% constraint_pai_4(size(C,2)*size(Aineq_constraint_power_balance,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_power_balance,1),pai_4_location)=part_pai_4;
%
% Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];
%% DC flow

% Aineq_constraint_pai_4=[];
% bineq_constraint_pai_4=[];
%
% Aeq_constraint_pai_4=[];
% beq_constraint_pai_4=[];
%
% part_pai_4_d=[];
% part_pai_4_C=[];
% part_pai_4_D=[];
%
% YP_Aineq_PG=sparse(size(Aineq_constraint_power_balance,1),length(YP_PG));
%
% YP_Aeq_PG=sparse(size(C,2)*size(Aineq_constraint_power_balance,1),length(YP_PG));
%
% YPhi_Aeq_PG=sparse(size(D,2)*size(Aineq_constraint_power_balance,1),length(YPhi_PG));
% bineq_constraint_pai_4_part=sparse(size(Aineq_constraint_power_balance,1),1);
% for i=1:size(Aineq_constraint_power_balance,1)
%
%     beq_constraint_pai_4_part=sparse(size(C,2),1);
%     part_pai_4_d=blkdiag(part_pai_4_d,d');
%     part_pai_4_C=blkdiag(part_pai_4_C,C');
%     part_pai_4_D=blkdiag(part_pai_4_D,D');
%
%     PG_part_location=find(Aineq_constraint_power_balance(i,PGit_location)~=0);
%     PWrt_part_location=find(Aineq_constraint_power_balance(i,PWrt_location)~=0);
%
%     YP_Aineq_PG(i,:)=Aineq_constraint_power_balance(i,PGit_location(PG_part_location))*...
%         YP_miu(PG_part_location,PG_in_YP);
%
%
%     for k=1:length(PG_part_location)
%
%         [YP_PG_part_location_row,YP_PG_part_location_col]=find(YP_part(PG_part_location(k),:)~=0);
%         YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location_col)=-1*Aineq_constraint_power_balance(i,PGit_location(PG_part_location(k)))*...
%             model_Pwan2PW_coeficent((PG_part_location(k)-1)*size(C,2)+1:PG_part_location(k)*size(C,2),...
%             PG_in_YP(1,YP_PG_part_location_col));
%
%         YPhi_PG_part_location=find(YPhi_part(PG_part_location(k),:)~=0);
%         YPhi_Aeq_PG((i-1)*size(D,2)+1:i*size(D,2),YPhi_PG_part_location)=-1*Aineq_constraint_power_balance(i,PGit_location(PG_part_location(k)))*...
%             diag(ones(R_wan_len*(Lk-1),1));
%     end
%
%     if(~isempty(PWrt_part_location))
%         for r=1:length(PWrt_part_location)
%             beq_constraint_pai_4_part=beq_constraint_pai_4_part+...
%                 Aineq_constraint_power_balance(i,PWrt_location(PWrt_part_location(r)))*Pwan2PW_coeficent(PWrt_part_location(r),:)';
%             bineq_constraint_pai_4_part(i,1)=bineq_constraint_pai_4_part(i,1)+...
%                 -1*Aineq_constraint_power_balance(i,PWrt_location(PWrt_part_location(r)))*miu_average(PWrt_part_location(r));
%         end
%     end
%     beq_constraint_pai_4=[beq_constraint_pai_4;beq_constraint_pai_4_part];
% end
%
% constraint_pai_4=sparse(size(Aineq_constraint_power_balance,1),total_var_num);
% constraint_pai_4(:,x_location)=Aineq_constraint_power_balance(:,x_location);
% constraint_pai_4(:,Y0_PG)=Aineq_constraint_power_balance(:,PGit_location);
% constraint_pai_4(:,YP_PG)=YP_Aineq_PG;
% constraint_pai_4(:,pai_4_location)=part_pai_4_d;
%
% Aineq_constraint_pai_4=[Aineq_constraint_pai_4;constraint_pai_4];
% bineq_constraint_pai_4=[bineq_constraint_pai_4;bineq_constraint_power_balance+bineq_constraint_pai_4_part];
%
% %eq
% constraint_pai_4=sparse((size(C,2)+size(D,2))*size(Aineq_constraint_power_balance,1),total_var_num);
% constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance,1),YP_PG)=YP_Aeq_PG;
% constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance,1),pai_4_location)=part_pai_4_C;
% constraint_pai_4(size(C,2)*size(Aineq_constraint_power_balance,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_power_balance,1),YPhi_PG)=YPhi_Aeq_PG;
% constraint_pai_4(size(C,2)*size(Aineq_constraint_power_balance,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_power_balance,1),pai_4_location)=part_pai_4_D;
%
% Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];
% beq_constraint_pai_4=[beq_constraint_pai_4;sparse(size(D,2)*size(Aineq_constraint_power_balance,1),1)];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Aineq_constraint_pai_4=[];
bineq_constraint_pai_4=[];

Aeq_constraint_pai_4=[];
beq_constraint_pai_4=[];

if(~isempty(pai_4_location))
    part_pai_4_d=[];
    part_pai_4_C=[];
    part_pai_4_D=[];
    
    YP_Aineq_PG=sparse(size(Aineq_Aeq_DCPowerFlow,1),length(YP_PG));
    YP_Aineq_Seita=sparse(size(Aineq_Aeq_DCPowerFlow,1),length(YP_Seita));

    YP_Aeq_PG=sparse(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YP_PG));
    YP_Aeq_Seita=sparse(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YP_Seita));
    if(param.windLoss==1)
        YP_Aineq_windLoss=sparse(size(Aineq_Aeq_DCPowerFlow,1),length(YP_windLoss));
        YP_Aeq_windLoss=sparse(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YP_windLoss));
        YPhi_Aeq_windLoss=sparse(size(D,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YPhi_windLoss));
    end
    
    YPhi_Aeq_PG=sparse(size(D,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YPhi_PG));
    YPhi_Aeq_Seita=sparse(size(D,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YPhi_Seita));

    bineq_constraint_pai_4_part=sparse(size(Aineq_Aeq_DCPowerFlow,1),1);
    for i=1:size(Aineq_Aeq_DCPowerFlow,1)
        
        beq_constraint_pai_4_part=sparse(size(C,2),1);
        part_pai_4_d=blkdiag(part_pai_4_d,d');
        part_pai_4_C=blkdiag(part_pai_4_C,C');
        part_pai_4_D=blkdiag(part_pai_4_D,D');
        
        PG_part_location=find(Aineq_Aeq_DCPowerFlow(i,PGit_location)~=0);
        Seita_part_location=find(Aineq_Aeq_DCPowerFlow(i,Seitait_location)~=0);
        PWrt_part_location=find(Aineq_Aeq_DCPowerFlow(i,PWrt_location)~=0);
        if(param.windLoss==1)
        windLoss_part_location=find(Aineq_Aeq_DCPowerFlow(i,windLoss_location)~=0);
                YP_Aineq_windLoss(i,:)=Aineq_Aeq_DCPowerFlow(i,windLoss_location(windLoss_part_location))*...
            YP_miu(windLoss_in_Y0(windLoss_part_location),windLoss_in_YP);
        end
        
        YP_Aineq_PG(i,:)=Aineq_Aeq_DCPowerFlow(i,PGit_location(PG_part_location))*...
            YP_miu(PG_part_location,PG_in_YP);
        
        YP_Aineq_Seita(i,:)=Aineq_Aeq_DCPowerFlow(i,Seitait_location(Seita_part_location))*...
            YP_miu(Seita_in_Y0(Seita_part_location),Seita_in_YP);
        

        for k=1:length(PG_part_location)
            
            [YP_PG_part_location_row,YP_PG_part_location_col]=find(YP_part(PG_part_location(k),:)~=0);
            YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location_col)=-1*Aineq_Aeq_DCPowerFlow(i,PGit_location(PG_part_location(k)))*...
                model_Pwan2PW_coeficent((PG_part_location(k)-1)*size(C,2)+1:PG_part_location(k)*size(C,2),...
                PG_in_YP(1,YP_PG_part_location_col));
            
            YPhi_PG_part_location=find(YPhi_part(PG_part_location(k),:)~=0);
            YPhi_Aeq_PG((i-1)*size(D,2)+1:i*size(D,2),YPhi_PG_part_location)=-1*Aineq_Aeq_DCPowerFlow(i,PGit_location(PG_part_location(k)))*...
                diag(ones(R_wan_len*(Lk-1),1));
        end
        for k=1:length(Seita_part_location)
            [YP_Seita_part_location_row,YP_Seita_part_location_col]=find(YP_part(Seita_in_Y0(Seita_part_location(k)),:)~=0);
            YP_Aeq_Seita((i-1)*size(C,2)+1:i*size(C,2),YP_Seita_part_location_col-length(YP_PG))=-1*Aineq_Aeq_DCPowerFlow(i,Seitait_location(Seita_part_location(k)))*...
                model_Pwan2PW_coeficent((Seita_in_Y0(Seita_part_location(k))-1)*size(C,2)+1:Seita_in_Y0(Seita_part_location(k))*size(C,2),...
                YP_Seita_part_location_col);
            
            YPhi_Seita_part_location=find(YPhi_part(Seita_in_Y0(Seita_part_location(k)),:)~=0);
            YPhi_Aeq_Seita((i-1)*size(D,2)+1:i*size(D,2),YPhi_Seita_part_location-length(YPhi_PG))=-1*Aineq_Aeq_DCPowerFlow(i,Seitait_location(Seita_part_location(k)))*diag(ones(R_wan_len*(Lk-1),1));
        end
        
        if(~isempty(PWrt_part_location))
            for r=1:length(PWrt_part_location)
                beq_constraint_pai_4_part=beq_constraint_pai_4_part+...
                    Aineq_Aeq_DCPowerFlow(i,PWrt_location(PWrt_part_location(r)))*Pwan2PW_coeficent(PWrt_part_location(r),:)';
                bineq_constraint_pai_4_part(i,1)=bineq_constraint_pai_4_part(i,1)+...
                    -1*Aineq_Aeq_DCPowerFlow(i,PWrt_location(PWrt_part_location(r)))*miu_average(PWrt_part_location(r));
            end
        end
        
        if(param.windLoss==1)
            for k=1:length(windLoss_part_location)
                [YP_windLoss_part_location_row,YP_windLoss_part_location_col]=find(YP_part(windLoss_in_Y0(windLoss_part_location(k)),:)~=0);
                YP_Aeq_windLoss((i-1)*size(C,2)+1:i*size(C,2),YP_windLoss_part_location_col-length(YP_PG)-length(YP_Seita)-length(YP_Zit))=-1*Aineq_Aeq_DCPowerFlow(i,windLoss_location(windLoss_part_location(k)))*...
                    model_Pwan2PW_coeficent((windLoss_in_Y0(windLoss_part_location(k))-1)*size(C,2)+1:windLoss_in_Y0(windLoss_part_location(k))*size(C,2),...
                    YP_windLoss_part_location_col);
                
                YPhi_windLoss_part_location=find(YPhi_part(windLoss_in_Y0(windLoss_part_location(k)),:)~=0);
                YPhi_Aeq_windLoss((i-1)*size(D,2)+1:i*size(D,2),YPhi_windLoss_part_location-length(YPhi_PG)-length(YPhi_Seita)-length(YPhi_Zit))=-1*Aineq_Aeq_DCPowerFlow(i,windLoss_location(windLoss_part_location(k)))*diag(ones(R_wan_len*(Lk-1),1));
            end
        end
        beq_constraint_pai_4=[beq_constraint_pai_4;beq_constraint_pai_4_part];
    end
    
    constraint_pai_4=sparse(size(Aineq_Aeq_DCPowerFlow,1),total_var_num);
    constraint_pai_4(:,x_location)=Aineq_Aeq_DCPowerFlow(:,x_location);
    constraint_pai_4(:,Y0_PG)=Aineq_Aeq_DCPowerFlow(:,PGit_location);
    constraint_pai_4(:,Y0_Seita)=Aineq_Aeq_DCPowerFlow(:,Seitait_location);
    if(param.windLoss==1)
    constraint_pai_4(:,Y0_windLoss)=Aineq_Aeq_DCPowerFlow(:,windLoss_location);    
        constraint_pai_4(:,YP_windLoss)=YP_Aineq_windLoss;
    end
    constraint_pai_4(:,YP_PG)=YP_Aineq_PG;
    constraint_pai_4(:,YP_Seita)=YP_Aineq_Seita;

    constraint_pai_4(:,pai_4_location)=part_pai_4_d;
    
    Aineq_constraint_pai_4=[Aineq_constraint_pai_4;constraint_pai_4];
    bineq_constraint_pai_4=[bineq_constraint_pai_4;bineq_Aeq_DCPowerFlow+bineq_constraint_pai_4_part];
    
    %eq
    constraint_pai_4=sparse((size(C,2)+size(D,2))*size(Aineq_Aeq_DCPowerFlow,1),total_var_num);
    constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),YP_PG)=YP_Aeq_PG;
    constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),YP_Seita)=YP_Aeq_Seita;
    if(param.windLoss==1)
        constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),YP_windLoss)=YP_Aeq_windLoss;
        constraint_pai_4(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1)+1:(size(C,2)+size(D,2))*size(Aineq_Aeq_DCPowerFlow,1),YPhi_windLoss)=YPhi_Aeq_windLoss;
    end
    constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),pai_4_location)=part_pai_4_C;
    constraint_pai_4(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1)+1:(size(C,2)+size(D,2))*size(Aineq_Aeq_DCPowerFlow,1),YPhi_PG)=YPhi_Aeq_PG;
    constraint_pai_4(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1)+1:(size(C,2)+size(D,2))*size(Aineq_Aeq_DCPowerFlow,1),YPhi_Seita)=YPhi_Aeq_Seita;
    constraint_pai_4(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1)+1:(size(C,2)+size(D,2))*size(Aineq_Aeq_DCPowerFlow,1),pai_4_location)=part_pai_4_D;
    
    Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];
    beq_constraint_pai_4=[beq_constraint_pai_4;sparse(size(D,2)*size(Aineq_Aeq_DCPowerFlow,1),1)];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Aineq_constraint_pai_4_1=[];
bineq_constraint_pai_4_1=[];

Aeq_constraint_pai_4_1=[];
beq_constraint_pai_4_1=[];
if(param.eq==1)
    Aineq_Aeq_DCPowerFlow=[UC_model.Aeq_DCPowerFlow];
    bineq_Aeq_DCPowerFlow=[UC_model.beq_DCPowerFlow];
    
    
    if(~isempty(pai_4_location))
        
        
        YP_Aineq_PG=sparse(size(Aineq_Aeq_DCPowerFlow,1),length(YP_PG));
        YP_Aineq_Seita=sparse(size(Aineq_Aeq_DCPowerFlow,1),length(YP_Seita));
        %         YP_Aineq_Load=sparse(size(Aineq_Aeq_DCPowerFlow,1),length(YP_LoadLoss));
        
        YP_Aeq_PG=sparse(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YP_PG));
        YP_Aeq_Seita=sparse(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YP_Seita));
        %         YP_Aeq_Load=sparse(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YP_LoadLoss));
        
        YPhi_Aeq_PG=sparse(size(D,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YPhi_PG));
        YPhi_Aeq_Seita=sparse(size(D,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YPhi_Seita));
        %     YPhi_Aeq_Load=sparse(size(D,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YPhi_LoadLoss));
        
        if(param.windLoss==1)
            YP_Aineq_windLoss=sparse(size(Aineq_Aeq_DCPowerFlow,1),length(YP_windLoss));
            YP_Aeq_windLoss=sparse(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YP_windLoss));
            YPhi_Aeq_windLoss=sparse(size(D,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YPhi_windLoss));
        end
        
        bineq_constraint_pai_4_part=sparse(size(Aineq_Aeq_DCPowerFlow,1),1);
        for i=1:size(Aineq_Aeq_DCPowerFlow,1)
            
            beq_constraint_pai_4_part=sparse(size(C,2),1);
            
            
            PG_part_location=find(Aineq_Aeq_DCPowerFlow(i,PGit_location)~=0);
            Seita_part_location=find(Aineq_Aeq_DCPowerFlow(i,Seitait_location)~=0);
            PWrt_part_location=find(Aineq_Aeq_DCPowerFlow(i,PWrt_location)~=0);
            %         Load_part_location=find(Aineq_Aeq_DCPowerFlow(i,LoadLoss_location)~=0);
            
            YP_Aineq_PG(i,:)=Aineq_Aeq_DCPowerFlow(i,PGit_location(PG_part_location))*...
                YP_miu(PG_part_location,PG_in_YP);
            
            YP_Aineq_Seita(i,:)=Aineq_Aeq_DCPowerFlow(i,Seitait_location(Seita_part_location))*...
                YP_miu(Seita_in_Y0(Seita_part_location),Seita_in_YP);
            %         YP_Aineq_Load(i,:)=Aineq_Aeq_DCPowerFlow(i,LoadLoss_location(Load_part_location))*...
            %             YP_miu(LoadLoss_in_Y0(Load_part_location),LoadLoss_in_YP);
            %
           if(param.windLoss==1)
                windLoss_part_location=find(Aineq_Aeq_DCPowerFlow(i,windLoss_location)~=0);
                YP_Aineq_windLoss(i,:)=Aineq_Aeq_DCPowerFlow(i,windLoss_location(windLoss_part_location))*...
                    YP_miu(windLoss_in_Y0(windLoss_part_location),windLoss_in_YP);
            end
            
            for k=1:length(PG_part_location)
                
                [YP_PG_part_location_row,YP_PG_part_location_col]=find(YP_part(PG_part_location(k),:)~=0);
                YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location_col)=-1*Aineq_Aeq_DCPowerFlow(i,PGit_location(PG_part_location(k)))*...
                    model_Pwan2PW_coeficent((PG_part_location(k)-1)*size(C,2)+1:PG_part_location(k)*size(C,2),...
                    PG_in_YP(1,YP_PG_part_location_col));
                
                YPhi_PG_part_location=find(YPhi_part(PG_part_location(k),:)~=0);
                YPhi_Aeq_PG((i-1)*size(D,2)+1:i*size(D,2),YPhi_PG_part_location)=-1*Aineq_Aeq_DCPowerFlow(i,PGit_location(PG_part_location(k)))*...
                    diag(ones(R_wan_len*(Lk-1),1));
            end
            for k=1:length(Seita_part_location)
                [YP_Seita_part_location_row,YP_Seita_part_location_col]=find(YP_part(Seita_in_Y0(Seita_part_location(k)),:)~=0);
                YP_Aeq_Seita((i-1)*size(C,2)+1:i*size(C,2),YP_Seita_part_location_col-length(YP_PG))=-1*Aineq_Aeq_DCPowerFlow(i,Seitait_location(Seita_part_location(k)))*...
                    model_Pwan2PW_coeficent((Seita_in_Y0(Seita_part_location(k))-1)*size(C,2)+1:Seita_in_Y0(Seita_part_location(k))*size(C,2),...
                    YP_Seita_part_location_col);
                
                YPhi_Seita_part_location=find(YPhi_part(Seita_in_Y0(Seita_part_location(k)),:)~=0);
                YPhi_Aeq_Seita((i-1)*size(D,2)+1:i*size(D,2),YPhi_Seita_part_location-length(YPhi_PG))=-1*Aineq_Aeq_DCPowerFlow(i,Seitait_location(Seita_part_location(k)))*diag(ones(R_wan_len*(Lk-1),1));
            end
            
            if(~isempty(PWrt_part_location))
                for r=1:length(PWrt_part_location)
                    beq_constraint_pai_4_part=beq_constraint_pai_4_part+...
                        Aineq_Aeq_DCPowerFlow(i,PWrt_location(PWrt_part_location(r)))*Pwan2PW_coeficent(PWrt_part_location(r),:)';
                    bineq_constraint_pai_4_part(i,1)=bineq_constraint_pai_4_part(i,1)+...
                        -1*Aineq_Aeq_DCPowerFlow(i,PWrt_location(PWrt_part_location(r)))*miu_average(PWrt_part_location(r));
                end
            end
            if(param.windLoss==1)
                    for k=1:length(windLoss_part_location)
                        [YP_windLoss_part_location_row,YP_windLoss_part_location_col]=find(YP_part(windLoss_in_Y0(windLoss_part_location(k)),:)~=0);
                        YP_Aeq_windLoss((i-1)*size(C,2)+1:i*size(C,2),YP_windLoss_part_location_col-length(YP_PG)-length(YP_Seita)-length(YP_Zit))=-1*Aineq_Aeq_DCPowerFlow(i,windLoss_location(windLoss_part_location(k)))*...
                            model_Pwan2PW_coeficent((windLoss_in_Y0(windLoss_part_location(k))-1)*size(C,2)+1:windLoss_in_Y0(windLoss_part_location(k))*size(C,2),...
                            YP_windLoss_part_location_col);
            
                        YPhi_windLoss_part_location=find(YPhi_part(windLoss_in_Y0(windLoss_part_location(k)),:)~=0);
                        YPhi_Aeq_windLoss((i-1)*size(D,2)+1:i*size(D,2),YPhi_windLoss_part_location-length(YPhi_PG)-length(YPhi_Seita)-length(YPhi_Zit))=-1*Aineq_Aeq_DCPowerFlow(i,windLoss_location(windLoss_part_location(k)))*diag(ones(R_wan_len*(Lk-1),1));
                    end
            end
            beq_constraint_pai_4_1=[beq_constraint_pai_4_1;beq_constraint_pai_4_part];
        end
        
        constraint_pai_4=sparse(size(Aineq_Aeq_DCPowerFlow,1),total_var_num);
        constraint_pai_4(:,x_location)=Aineq_Aeq_DCPowerFlow(:,x_location);
        constraint_pai_4(:,Y0_PG)=Aineq_Aeq_DCPowerFlow(:,PGit_location);
        constraint_pai_4(:,Y0_Seita)=Aineq_Aeq_DCPowerFlow(:,Seitait_location);
        if(param.windLoss==1)
            constraint_pai_4(:,Y0_windLoss)=Aineq_Aeq_DCPowerFlow(:,windLoss_location);
             constraint_pai_4(:,YP_windLoss)=YP_Aineq_windLoss;
        end
        constraint_pai_4(:,YP_PG)=YP_Aineq_PG;
        constraint_pai_4(:,YP_Seita)=YP_Aineq_Seita;
       
        
        
        Aineq_constraint_pai_4_1=[Aineq_constraint_pai_4_1;constraint_pai_4];
        bineq_constraint_pai_4_1=[bineq_constraint_pai_4_1;bineq_Aeq_DCPowerFlow+bineq_constraint_pai_4_part];
        
        %eq
        constraint_pai_4=sparse((size(C,2)+size(D,2))*size(Aineq_Aeq_DCPowerFlow,1),total_var_num);
        constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),YP_PG)=YP_Aeq_PG;
        constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),YP_Seita)=YP_Aeq_Seita;
        if(param.windLoss==1)
            constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),YP_windLoss)=YP_Aeq_windLoss;
            constraint_pai_4(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1)+1:(size(C,2)+size(D,2))*size(Aineq_Aeq_DCPowerFlow,1),YPhi_windLoss)=YPhi_Aeq_windLoss;

        end
        constraint_pai_4(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1)+1:(size(C,2)+size(D,2))*size(Aineq_Aeq_DCPowerFlow,1),YPhi_PG)=YPhi_Aeq_PG;
        constraint_pai_4(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1)+1:(size(C,2)+size(D,2))*size(Aineq_Aeq_DCPowerFlow,1),YPhi_Seita)=YPhi_Aeq_Seita;
        
        Aeq_constraint_pai_4_1=[Aeq_constraint_pai_4_1;constraint_pai_4];
        beq_constraint_pai_4_1=[beq_constraint_pai_4_1;sparse(size(D,2)*size(Aineq_Aeq_DCPowerFlow,1),1)];
    end
end
% part_pai_4=[];
% for i=1:size(Aineq_Aeq_DCPowerFlow,1)
%     part_pai_4=blkdiag(part_pai_4,d');
% end
%
% constraint_pai_4=sparse(size(Aineq_Aeq_DCPowerFlow,1),total_var_num);
% constraint_pai_4(:,Y0_PG)=Aineq_Aeq_DCPowerFlow(:,PGit_location);
% constraint_pai_4(:,Y0_Seita)=Aineq_Aeq_DCPowerFlow(:,Seitait_location);
% constraint_pai_4(:,pai_4_location)=part_pai_4;
%
% Aineq_constraint_pai_4=[Aineq_constraint_pai_4;constraint_pai_4];
% bineq_constraint_pai_4=[bineq_constraint_pai_4;bineq_Aeq_DCPowerFlow];
% %
% % %eq
% % %upper
% part_pai_4=[];
% constraint_pai_4=sparse((size(C,2))*size(Aineq_DCPowerFlow_upper,1),total_var_num);
%
% for i=1:size(Aineq_DCPowerFlow_upper,1)
%     part_pai_4=blkdiag(part_pai_4,C');
%     b_part_4=sparse(size(C',1),1);
%
%     PG_part_location=find(Aineq_DCPowerFlow_upper(i,PGit_location)~=0);
%     Seita_part_location=find(Aineq_DCPowerFlow_upper(i,Seitait_location)~=0);
%     Pw_location=find(Aineq_DCPowerFlow_upper(i,PWrt_location)~=0);
%
%     if(~isempty(PG_part_location))
%         YP_PG_part=sparse(size(C,2),length(YP_PG));
%         for j=1:length(PG_part_location)
%             index_unit_no=ceil(PG_part_location(j)/T);
%             index_time_no=mod(PG_part_location(j)-1,T)+1;
%             YP_PG_part(:,(index_unit_no-1)*T*R*T+(index_time_no-1)*R*T+1:(index_unit_no-1)*T*R*T+index_time_no*R*T)=...
%                 -1*diag(ones(R*T,1));
%         end
%     end
%     if(~isempty(Seita_part_location))
%         YP_Seita_part=sparse(size(C,2),length(YP_Seita));
%         for j=1:length(Seita_part_location)
%             index_bus_no=ceil(Seita_part_location(j)/T);
%             index_time_no=mod(Seita_part_location(j)-1,T)+1;
%             YP_Seita_part(:,(index_bus_no-1)*T*R*T+(index_time_no-1)*R*T+1:(index_bus_no-1)*T*R*T+index_time_no*R*T)=...
%                 -1*Aineq_DCPowerFlow_upper(i,Seitait_location(Seita_part_location(j)))*diag(ones(R*T,1));
%         end
%     end
%     if(~isempty(Pw_location))
%          b_part_4(Pw_location,1)=1;
%     end
%
%     constraint_pai_4((i-1)*size(C,2)+1:i*size(C,2),YP_PG)=YP_PG_part;
%     constraint_pai_4((i-1)*size(C,2)+1:i*size(C,2),YP_Seita)=YP_Seita_part;
%
%
%     beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
% end
% constraint_pai_4(1:size(C,2)*size(Aineq_DCPowerFlow_upper,1),pai_4_location_upper)=part_pai_4;
% Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];
%
% %lower  YP
% constraint_pai_4_lower=sparse((size(C,2))*size(Aineq_DCPowerFlow_lower,1),total_var_num);
% constraint_pai_4_lower(:,YP_PG)=-1*constraint_pai_4(:,YP_PG);
% constraint_pai_4_lower(:,YP_Seita)=-1*constraint_pai_4(:,YP_Seita);
% constraint_pai_4_lower(:,pai_4_location_lower)=constraint_pai_4(:,pai_4_location_upper);
%
% beq_constraint_pai_4_lower=-1*beq_constraint_pai_4;
% Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4_lower];
% beq_constraint_pai_4=[beq_constraint_pai_4;beq_constraint_pai_4_lower];
%
% beq_constraint_pai_4_lower=[];
%
% %upper YPhi
% part_pai_4=[];
%
% constraint_pai_4=sparse((size(D,2))*size(Aineq_DCPowerFlow_upper,1),total_var_num);
% for i=1:size(Aineq_DCPowerFlow_upper,1)
%     part_pai_4=blkdiag(part_pai_4,D');
%     b_part_4=sparse(size(D',1),1);
%
%     PG_part_location=find(Aineq_DCPowerFlow_upper(i,PGit_location)~=0);
%     Seita_part_location=find(Aineq_DCPowerFlow_upper(i,Seitait_location)~=0);
%
%     if(~isempty(PG_part_location))
%         YPhi_PG_part=sparse(size(D,2),length(YPhi_PG));
%         for j=1:length(PG_part_location)
%             index_unit_no=ceil(PG_part_location(j)/T);
%             index_time_no=mod(PG_part_location(j)-1,T)+1;
%             YPhi_PG_part(:,(index_unit_no-1)*T*R*(Lk-1)*T+(index_time_no-1)*T*R*(Lk-1)+1:...
%                     (index_unit_no-1)*T*R*(Lk-1)*T+index_time_no*T*R*(Lk-1))=...
%                 -1*diag(ones(R*T*(Lk-1),1));
%         end
%     end
%     if(~isempty(Seita_part_location))
%         YPhi_Seita_part=sparse(size(D,2),length(YPhi_Seita));
%         for j=1:length(Seita_part_location)
%             index_bus_no=ceil(Seita_part_location(j)/T);
%             index_time_no=mod(Seita_part_location(j)-1,T)+1;
%             YPhi_Seita_part(:,(index_bus_no-1)*T*R*T*(Lk-1)+(index_time_no-1)*R*T*(Lk-1)+1:(index_bus_no-1)*T*R*T*(Lk-1)+index_time_no*R*T*(Lk-1))=...
%                 -1*Aineq_DCPowerFlow_upper(i,Seitait_location(Seita_part_location(j)))*diag(ones(R*T*(Lk-1),1));
%         end
%     end
%
%     constraint_pai_4((i-1)*size(D,2)+1:i*size(D,2),YPhi_PG)=YPhi_PG_part;
%     constraint_pai_4((i-1)*size(D,2)+1:i*size(D,2),YPhi_Seita)=YPhi_Seita_part;
%
%
%     beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
%     beq_constraint_pai_4_lower=[beq_constraint_pai_4_lower;-1*b_part_4];
% end
% constraint_pai_4(1:size(D,2)*size(Aineq_DCPowerFlow_upper,1),pai_4_location_upper)=part_pai_4;
% Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];
%
%
% %lower YPhi
% constraint_pai_4_lower=sparse((size(D,2))*size(Aineq_DCPowerFlow_lower,1),total_var_num);
% constraint_pai_4_lower(:,YPhi_PG)=-1*constraint_pai_4(:,YPhi_PG);
% constraint_pai_4_lower(:,YPhi_Seita)=-1*constraint_pai_4(:,YPhi_Seita);
% constraint_pai_4_lower(:,pai_4_location_lower)=constraint_pai_4(:,pai_4_location_upper);
%
% Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4_lower];
% beq_constraint_pai_4=[beq_constraint_pai_4;beq_constraint_pai_4_lower];
%
% %lower
% part_pai_4=[];
% constraint_pai_4=sparse((size(C,2))*size(Aineq_DCPowerFlow_lower,1),total_var_num);
%
% for i=1:size(Aineq_DCPowerFlow_lower,1)
%     part_pai_4=blkdiag(part_pai_4,C');
%     b_part_4=sparse(size(C',1),1);
%
%     PG_part_location=find(Aineq_DCPowerFlow_lower(i,PGit_location)~=0);
%     Seita_part_location=find(Aineq_DCPowerFlow_lower(i,Seitait_location)~=0);
%     Pw_location=find(Aineq_DCPowerFlow_lower(i,PWrt_location)~=0);
%
%     if(~isempty(PG_part_location))
%         YP_PG_part=sparse(size(C,2),length(YP_PG));
%         for j=1:length(PG_part_location)
%             index_unit_no=ceil(PG_part_location(j)/T);
%             index_time_no=mod(PG_part_location(j)-1,T)+1;
%             YP_PG_part(:,(index_unit_no-1)*T*R*T+(index_time_no-1)*R*T+1:(index_unit_no-1)*T*R*T+index_time_no*R*T)=...
%                 diag(ones(R*T,1));
%         end
%     end
%     if(~isempty(Seita_part_location))
%         YP_Seita_part=sparse(size(C,2),length(YP_Seita));
%         for j=1:length(Seita_part_location)
%             index_bus_no=ceil(Seita_part_location(j)/T);
%             index_time_no=mod(Seita_part_location(j)-1,T)+1;
%             YP_Seita_part(:,(index_bus_no-1)*T*R*T+(index_time_no-1)*R*T+1:(index_bus_no-1)*T*R*T+index_time_no*R*T)=...
%                 -1*Aineq_DCPowerFlow_lower(i,Seitait_location(Seita_part_location(j)))*diag(ones(R*T,1));
%         end
%     end
%     if(~isempty(Pw_location))
%          b_part_4(Pw_location,1)=-1;
%     end
%
%     constraint_pai_4((i-1)*size(C,2)+1:i*size(C,2),YP_PG)=YP_PG_part;
%     constraint_pai_4((i-1)*size(C,2)+1:i*size(C,2),YP_Seita)=YP_Seita_part;
%
%
%     beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
% end
% constraint_pai_4(1:size(C,2)*size(Aineq_DCPowerFlow_lower,1),pai_4_location_lower)=part_pai_4;
% Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];
%
%
% part_pai_4=[];
% constraint_pai_4=sparse((size(D,2))*size(Aineq_DCPowerFlow_lower,1),total_var_num);
% for i=1:size(Aineq_DCPowerFlow_lower,1)
%     part_pai_4=blkdiag(part_pai_4,D');
%     b_part_4=sparse(size(D',1),1);
%
%     PG_part_location=find(Aineq_DCPowerFlow_lower(i,PGit_location)~=0);
%     Seita_part_location=find(Aineq_DCPowerFlow_lower(i,Seitait_location)~=0);
%
%     if(~isempty(PG_part_location))
%         YPhi_PG_part=sparse(size(D,2),length(YPhi_PG));
%         for j=1:length(PG_part_location)
%             index_unit_no=ceil(PG_part_location(j)/T);
%             index_time_no=mod(PG_part_location(j)-1,T)+1;
%             YPhi_PG_part(:,(index_unit_no-1)*T*R*(Lk-1)*T+(index_time_no-1)*T*R*(Lk-1)+1:...
%                     (index_unit_no-1)*T*R*(Lk-1)*T+index_time_no*T*R*(Lk-1))=...
%                 diag(ones(R*T*(Lk-1),1));
%         end
%     end
%     if(~isempty(Seita_part_location))
%         YPhi_Seita_part=sparse(size(D,2),length(YPhi_Seita));
%         for j=1:length(Seita_part_location)
%             index_bus_no=ceil(Seita_part_location(j)/T);
%             index_time_no=mod(Seita_part_location(j)-1,T)+1;
%             YPhi_Seita_part(:,(index_bus_no-1)*T*R*T*(Lk-1)+(index_time_no-1)*R*T*(Lk-1)+1:(index_bus_no-1)*T*R*T*(Lk-1)+index_time_no*R*T*(Lk-1))=...
%                 -1*Aineq_DCPowerFlow_lower(i,Seitait_location(Seita_part_location(j)))*diag(ones(R*T*(Lk-1),1));
%         end
%     end
%
%     constraint_pai_4((i-1)*size(D,2)+1:i*size(D,2),YPhi_PG)=YPhi_PG_part;
%     constraint_pai_4((i-1)*size(D,2)+1:i*size(D,2),YPhi_Seita)=YPhi_Seita_part;
%
%
%     beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
% end
% constraint_pai_4(1:size(D,2)*size(Aineq_DCPowerFlow_lower,1),pai_4_location_lower)=part_pai_4;
% Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];

%seita
% part_pai_4=[];
% constraint_pai_4=sparse((size(C,2))*size(Aineq_DCPowerFlow,1),total_var_num);
%
% for i=1:size(Aineq_DCPowerFlow,1)
%     part_pai_4=blkdiag(part_pai_4,C');
%     b_part_4=sparse(size(C',1),1);
%     Seita_part_location=find(Aineq_DCPowerFlow(i,Seitait_location)~=0);
%     if(~isempty(Seita_part_location))
%         YP_Seita_part=sparse(size(C,2),length(YP_Seita));
%         for j=1:length(Seita_part_location)
%             index_bus_no=ceil(Seita_part_location(j)/T);
%             index_time_no=mod(Seita_part_location(j)-1,T)+1;
%             YP_Seita_part(:,(index_bus_no-1)*T*R*T+(index_time_no-1)*R*T+1:(index_bus_no-1)*T*R*T+index_time_no*R*T)=...
%                 -1*Aineq_DCPowerFlow(i,Seitait_location(Seita_part_location(j)))*diag(ones(R*T,1));
%         end
%     end
%
%     constraint_pai_4((i-1)*size(C,2)+1:i*size(C,2),YP_PG)=YP_PG_part;
%     constraint_pai_4((i-1)*size(C,2)+1:i*size(C,2),YP_Seita)=YP_Seita_part;
%
%
%     beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
% end
% constraint_pai_4(1:size(C,2)*size(Aineq_DCPowerFlow,1),pai_4_location_seita)=part_pai_4;
% Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];
%
%
% part_pai_4=[];
% constraint_pai_4=sparse((size(D,2))*size(Aineq_DCPowerFlow,1),total_var_num);
% for i=1:size(Aineq_DCPowerFlow,1)
%     part_pai_4=blkdiag(part_pai_4,D');
%     b_part_4=sparse(size(D',1),1);
%
%     Seita_part_location=find(Aineq_DCPowerFlow(i,Seitait_location)~=0);
%     if(~isempty(Seita_part_location))
%         YPhi_Seita_part=sparse(size(D,2),length(YPhi_Seita));
%         for j=1:length(Seita_part_location)
%             index_bus_no=ceil(Seita_part_location(j)/T);
%             index_time_no=mod(Seita_part_location(j)-1,T)+1;
%             YPhi_Seita_part(:,(index_bus_no-1)*T*R*T*(Lk-1)+(index_time_no-1)*R*T*(Lk-1)+1:(index_bus_no-1)*T*R*T*(Lk-1)+index_time_no*R*T*(Lk-1))=...
%                 -1*Aineq_DCPowerFlow(i,Seitait_location(Seita_part_location(j)))*diag(ones(R*T*(Lk-1),1));
%         end
%     end
%
%     constraint_pai_4((i-1)*size(D,2)+1:i*size(D,2),YPhi_PG)=YPhi_PG_part;
%     constraint_pai_4((i-1)*size(D,2)+1:i*size(D,2),YPhi_Seita)=YPhi_Seita_part;
%
%
%     beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
% end
% constraint_pai_4(1:size(D,2)*size(Aineq_DCPowerFlow,1),pai_4_location_seita)=part_pai_4;
% Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];

%% Aineq_ramp_limt
Aineq_constraint_pai_5=[];
bineq_constraint_pai_5=[];

Aeq_constraint_pai_5=[];
beq_constraint_pai_5=[];

if(~isempty(pai_5_location))
    part_pai_5_d=[];
    part_pai_5_C=[];
    part_pai_5_D=[];
    
    YP_Aineq_PG=sparse(size(Aineq_ramp_limt,1),length(YP_PG));
    
    YP_Aeq_PG=sparse(size(C,2)*size(Aineq_ramp_limt,1),length(YP_PG));
    
    YPhi_Aeq_PG=sparse(size(D,2)*size(Aineq_ramp_limt,1),length(YPhi_PG));
    for i=1:size(Aineq_ramp_limt,1)
        part_pai_5_d=blkdiag(part_pai_5_d,d');
        part_pai_5_C=blkdiag(part_pai_5_C,C');
        part_pai_5_D=blkdiag(part_pai_5_D,D');
        
        PG_part_location=find(Aineq_ramp_limt(i,PGit_location)~=0);
        
        YP_Aineq_PG(i,:)=Aineq_ramp_limt(i,PGit_location(PG_part_location))*...
            YP_miu(PG_part_location,PG_in_YP);
        
        for k=1:length(PG_part_location)
            [YP_PG_part_location_row,YP_PG_part_location_col]=find(YP_part(PG_part_location(k),:)~=0);
            YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location_col)=-1*Aineq_ramp_limt(i,PGit_location(PG_part_location(k)))*...
                model_Pwan2PW_coeficent((PG_part_location(k)-1)*size(C,2)+1:PG_part_location(k)*size(C,2),...
                PG_in_YP(1,YP_PG_part_location_col));
            
            YPhi_PG_part_location=find(YPhi_part(PG_part_location(k),:)~=0);
            YPhi_Aeq_PG((i-1)*size(D,2)+1:i*size(D,2),YPhi_PG_part_location)=-1*Aineq_ramp_limt(i,PGit_location(PG_part_location(k)))*...
                diag(ones(R_wan_len*(Lk-1),1));
        end
        
    end
    
    constraint_pai_5=sparse(size(Aineq_ramp_limt,1),total_var_num);
    constraint_pai_5(:,x_location)=Aineq_ramp_limt(:,x_location);
    constraint_pai_5(:,Y0_PG)=Aineq_ramp_limt(:,PGit_location);
    constraint_pai_5(:,YP_PG)=YP_Aineq_PG;
    constraint_pai_5(:,pai_5_location)=part_pai_5_d;
    
    Aineq_constraint_pai_5=[Aineq_constraint_pai_5;constraint_pai_5];
    bineq_constraint_pai_5=[bineq_constraint_pai_5;bineq_ramp_limt];
    
    %eq
    constraint_pai_5=sparse((size(C,2)+size(D,2))*size(Aineq_ramp_limt,1),total_var_num);
    constraint_pai_5(1:size(C,2)*size(Aineq_ramp_limt,1),YP_PG)=YP_Aeq_PG;
    constraint_pai_5(1:size(C,2)*size(Aineq_ramp_limt,1),pai_5_location)=part_pai_5_C;
    constraint_pai_5(size(C,2)*size(Aineq_ramp_limt,1)+1:(size(C,2)+size(D,2))*size(Aineq_ramp_limt,1),YPhi_PG)=YPhi_Aeq_PG;
    constraint_pai_5(size(C,2)*size(Aineq_ramp_limt,1)+1:(size(C,2)+size(D,2))*size(Aineq_ramp_limt,1),pai_5_location)=part_pai_5_D;
    
    Aeq_constraint_pai_5=[Aeq_constraint_pai_5;constraint_pai_5];
    beq_constraint_pai_5=[beq_constraint_pai_5;sparse((size(C,2)+size(D,2))*size(Aineq_ramp_limt,1),1)];
end
% part_pai_5=[];
% for i=1:size(Aineq_ramp_limt_up,1)
%     part_pai_5=blkdiag(part_pai_5,d');
% end
%
% constraint_pai_5=sparse(size(Aineq_ramp_limt_up,1),total_var_num);
% constraint_pai_5(:,1:x_num)=Aineq_ramp_limt_up(:,1:x_num);
% constraint_pai_5(:,Y0_PG)=Aineq_ramp_limt_up(:,PGit_location);
% constraint_pai_5(:,pai_5_location_upper)=part_pai_5;
% Aineq_constraint_pai_5=[Aineq_constraint_pai_5;constraint_pai_5];
% bineq_constraint_pai_5=[bineq_constraint_pai_5;bineq_ramp_limt_up];
%
% part_pai_5=[];
% constraint_pai_5=sparse((size(C,2))*size(Aineq_ramp_limt_up,1),total_var_num);
%
% for i=1:size(Aineq_ramp_limt_up,1)
%     part_pai_5=blkdiag(part_pai_5,C');
%     b_part_5=sparse(size(C',1),1);
%     PG_part_location=find(Aineq_ramp_limt_up(i,PGit_location)~=0);
%     if(~isempty(PG_part_location))
%         YP_PG_part=sparse(size(C,2),length(YP_PG));
%         for j=1:length(PG_part_location)
%             index_unit_no=ceil(PG_part_location(j)/T);
%             index_time_no=mod(PG_part_location(j)-1,T)+1;
%             YP_PG_part(:,(index_unit_no-1)*T*R*T+(index_time_no-1)*R*T+1:(index_unit_no-1)*T*R*T+index_time_no*R*T)=...
%                 -1*Aineq_ramp_limt_up(i,PGit_location(PG_part_location(j)))*diag(ones(R*T,1));
%         end
%     end
%
%     constraint_pai_5((i-1)*size(C,2)+1:i*size(C,2),YP_PG)=YP_PG_part;
%
%     beq_constraint_pai_5=[beq_constraint_pai_5;b_part_5];
% end
% constraint_pai_5(1:size(C,2)*size(Aineq_ramp_limt_up,1),pai_5_location_upper)=part_pai_5;
% Aeq_constraint_pai_5=[Aeq_constraint_pai_5;constraint_pai_5];
%
%
% part_pai_5=[];
% constraint_pai_5=sparse((size(D,2))*size(Aineq_ramp_limt_up,1),total_var_num);
% for i=1:size(Aineq_ramp_limt_up,1)
%     part_pai_5=blkdiag(part_pai_5,D');
%     b_part_5=sparse(size(D',1),1);
%
%      PG_part_location=find(Aineq_ramp_limt_up(i,PGit_location)~=0);
%     if(~isempty(PG_part_location))
%         YPhi_PG_part=sparse(size(D,2),length(YPhi_PG));
%         for j=1:length(PG_part_location)
%             index_unit_no=ceil(PG_part_location(j)/T);
%             index_time_no=mod(PG_part_location(j)-1,T)+1;
%             YPhi_PG_part(:,(index_unit_no-1)*T*R*(Lk-1)*T+(index_time_no-1)*T*R*(Lk-1)+1:...
%                     (index_unit_no-1)*T*R*(Lk-1)*T+index_time_no*T*R*(Lk-1))=...
%                 -1*Aineq_ramp_limt_up(i,PGit_location(PG_part_location(j)))*diag(ones(R*T*(Lk-1),1));
%         end
%     end
%
%     constraint_pai_5((i-1)*size(D,2)+1:i*size(D,2),YPhi_PG)=YPhi_PG_part;
%     beq_constraint_pai_5=[beq_constraint_pai_5;b_part_5];
% end
% constraint_pai_5(1:size(D,2)*size(Aineq_ramp_limt_up,1),pai_5_location_upper)=part_pai_5;
% Aeq_constraint_pai_5=[Aeq_constraint_pai_5;constraint_pai_5];
%
% %Aineq_ramp_limit_lower
% part_pai_5=[];
% for i=1:size(Aineq_ramp_limt_down,1)
%     part_pai_5=blkdiag(part_pai_5,d');
% end
%
% constraint_pai_5=sparse(size(Aineq_ramp_limt_down,1),total_var_num);
% constraint_pai_5(:,1:x_num)=Aineq_ramp_limt_down(:,1:x_num);
% constraint_pai_5(:,Y0_PG)=Aineq_ramp_limt_down(:,PGit_location);
% constraint_pai_5(:,pai_5_location_down)=part_pai_5;
% Aineq_constraint_pai_5=[Aineq_constraint_pai_5;constraint_pai_5];
% bineq_constraint_pai_5=[bineq_constraint_pai_5;bineq_ramp_limt_down];
%
% part_pai_5=[];
% constraint_pai_5=sparse((size(C,2))*size(Aineq_ramp_limt_down,1),total_var_num);
%
% for i=1:size(Aineq_ramp_limt_down,1)
%     part_pai_5=blkdiag(part_pai_5,C');
%     b_part_5=sparse(size(C',1),1);
%     PG_part_location=find(Aineq_ramp_limt_down(i,PGit_location)~=0);
%     if(~isempty(PG_part_location))
%         YP_PG_part=sparse(size(C,2),length(YP_PG));
%         for j=1:length(PG_part_location)
%             index_unit_no=ceil(PG_part_location(j)/T);
%             index_time_no=mod(PG_part_location(j)-1,T)+1;
%             YP_PG_part(:,(index_unit_no-1)*T*R*T+(index_time_no-1)*R*T+1:(index_unit_no-1)*T*R*T+index_time_no*R*T)=...
%                 -1*Aineq_ramp_limt_down(i,PGit_location(PG_part_location(j)))*diag(ones(R*T,1));
%         end
%     end
%
%     constraint_pai_5((i-1)*size(C,2)+1:i*size(C,2),YP_PG)=YP_PG_part;
%
%     beq_constraint_pai_5=[beq_constraint_pai_5;b_part_5];
% end
% constraint_pai_5(1:size(C,2)*size(Aineq_ramp_limt_down,1),pai_5_location_down)=part_pai_5;
% Aeq_constraint_pai_5=[Aeq_constraint_pai_5;constraint_pai_5];
%
%
% part_pai_5=[];
% constraint_pai_5=sparse((size(D,2))*size(Aineq_ramp_limt_down,1),total_var_num);
% for i=1:size(Aineq_ramp_limt_down,1)
%     part_pai_5=blkdiag(part_pai_5,D');
%     b_part_5=sparse(size(D',1),1);
%
%      PG_part_location=find(Aineq_ramp_limt_down(i,PGit_location)~=0);
%     if(~isempty(PG_part_location))
%         YPhi_PG_part=sparse(size(D,2),length(YPhi_PG));
%         for j=1:length(PG_part_location)
%             index_unit_no=ceil(PG_part_location(j)/T);
%             index_time_no=mod(PG_part_location(j)-1,T)+1;
%             YPhi_PG_part(:,(index_unit_no-1)*T*R*(Lk-1)*T+(index_time_no-1)*T*R*(Lk-1)+1:...
%                     (index_unit_no-1)*T*R*(Lk-1)*T+index_time_no*T*R*(Lk-1))=...
%                 -1*Aineq_ramp_limt_down(i,PGit_location(PG_part_location(j)))*diag(ones(R*T*(Lk-1),1));
%         end
%     end
%
%     constraint_pai_5((i-1)*size(D,2)+1:i*size(D,2),YPhi_PG)=YPhi_PG_part;
%     beq_constraint_pai_5=[beq_constraint_pai_5;b_part_5];
% end
% constraint_pai_5(1:size(D,2)*size(Aineq_ramp_limt_up,1),pai_5_location_down)=part_pai_5;
% Aeq_constraint_pai_5=[Aeq_constraint_pai_5;constraint_pai_5];

% Aineq_constraint_pai_5=[Aineq_constraint_pai_5;constraint_pai_5];
% bineq_constraint_pai_5=[bineq_constraint_pai_5;bineq_ramp_limt_up];
%
% part_pai_5=[];
% for i=1:size(Aineq_ramp_limt_up,1)
%     part_pai_5=blkdiag(part_pai_5,C');
% end
% part_YP_1_T=diag(-1*ones(R_wan_len*T,1))+diag(ones(R*(T-1),1),-1*R_wan_len);
% part_YP=[];
% for i=1:N
%     part_YP=sparse(blkdiag(part_YP,part_YP_1_T));
% end
% constraint_pai_5=sparse((size(C,2)+size(D,2))*size(Aineq_ramp_limt_up,1),total_var_num);
% constraint_pai_5(1:size(C,2)*size(Aineq_ramp_limt_up,1),YP_PG)=part_YP;
% constraint_pai_5(1:size(C,2)*size(Aineq_ramp_limt_up,1),pai_5_location_upper)=part_pai_5;
%
% part_pai_5=[];
% for i=1:size(Aineq_ramp_limt_up,1)
%     part_pai_5=blkdiag(part_pai_5,D');
% end
% part_YPhi_1_T=sparse(diag(-1*ones(R_wan_len*(Lk-1)*T,1)))+sparse(diag(ones(R_wan_len*(T-1)*(Lk-1),1),-1*R_wan_len*(Lk-1)));
% part_YPhi=[];
% for i=1:N
%     part_YPhi=blkdiag(part_YPhi,part_YPhi_1_T);
% end
% constraint_pai_5(size(C,2)*size(Aineq_ramp_limt_up,1)+1:(size(C,2)+size(D,2))*size(Aineq_ramp_limt_up,1),YPhi_PG)=part_YPhi;
% constraint_pai_5(size(C,2)*size(Aineq_ramp_limt_up,1)+1:(size(C,2)+size(D,2))*size(Aineq_ramp_limt_up,1),pai_5_location_upper)=part_pai_5;
%
% Aeq_constraint_pai_5=[Aeq_constraint_pai_5;constraint_pai_5];
% beq_constraint_pai_5=[beq_constraint_pai_5;sparse((size(C,2)+size(D,2))*size(Aineq_ramp_limt_up,1),1)];

%Aineq_ramp_limit_lower
% part_pai_5=[];
% for i=1:size(Aineq_ramp_limt_down,1)
%     part_pai_5=blkdiag(part_pai_5,d');
% end
%
% constraint_pai_5=sparse(size(Aineq_ramp_limt_down,1),total_var_num);
% constraint_pai_5(:,1:x_num)=Aineq_ramp_limt_down(:,1:x_num);
% constraint_pai_5(:,Y0_PG)=Aineq_ramp_limt_down(:,x_num+1:x_num+PGit_num);
% constraint_pai_5(:,pai_5_location_down)=part_pai_5;
%
% Aineq_constraint_pai_5=[Aineq_constraint_pai_5;constraint_pai_5];
% bineq_constraint_pai_5=[bineq_constraint_pai_5;bineq_ramp_limt_down];
%
% part_pai_5=[];
% for i=1:size(Aineq_ramp_limt_down,1)
%     part_pai_5=blkdiag(part_pai_5,C');
% end
% part_YP_1_T=[];
% part_YP_1_T=diag(ones(R_wan_len*T,1))+diag(-1*ones(R_wan_len*(T-1),1),-1*R_wan_len);
% part_YP=[];
% for i=1:N
%     part_YP=blkdiag(part_YP,part_YP_1_T);
% end
% constraint_pai_5=sparse((size(C,2)+size(D,2))*size(Aineq_ramp_limt_down,1),total_var_num);
% constraint_pai_5(1:size(C,2)*size(Aineq_ramp_limt_down,1),YP_PG)=part_YP;
% constraint_pai_5(1:size(C,2)*size(Aineq_ramp_limt_down,1),pai_5_location_down)=part_pai_5;
%
% part_pai_5=[];
% for i=1:size(Aineq_ramp_limt_down,1)
%     part_pai_5=blkdiag(part_pai_5,D');
% end
% part_YPhi_1_T=sparse(diag(ones(R_wan_len*(Lk-1)*T,1)))+sparse(diag(-1*ones(R_wan_len*(T-1)*(Lk-1),1),-1*R_wan_len*(Lk-1)));
% part_YPhi=[];
% for i=1:N
%     part_YPhi=blkdiag(part_YPhi,part_YPhi_1_T);
% end
% constraint_pai_5(size(C,2)*size(Aineq_ramp_limt_down,1)+1:(size(C,2)+size(D,2))*size(Aineq_ramp_limt_down,1),YPhi_PG)=part_YPhi;
% constraint_pai_5(size(C,2)*size(Aineq_ramp_limt_down,1)+1:(size(C,2)+size(D,2))*size(Aineq_ramp_limt_down,1),pai_5_location_down)=part_pai_5;
%
% Aeq_constraint_pai_5=[Aeq_constraint_pai_5;constraint_pai_5];
% beq_constraint_pai_5=[beq_constraint_pai_5;sparse((size(C,2)+size(D,2))*size(Aineq_ramp_limt_down,1),1)];

%% windLoss
Aineq_constraint_pai_6=[];
bineq_constraint_pai_6=[];

Aeq_constraint_pai_6=[];
beq_constraint_pai_6=[];
if(param.windLoss==1)
  part_pai_6_d=[];
    part_pai_6_C=[];
    part_pai_6_D=[];
    
    YP_Aineq_windLoss=sparse(size(Aineq_windLoss_constraint,1),length(YP_windLoss));
    
    YP_Aeq_windLoss=sparse(size(C,2)*size(Aineq_windLoss_constraint,1),length(YP_windLoss));
    
    YPhi_Aeq_windLoss=sparse(size(D,2)*size(Aineq_windLoss_constraint,1),length(YPhi_windLoss));
    
      bineq_constraint_pai_6_part=sparse(size(Aineq_windLoss_constraint,1),1);
       for i=1:size(Aineq_windLoss_constraint,1)
           
        part_pai_6_d=blkdiag(part_pai_6_d,d');
        part_pai_6_C=blkdiag(part_pai_6_C,C');
        part_pai_6_D=blkdiag(part_pai_6_D,D');
        
        beq_constraint_pai_6_part=sparse(size(C,2),1);
        
        windLoss_part_location=find(Aineq_windLoss_constraint(i,windLoss_location)~=0);
        PWrt_part_location=find(Aineq_windLoss_constraint(i,PWrt_location)~=0);
        
        YP_Aineq_windLoss(i,:)=Aineq_windLoss_constraint(i,windLoss_location(windLoss_part_location))*...
            YP_miu(windLoss_in_Y0(windLoss_part_location),windLoss_in_YP);

        for k=1:length(windLoss_part_location)
            [YP_windLoss_part_location_row,YP_windLoss_part_location_col]=find(YP_part(windLoss_in_Y0(windLoss_part_location(k)),:)~=0);
            YP_Aeq_windLoss((i-1)*size(C,2)+1:i*size(C,2),YP_windLoss_part_location_col-length(YP_PG)-length(YP_Seita)-length(YP_Zit))=-1*Aineq_windLoss_constraint(i,windLoss_location(windLoss_part_location(k)))*...
                model_Pwan2PW_coeficent((windLoss_in_Y0(windLoss_part_location(k))-1)*size(C,2)+1:windLoss_in_Y0(windLoss_part_location(k))*size(C,2),...
                YP_windLoss_part_location_col);
            
            YPhi_windLoss_part_location=find(YPhi_part(windLoss_in_Y0(windLoss_part_location(k)),:)~=0);
            YPhi_Aeq_windLoss((i-1)*size(D,2)+1:i*size(D,2),YPhi_windLoss_part_location-length(YPhi_PG)-length(YPhi_Seita)-length(YPhi_Zit))=-1*Aineq_windLoss_constraint(i,windLoss_location(windLoss_part_location(k)))*diag(ones(R_wan_len*(Lk-1),1));
             
        end
        if(~isempty(PWrt_part_location))
            for r=1:length(PWrt_part_location)
                beq_constraint_pai_6_part=beq_constraint_pai_6_part+...
                    Aineq_windLoss_constraint(i,PWrt_location(PWrt_part_location(r)))*Pwan2PW_coeficent(PWrt_part_location(r),:)';
                bineq_constraint_pai_6_part(i,1)=bineq_constraint_pai_6_part(i,1)+...
                    -1*Aineq_windLoss_constraint(i,PWrt_location(PWrt_part_location(r)))*miu_average(PWrt_part_location(r));
            end
        end
        beq_constraint_pai_6=[beq_constraint_pai_6;beq_constraint_pai_6_part];
       end
    constraint_pai_6=sparse(size(Aineq_windLoss_constraint,1),total_var_num);
    constraint_pai_6(:,x_location)=Aineq_windLoss_constraint(:,x_location);
    constraint_pai_6(:,Y0_windLoss)=Aineq_windLoss_constraint(:,windLoss_location);
    constraint_pai_6(:,YP_windLoss)=YP_Aineq_windLoss;
    constraint_pai_6(:,pai_6_location)=part_pai_6_d;
    
    Aineq_constraint_pai_6=[Aineq_constraint_pai_6;constraint_pai_6];
    bineq_constraint_pai_6=[bineq_constraint_pai_6;bineq_windLoss_constraint+bineq_constraint_pai_6_part];
    
    %eq
    constraint_pai_6=sparse((size(C,2)+size(D,2))*size(Aineq_windLoss_constraint,1),total_var_num);
    constraint_pai_6(1:size(C,2)*size(Aineq_windLoss_constraint,1),YP_windLoss)=YP_Aeq_windLoss;
    constraint_pai_6(1:size(C,2)*size(Aineq_windLoss_constraint,1),pai_6_location)=part_pai_6_C;
    constraint_pai_6(size(C,2)*size(Aineq_windLoss_constraint,1)+1:(size(C,2)+size(D,2))*size(Aineq_windLoss_constraint,1),YPhi_windLoss)=YPhi_Aeq_windLoss;
    constraint_pai_6(size(C,2)*size(Aineq_windLoss_constraint,1)+1:(size(C,2)+size(D,2))*size(Aineq_windLoss_constraint,1),pai_6_location)=part_pai_6_D;
    
    Aeq_constraint_pai_6=[Aeq_constraint_pai_6;constraint_pai_6];
    beq_constraint_pai_6=[beq_constraint_pai_6;sparse((size(D,2))*size(Aineq_windLoss_constraint,1),1)];
end
%% DRO model

Aineq_two_bin_var_constraint=[Aineq_constraint_min_upordown_time;Aineq_constraint_start_cost];
bineq_two_bin_var_constraint=[bineq_constraint_min_upordown_time;bineq_constraint_start_cost];

Aeq_two_bin_var_constraint=[Aeq_constraints_state;Aeq_constraints_initial_statues];
beq_two_bin_var_constraint=[beq_constraints_state;beq_constraints_initial_statues];

Aineq_two_bin_var=sparse(size(Aineq_two_bin_var_constraint,1),total_var_num);
Aineq_two_bin_var(:,x_location)=Aineq_two_bin_var_constraint(:,x_location);

Aeq_two_bin_var=sparse(size(Aeq_two_bin_var_constraint,1),total_var_num);
Aeq_two_bin_var(:,x_location)=Aeq_two_bin_var_constraint(:,x_location);


Aineq=[Aineq_two_bin_var;Aineq_constraint_pai_1;Aineq_constraint_pai_2;Aineq_constraint_pai_3;Aineq_constraint_pai_4;Aineq_constraint_pai_5;Aineq_constraint_pai_6];%
bineq=[bineq_two_bin_var_constraint;bineq_constraint_pai_1;bineq_constraint_pai_2;bineq_constraint_pai_3;bineq_constraint_pai_4;bineq_constraint_pai_5;bineq_constraint_pai_6];%
Aeq=[Aeq_two_bin_var;Aeq_constraint_pai_1;Aeq_constraint_pai_2;Aeq_constraint_pai_3;Aeq_constraint_pai_4;Aeq_constraint_pai_5;Aineq_constraint_pai_4_1;Aeq_constraint_pai_4_1;Aeq_constraint_pai_6];%
beq=[beq_two_bin_var_constraint;beq_constraint_pai_1;beq_constraint_pai_2;beq_constraint_pai_3;beq_constraint_pai_4;beq_constraint_pai_5;bineq_constraint_pai_4_1;beq_constraint_pai_4_1;beq_constraint_pai_6];%


lb=sparse(total_var_num,1);
lb(Eta_location,1)=-inf;
lb(Y_location,1)=-inf;
% lb(Y0_LoadLoss,1)=0;
% lb(YP_LoadLoss,1)=0;
% lb(YPhi_LoadLoss,1)=0;
ub=inf*ones(total_var_num,1);
ub(uit_location,1)=1;
ub(sit_location,1)=1;
ub(dit_location,1)=1;

ctype='';
ctype(1:total_var_num)='C';
ctype(uit_location)='B';
ctype(sit_location)='B';
ctype(dit_location)='B';

%% UC model
% first-order uit sit dit Sit
% f_sit=reshape(repmat(ThHot_cost_start,1,T)',N*T,1);
% f_Sit=ones(N*T,1);
% f_Zit=ones(N*T,1);
% f_x=[sparse(N*T,1);f_sit;sparse(N*T,1);f_Sit];
%
% f_d=[sparse(N*T+NodeNum*T,1);f_Zit];% PGit(N*T) Setait(NodeNum*T) Zit(N*T)
% f=[f_x;f_d;sparse(PWrt_num,1)];
%
% Aeq=[Aeq_constraints_state;Aeq_constraints_initial_statues;Aeq_DCPowerFlow];%];Aeq_constraint_power_balance
% beq=[beq_constraints_state;beq_constraints_initial_statues;beq_DCPowerFlow];%];beq_constraint_power_balance
% Aineq=[Aineq_constraint_min_upordown_time;Aineq_constraint_start_cost;Aineq_genration_limit;Aineq_linear_approximation;Aineq_ramp_limt;Aineq_DCPowerFlow];%
% bineq=[bineq_constraint_min_upordown_time;bineq_constraint_start_cost;bineq_genration_limit;bineq_linear_approximation;bineq_ramp_limt;bineq_DCPowerFlow];%;
% lb=[sparse(x_num,1);sparse(N*T,1);-inf*ones((NodeNum+N)*T,1);P_Wind_Min];
% ub=[ones(3*N*T,1);inf*ones(N*T,1);inf*ones((NodeNum+2*N)*T,1);P_Wind_Max];
% ctype='';
% ctype(1:3*N*T)='B';
% ctype(3*N*T+1:total_num)='C';
%%
model.Q=Q;
model.f=f;
model.Aeq=Aeq;
model.beq=beq;
model.Aineq=Aineq;
model.bineq=bineq;
model.lb=lb;
model.ub=ub;
model.ctype=ctype;
model.Seitait_in_y_location=Seitait_in_y_location;
model.uit_location=uit_location;
model.sit_location=sit_location;
model.dit_location=dit_location;
model.Sit_location=Sit_location;
model.PGit_location=PGit_location;
model.Seita_location=Seitait_location;
model.Zit_location=Zit_location;
model.Y0_location=Y0_location;
model.YP_location=YP_location;
model.YPhi_location=YPhi_location;
model.linearDecisionRule.Y0=Y0_part;
model.linearDecisionRule.YP=YP_part;
model.linearDecisionRule.YPhi=YPhi_part;
model.linearDecisionRule.model_PW2P=model_Pwan2PW_coeficent;
model.linearDecisionRule.PW2P=Pwan2PW_coeficent;
model.linearDecisionRule.YP_miu=YP_miu;
model.miu=miu;
model.K=K;
model.P_wan=P_wan;
% model.node_sequence=UC_model.node_sequnce;

model.PG_in_Y0=PG_in_Y0;
model.PG_in_YP=PG_in_YP;
model.PG_in_YPhi=PG_in_YPhi;
if(param.windLoss==1)
model.windLoss_in_Y0=windLoss_in_Y0;
model.windLoss_in_YP=windLoss_in_YP;
model.windLoss_in_YPhi=windLoss_in_YPhi;
end

model.Y0_part=Y0_part;
model.YP_part=YP_part;
model.YPhi_part=YPhi_part;

model.Y0_location=Y0_location;
model.YP_location=YP_location;
model.YPhi_location=YPhi_location;

model.data_wind_origin=data_wind; 
model.Ckl_origin=Ckl;
model.data_wind_PCA=P_wind_PCA;
end


% function [eq,ineq]=DC_flow_constraint(NodeNum,N,T,Bus_G,Bus_D,ThPimin,ThPimax,B,bus_P,branchI,branchJ,branchX,branchP,wind_node)
% Aeq_constraints_DCPowerFlow=[];
% beq_constraints_DCPowerFlow=[];
% 
% Aineq_constraints_DCPowerFlow=[];
% bineq_constraints_DCPowerFlow=[];
% 
% R=length(wind_node);
% 
% PG=sparse(1,NodeNum);
% PD=sparse(1,NodeNum);
% PG(1,Bus_G)=1;
% PD(1,Bus_D)=1;
% 
% P_index=1;
% D_index=1;
% for i=1:NodeNum
%     if(PG(i)==1&&PD(i)==1)
%         P_no=find(i==Bus_G);
%         D_no=find(i==Bus_D);
%         PW_no=find(i==wind_node);
%         
%         uit=sparse(T,N*T);
%         PitWan=sparse(T,N*T);
%         Seita=sparse(T,NodeNum*T);
%         
%         uit(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag(ThPimin(P_no)*ones(1,T)));
%         PitWan(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag((ThPimax(P_no)-ThPimin(P_no))*ones(1,T)));
%         coefficient=[];
%         for j=1:NodeNum
%             coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
%         end
%         Seita=-1*coefficient;
%         
%         Pit=sparse(T,N*T);
%         Pit(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag(ones(1,T)));
%         
%         PWrt=sparse(T,R*T);
%         if(~isempty(PW_no))
%             PWrt=[];
%             for t=1:T
%                 PW_part=sparse(1,R);
%                 PW_part(1,PW_no)=1;
%                 PWrt=blkdiag(PWrt,PW_part);
%             end
%         end
%         
%         
%         Aeq_DCPowerFlow=[sparse(T,4*N*T),Pit,Seita,sparse(T,N*T),PWrt];
%         beq_DCPowerFlow=[bus_P(:,D_no)];
%         
%         Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
%         beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
%         
%         P_index=P_index+1;
%         D_index=D_index+1;
%     end
%     if(PG(i)==1&&PD(i)==0)
%         P_no=find(i==Bus_G);
%         PW_no=find(i==wind_node);
%         
%         uit=sparse(T,N*T);
%         PitWan=sparse(T,N*T);
%         Seita=sparse(T,NodeNum*T);
%         
%         uit(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag(ThPimin(P_no)*ones(1,T)));
%         PitWan(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag((ThPimax(P_no)-ThPimin(P_no))*ones(1,T)));
%         coefficient=[];
%         for j=1:NodeNum
%             coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
%         end
%         Seita=-1*coefficient;
%         
%         
%         Pit=sparse(T,N*T);
%         Pit(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag(ones(1,T)));
%         
%         PWrt=sparse(T,R*T);
%         if(~isempty(PW_no))
%             PWrt=[];
%             for t=1:T
%                 PW_part=sparse(1,R);
%                 PW_part(1,PW_no)=1;
%                 PWrt=blkdiag(PWrt,PW_part);
%             end
%         end
%         
%         Aeq_DCPowerFlow=[sparse(T,4*N*T),Pit,Seita,sparse(T,N*T),PWrt];
%         beq_DCPowerFlow=[sparse(T,1)];
%         
%         Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
%         beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
%         
%         
%         P_index=P_index+1;
%     end
%     if(PG(i)==0&&PD(i)==1)
%         
%         D_no=find(i==Bus_D);
%         PW_no=find(i==wind_node);
%         Seita=sparse(T,NodeNum*T);
%         coefficient=[];
%         for j=1:NodeNum
%             coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
%         end
%         Seita=-1*coefficient;
%         
%         PWrt=sparse(T,R*T);
%         if(~isempty(PW_no))
%             PWrt=[];
%             for t=1:T
%                 PW_part=sparse(1,R);
%                 PW_part(1,PW_no)=1;
%                 PWrt=blkdiag(PWrt,PW_part);
%             end
%         end
%         
%         Aeq_DCPowerFlow=[sparse(T,5*N*T),Seita,sparse(T,N*T),PWrt];
%         beq_DCPowerFlow=[bus_P(:,D_no)];
%         Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
%         beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
%         D_index=D_index+1;
%     end
%     if(PG(i)==0&&PD(i)==0)
%         Seita=sparse(T,NodeNum*T);
%         PW_no=find(i==wind_node);
%         
%         coefficient=[];
%         for j=1:NodeNum
%             coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
%         end
%         Seita=coefficient;
%         
%         PWrt=sparse(T,R*T);
%         if(~isempty(PW_no))
%             PWrt=[];
%             for t=1:T
%                 PW_part=sparse(1,R);
%                 PW_part(1,PW_no)=1;
%                 PWrt=blkdiag(PWrt,PW_part);
%             end
%         end
%         
%         Aeq_DCPowerFlow=[sparse(T,5*N*T),Seita,sparse(T,N*T),PWrt];
%         beq_DCPowerFlow=[sparse(T,1)];
%         Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
%         beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
%     end
%     
% end
% 
% %Seita=0
% % Seita=sparse(T,NodeNum*T);
% % Seita(:,1:T)=sparse(diag(ones(1,T)));
% % Aeq_DCPowerFlow=[sparse(T,5*N*T),Seita,sparse(T,N*T),sparse(T,R*T)];
% % beq_DCPowerFlow=[sparse(T,1)];
% % Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
% % beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
% 
% Aineq_DCPowerFlow=[];
% bineq_DCPowerFlow=[];
% 
% 
% for index=1:length(branchI)
%     Seita_i=branchI(index);
%     Seita_j=branchJ(index);
%     Seita=sparse(T,NodeNum*T);
%     
%     Seita(1:T,(Seita_i-1)*T+1:Seita_i*T)=diag((1/branchX(index))*ones(1,T));
%     Seita(1:T,(Seita_j-1)*T+1:Seita_j*T)=diag(-1*(1/branchX(index))*ones(1,T));
%     
%     Aineq_DCPowerFlow=sparse([Aineq_DCPowerFlow;sparse(T,5*N*T),Seita,sparse(T,N*T),sparse(T,R*T)]);
%     bineq_DCPowerFlow=[bineq_DCPowerFlow;branchP(index)*ones(T,1)];
%     
%     Aineq_DCPowerFlow=sparse([Aineq_DCPowerFlow;sparse(T,5*N*T),-1*Seita,sparse(T,N*T),sparse(T,R*T)]);
%     bineq_DCPowerFlow=[bineq_DCPowerFlow;branchP(index)*ones(T,1)];
%     
%     
% end
% Aineq_constraints_DCPowerFlow=[Aineq_constraints_DCPowerFlow;Aineq_DCPowerFlow];
% bineq_constraints_DCPowerFlow=[bineq_constraints_DCPowerFlow;bineq_DCPowerFlow];
% 
% 
% eq.A=Aeq_constraints_DCPowerFlow;
% eq.b=beq_constraints_DCPowerFlow;
% 
% ineq.A=Aineq_constraints_DCPowerFlow;
% ineq.b=bineq_constraints_DCPowerFlow;
% 
% 
% end
