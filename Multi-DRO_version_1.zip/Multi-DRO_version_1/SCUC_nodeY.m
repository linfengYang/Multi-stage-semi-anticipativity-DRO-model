%% ***************************************************************
%               Author��Lingfeng Yang,Jiangyao Luo,Yan Xu,Zhenrong Zhang,Zhaoyang Dong
%               Email��ylf@gxu.edu.cn,landiljy@163.com
%               Start date:2017.12.7
%               Finish date:2017.12.28 
%               Function description:Compute the network admittance matrix
%% ***************************************************************
function Y = SCUC_nodeY(SCUC_data, type) 

    Y.type = type;
    if strcmp(type, 'DC') == 1
        SCUC_data.branch.R = sparse(size(SCUC_data.branch.R,1),1);
        SCUC_data.branchTransformer.R = sparse(size(SCUC_data.branchTransformer.R,1),1);
    end


    n = SCUC_data.baseparameters.busN;  %%%  

    % Admittance matrix of branches without transformer; �γ�֧·���ɾ���
    Y1        = sparse(1./(SCUC_data.branch.R + 1i * SCUC_data.branch.X));
    Y11       = sparse(SCUC_data.branch.I,SCUC_data.branch.J,Y1,n,n);
    branchYij = sparse(-Y11-Y11.');                     %%%  ֧·���ɵķǶԽ�Ԫ��

    Ya        = sparse(SCUC_data.branch.I,SCUC_data.branch.J,1i*SCUC_data.branch.B,n,n);
    Yc        = sparse(Ya+Ya.');
    if strcmp(type, 'DC') == 1
        Yc = 0;%ֱ�����������ǶԵص���
    end
    branchYii = sparse(diag(sum(-branchYij)+sum(Yc)));  %%%  �γ�֧·���ɾ���Խ�Ԫ��
    branchY   = sparse(branchYij+branchYii);            %%%  �γ�֧·����

    if ~isempty(SCUC_data.branchTransformer.I)
        %Admittance matrix of branches with transformer;    ��ѹ��֧·����
        Y2                 = sparse(1./(SCUC_data.branchTransformer.R+1i*SCUC_data.branchTransformer.X));
        transformerYij     = sparse(SCUC_data.branchTransformer.I,SCUC_data.branchTransformer.J,-SCUC_data.branchTransformer.K.*Y2,n,n);
        transformerYij     = transformerYij+transformerYij.';                                                %%%  ��ѹ�����ɷǶԽ�Ԫ��
        transformerYii     = sparse(SCUC_data.branchTransformer.I,SCUC_data.branchTransformer.I,(SCUC_data.branchTransformer.K.^2).*Y2,n,n);  %%%  ��ѹ�����ɶ�Ӧi�Խ�Ԫ��
        transformerYjj     = sparse(SCUC_data.branchTransformer.J,SCUC_data.branchTransformer.J,Y2,n,n);                           %%%  ��ѹ�����ɶ�ӦJ�Խ�Ԫ��
        branchTransformerY = sparse(transformerYii+transformerYjj+transformerYij);                           %%%  ��ѹ��֧·����
    end
    %Network admittance matrix;   �γɽڵ㵼�ɾ���
    if ~isempty(SCUC_data.branchTransformer.I)
        YY = sparse(branchY+branchTransformerY);  %%%  ֧·���ɣ���ѹ������
    else
        YY = sparse(branchY);  %%%  ֧·���ɣ���ѹ������
    end

    Y.G = sparse(real(YY));
    Y.B = sparse(imag(YY));
end