%������������PCA�ķ�Ԥ�ڣ�������PCA�İ�Ԥ��
clear all;
PCA=[2,8,13];
WindRGap={[0.01,0.05,0.1,0.5],...
    [0.02],...
    [0.01,0.05,0.1,0.5]};
param.T_wan=24;%T_wan<=24,T_wan=24 is normal; T_wan<24 can reduce the number of YP
param.T_windows=24;
param.isPCA=1;
param.eq=1;
param.WindRGap=0.01;
param.semi_participation=0;
param.windLoss=1;
param.LDR=0; %1 is full, 0 is non-anticipativity
param.windcoefficient=0.6;
param.RampRate=1;
param.LossCost=1000;
param.divition=0;
param.partition=0;
param.phi=0;

FileFoder=fullfile('.\data\');
Result_Folder='result\';
dirOutput=dir(fullfile(FileFoder,'SCUC*'));
FileList={dirOutput.name}';
File_num=size(FileList,1);

index=1;
while(1)
    for File_index=File_num-2:-1:1
        while(index<=3)
            for j=1:length(WindRGap{index})
                param.WindRGap=WindRGap{index}(j);
                param.PCA=PCA(File_index);
                dataName=FileList{File_index};
                FilePath_thermal=strcat('data\',dataName);
                FilePath_Wind='data\Wind_power.xlsx';
                
                data=ReadDataSCUC(FilePath_thermal);
                B=DCOPFNodeY(data,param);
                data.B=B;
%                 [obj_SP,time_SP]=function_stochastic_programming(data,FilePath_Wind,param);
                data_wind_History= function_readWindData(data,FilePath_Wind,param);
                %�����ܵ�UCģ��
                [UC_model] = function_DC_UCmodel_wind_loss(data,data_wind_History,param);
                %���ֽڵ�
                % [ PI, allNodes,PINumber ] = partitionNode( data.baseparameters.busN, data.baseparameters.busN, 1,1 );
                %�����������ݽ��л���
                % [data_Partition] = function_NodeDataPartition(data,PI,allNodes,PINumber,data_wind_History,B);
                %��������Ƭ��ģ��
                % [model_partition] = function_model_location_partition(UC_model,data_Partition,data,PI,allNodes,param.T_wan);
                % [MDROmodeltest] =function_construct_DRO_MILP_model(UC_model,data,data_wind_History,param); %��ʽԼ������
                
                % [MDROmodeltest] = function_construct_DRO_MILP_model(UC_model,data,data_wind_History,param);
                %     [MDROmodeltest] = function_DC_UC_seimMDRO_model_without_PCA(UC_model,data,data_wind_History,param);
                if(param.semi_participation==1)
                    if(param.isPCA==0)
                        [MDROmodeltest] = function_DC_UC_seimMDRO_model_without_PCA(UC_model,data,data_wind_History,param);
                    else
                        [MDROmodeltest] = function_construct_semiDRO_MILP_model_with_PCA(UC_model,data,data_wind_History,param);
                    end
                else
                    if(param.isPCA==1)
                        [MDROmodeltest] = function_construct_DRO_MILP_model_with_PCA(UC_model,data,data_wind_History,param);
%                         [MDROmodeltest] = function_DC_UC_RO_model_with_PCA(UC_model,data,data_wind_History,param);
%                                 [MDROmodeltest] = function_construct_DRO_MILP_model(UC_model,data,data_wind_History,param);
                    else
                        [MDROmodeltest] = function_DC_UC_MDRO_model_without_PCA(UC_model,data,data_wind_History,param);
%                         [MDROmodeltest] = function_DC_UC_RO_model_without_PCA(UC_model,data,data_wind_History,param);
%                         [MDROmodeltest] = function_DC_UC_DRO_model_consider_wind(data,data_wind_History,param);
                    end
                end
                
                
                data_wind_origin=MDROmodeltest.data_wind_origin;
                Ckl_origin=MDROmodeltest.Ckl_origin;
                
                if(param.semi_participation==1)
                    data_wind_anticipated=MDROmodeltest.data_wind_anticipated;
                    Ckl_anticipated=MDROmodeltest.Ckl_anticipated;
                    
                end
                if(param.isPCA==1)
                    
                    K=MDROmodeltest.K;
                end
                
                data_wind=[];
                data_wind_part=[];
                Clk=[];
                Clk_windLoss=[];
                Clk_part=[];
                K_part=[];
                for i=1:param.T_windows
                    if(i<param.T_windows)
                        if(param.semi_participation==1)
                            data_wind_part=[data_wind_part;data_wind_origin(1:i*data.Wind.wind_Number,:);data_wind_anticipated((i-1)*data.Wind.wind_Number+1:i*data.Wind.wind_Number,:)];
                            Clk_part=[Clk_part;Ckl_origin(1:i*data.Wind.wind_Number,:);Ckl_anticipated((i-1)*data.Wind.wind_Number+1:i*data.Wind.wind_Number,:)];
                        else
                            if(param.isPCA==0)
                                if(param.LDR==0)
                                    data_wind_part=[data_wind_part;data_wind_origin(1:i*data.Wind.wind_Number,:)];
                                    Clk_part=[Clk_part;Ckl_origin(1:i*data.Wind.wind_Number,:)];
                                else
                                    data_wind_part=[data_wind_part;data_wind_origin(1:param.T_windows*data.Wind.wind_Number,:)];
                                    Clk_part=[Clk_part;Ckl_origin(1:param.T_windows*data.Wind.wind_Number,:)];
                                end
                            else
                                data_wind_part=[data_wind_part;data_wind_origin(1:i*data.Wind.wind_Number,:)];
                                Clk_part=[Clk_part;Ckl_origin];
                                K_part=[K_part;K];
                            end
                        end
                    else
                        
                        if(param.isPCA==0)
                            data_wind_part=[data_wind_part;data_wind_origin(1:i*data.Wind.wind_Number,:)];
                            Clk_part=[Clk_part;Ckl_origin(1:i*data.Wind.wind_Number,:)];
                        else
                            data_wind_part=[data_wind_part;data_wind_origin(1:i*data.Wind.wind_Number,:)];
                            Clk_part=[Clk_part;Ckl_origin];
                            K_part=[K_part;K];
                        end
                    end
                end
                K_P=[];
                for i=1:data.baseparameters.unitN
                    data_wind=[data_wind;data_wind_part];
                    Clk=[Clk;Clk_part];
                    K_P=[K_P;K_part];
                end
                
                data_wind_Loss=[];
                K_wind_loss=[];
                for i=1:data.Wind.wind_Number
                    Clk_windLoss=[Clk_windLoss;Clk_part];
                    data_wind_Loss=[data_wind_Loss;data_wind_part];
                    K_wind_loss=[K_wind_loss;K_part];
                end
                
                
                
                
                
                % [MDROmodeltest] = function_construct_DRO_MILP_model_eq(UC_model,data,data_wind_History,param);
                % uk=sparse( 2*data.baseparameters.unitN*param.T_wan+data.baseparameters.busN*param.T_wan,1);
                % z_k1=sparse( 2*data.baseparameters.unitN*param.T_wan+data.baseparameters.busN*param.T_wan,1);
                % pk=sparse( 2*data.baseparameters.unitN*param.T_wan+data.baseparameters.busN*param.T_wan,1);
                % [model_partiton] = function_model_partition(UC_model,data,PI,allNodes,PINumber,param.T_windows,data_wind_History);
                
                
                
                % param.PI=PI;
                % param.allNodes=allNodes;
                % param.PINumber=PINumber;
                % for i=1:length(PI)
                %
                % %         [model] = function_DC_UCmodel_consider_wind(data_Partition{i});
                %          param.k=1;
                %         param.NoWind=0;
                % %         [MDROmodel{i}] = function_Universal_DRO_MILP_construct(model,data_Partition{i},data_Partition{i}.data_wind_history,...
                % %             data_Partition{i}.baseparameters.unitN,param.T_windows,param);
                % [MDROmodel{i}] =function_construct_DRO_MILP_model(model_partition{i},data_Partition{i},data_Partition{i}.data_wind_history,param);
                % end
                % [MDROmodel{i+1}]=function_Universal_DRO_QP_construct(model_partition{i+1},MDROmodel,data,data_Partition,PI,param.T_wan,param);
                
                %Z
                % [model] = function_DC_UCmodel_consider_wind(data);
                % model.Aineq=model.Aineq_DCPowerFlow;
                % model.bineq=model.bineq_DCPowerFlow;
                % model.Aeq=[];
                % model.beq=[];
                %         [MDROmodel{length(PI)+1}] = function_Universal_DRO_MILP_construct(model,data,data_wind_History,...
                %             data.baseparameters.unitN,param.T_windows,param);
                %         MDROmodel{length(PI)+1}.f=sparse(1,size(MDROmodel{length(PI)+1}.ctype,2));
                % [MDROmodel{length(PI)+1}] = function_DRO_MIQP_construct(model,data,data_Partition,PI,data_wind_History,...
                %             data.baseparameters.unitN,param.T_windows,param);
                % [MDROmodel{length(PI)+1}] = function_construct_QP(model,data,data_Partition,PI,data_wind_History,param.T_windows,param);
                % [MDROmodel{length(PI)+1}] = function_Universal_DRO_QP_construct(model,MDROmodel,data,data_Partition,PI,data_wind_History,param.T_windows,param);
                
                % for iter=1:Max_iter
                %     param.k=iter;
                %     for i=1:length(PI)
                %         if(data_Partition{i}.Wind.wind_Number~=0)
                %             param.NoWind=0;
                %             [model] = function_Universal_DRO_MILP_construct(model,data_Partition{i},data_Partition{i}.data_wind_history,...
                %                 data_Partition{i}.baseparameters.unitN,param.T_windows,param);
                %         else
                %             param.NoWind=1;
                %             [model] = function_Universal_DRO_MILP_construct(model,data_Partition{i},data_Partition{i+1}.data_wind_history,...
                %                 data_Partition{i}.baseparameters.unitN,param.T_windows,param);
                %             var_total_num=length(model.lb);
                %             Q=sparse(1,var_total_num);
                %             Q(1,model.y_location)=0.5*param.rho;
                %             Q=sparse(diag(Q));
                %             if(k==1)
                %                 z=sparse(length(model.y_location),1);
                %                 u=sparse(length(model.y_location),1);
                %             else
                %                 z=z_k;
                %                 u=z_k;
                %             end
                %             model.f(model.y_location,1)=model.f(model.y_location,1)+param.rho*(u-z);
                %             model.Q=Q;
                %         end
                % [MDRO_model] = function_construct_DRO_MILP_model(UC_model,data_Partition{i},data_Partition{i}.data_wind_history,param);
                
                disp('___________________________________________________________');
                disp(datestr(now,'yyyy-mm-dd HH:MM:SS'));
                disp(dataName);
                disp(num2str(param.PCA));
                disp(num2str(param.semi_participation));
                strlog='log\log_';
                strlog=strcat(strlog,'MDRO_',dataName);
                diary(strcat(strlog,'.txt'));
                diary on;
                [MDRO_resulttest] = solve(MDROmodeltest);
                diary off;
                
                %     end
                
                
                if(param.isPCA==1)
                    %PCA equation
                    Y0_equation=MDROmodeltest.Y0_equation;
                    YP_equation=MDROmodeltest.YP_equation;
                    A=[full(Y0_equation);full(YP_equation)];
                    b=[MDRO_resulttest.x(MDROmodeltest.Y0_location,:);MDRO_resulttest.x(MDROmodeltest.YP_location,:)];
                    tic
                    x=linsolve(A,full(b));
                    toc
                    x_Y0=x(1:length(MDROmodeltest.Y0_location_without_PCA));
                    x_YP=x(length(MDROmodeltest.Y0_location_without_PCA)+1:length(MDROmodeltest.Y0_location_without_PCA)+length(MDROmodeltest.YP_location_without_PCA));
                else
                    x_Y0=MDRO_resulttest.x(MDROmodeltest.Y0_location);
                    x_YP=MDRO_resulttest.x(MDROmodeltest.YP_location);
                end
                uit=reshape(MDRO_resulttest.x(UC_model.uit_location),param.T_windows,data.baseparameters.unitN)';
                
                PG_in_Y0=MDROmodeltest.PG_in_Y0_without_PCA;
                PG_in_YP=MDROmodeltest.PG_in_YP_without_PCA;
                
                windLoss_in_Y0=MDROmodeltest.windLoss_in_Y0_without_PCA;
                windLoss_in_YP=MDROmodeltest.windLoss_in_YP_without_PCA;
                
                
                Y0_part=MDROmodeltest.Y0_index_without_PCA;
                YP_part=MDROmodeltest.YP_index_without_PCA;
                
                Y0=Y0_part.*(repmat(x_Y0',size(Y0_part,1),1));
                YP=YP_part.*(repmat(x_YP',size(YP_part,1),1));
                
                x_num=length(UC_model.uit_location)+length(UC_model.sit_location)+length(UC_model.dit_location)+length(UC_model.Sit_location);
                Y0_PG=Y0(UC_model.PGit_location-x_num,PG_in_Y0);
                YP_PG=YP(UC_model.PGit_location-x_num,PG_in_YP);
                
                Y0_windLoss=Y0(UC_model.windLoss_location-x_num-length(UC_model.PWrt_location),windLoss_in_Y0);
                YP_windLoss=YP(UC_model.windLoss_location-x_num-length(UC_model.PWrt_location),windLoss_in_YP);
                
                if(param.phi==1)
                    x_YPhi=MDRO_resulttest.x(MDROmodeltest.YPhi_location);
                    
                    PG_in_YPhi=MDROmodeltest.PG_in_YPhi;
                    
                    windLoss_in_YPhi=MDROmodeltest.windLoss_in_YPhi;
                    
                    YPhi_part=MDROmodeltest.YPhi_part;
                    
                    YPhi=YPhi_part.*(repmat(x_YPhi',size(YPhi_part,1),1));
                    
                    YPhi_PG=YPhi(UC_model.PGit_location-x_num,PG_in_YPhi);
                    
                    YPhi_windLoss=YPhi(UC_model.windLoss_location-x_num-length(UC_model.PWrt_location),windLoss_in_YPhi);

                end
                
                if(param.isPCA==1)
                    K_PG=MDROmodeltest.K;%
                    %     K_windLoss=K_wind_loss(:,windLoss_in_YP);
                end
                
                if(param.isPCA==1)
                    Phi_PG=[];
                    Phi_windLoss=[];
                    for i=1:size(Clk,2)
                        
                        %                 Phi_PG=[Phi_PG,max(K_PG*(data_wind_origin(:,1)-MDROmodeltest.miu_average)-Ckl_origin(:,i),0)];
                        %                 Phi_windLoss=[Phi_windLoss,max(K_PG*data_wind_origin(:,1)-Ckl_origin(:,i),0)];
                        
                    end
                else
                    Phi_PG=[];
                    Phi_windLoss=[];
                    for i=1:size(Clk,2)
                        
                        Phi_PG=[Phi_PG,max(data_wind(:,1)-Clk(:,i),0)];
                        Phi_windLoss=[Phi_windLoss,max(data_wind_Loss(:,1)-Clk_windLoss(:,i),0)];
                        
                    end
                end
                
                if(param.isPCA==1)
                    PG=Y0_PG*ones(size(Y0_PG,2),1)+YP_PG*data_wind(:,1);%+0*repmat(reshape(Phi_PG(:,1:size(Phi_PG,2)-1)',size(Phi_PG,1)*(size(Phi_PG,2)-1),1),[size(Y0_PG,2),1])
                    PGit=reshape(PG,param.T_windows,data.baseparameters.unitN)';
                    
                    windLoss=Y0_windLoss*ones(size(Y0_windLoss,2),1)+YP_windLoss*data_wind_Loss(:,1);%+0*repmat(reshape(Phi_windLoss(:,1:size(Phi_windLoss,2)-1)',size(Phi_windLoss,1)*(size(Phi_windLoss,2)-1),1),[size(Y0_windLoss,2),1])
                    windLoss=reshape(windLoss,param.T_windows,data.Wind.wind_Number)';
                else
                    if(param.phi==1)
                    PG=Y0_PG*ones(size(Y0_PG,2),1)+YP_PG*data_wind(:,1)+YPhi_PG*reshape(Phi_PG(:,1:size(Phi_PG,2)-1)',size(Phi_PG,1)*(size(Phi_PG,2)-1),1);
                    PGit=reshape(PG,param.T_windows,data.baseparameters.unitN)';
                    
                    windLoss=Y0_windLoss*ones(size(Y0_windLoss,2),1)+YP_windLoss*data_wind_Loss(:,1)+YPhi_windLoss*reshape(Phi_windLoss(:,1:size(Phi_windLoss,2)-1)',size(Phi_windLoss,1)*(size(Phi_windLoss,2)-1),1);
                    windLoss=reshape(windLoss,param.T_windows,data.Wind.wind_Number)';
                    else
                        PG=Y0_PG*ones(size(Y0_PG,2),1)+YP_PG*data_wind(:,1);
                        PGit=reshape(PG,param.T_windows,data.baseparameters.unitN)';
                        
                        windLoss=Y0_windLoss*ones(size(Y0_windLoss,2),1)+YP_windLoss*data_wind_Loss(:,1);
                        windLoss=reshape(windLoss,param.T_windows,data.Wind.wind_Number)';
                    end
                end
                total_PGit=sum(PGit,1);
                total_windLoss=sum(windLoss,1);
                total_windPower=sparse(param.T_windows,1);
                for i=1:data.Wind.wind_Number
                    total_windPower=total_windPower+data_wind_origin(i:data.Wind.wind_Number:data.Wind.wind_Number*param.T_windows,1);
                end
                MDRO_resulttest.PGit=PGit;
                MDRO_resulttest.total_windLoss=total_windLoss;
                MDRO_resulttest.total_windPower=total_windPower;
                
                dataName=erase(dataName,'.txt');
                File_result=strcat(Result_Folder,'MDRO_result_',dataName);
                if(param.semi_participation==0)
                    File_result=strcat(File_result,'_non-anticipativity');
                else
                    File_result=strcat(File_result,'_semi-anticipativity',erase(num2str(param.WindRGap),'.'));
                end
                if(param.isPCA==1)
                    File_result=strcat(File_result,'_PCA_',num2str(param.PCA));
                end
                if(param.phi==1)
                    File_result=strcat(File_result,'_phi');
                end
                save(strcat(File_result,'.mat'),'MDRO_resulttest');
                
                disp(PGit);
            end
            if(param.semi_participation==0)
                param.semi_participation=1;
            else
                if(param.isPCA==0)
                    param.isPCA=1;
                    param.semi_participation=0;
                else
                    break;
                end
            end
            index=index+1;
        end
    end
end
    
    
    



function [result]=getX(model,x,data,param)
N = data.baseparameters.unitN;
NodeNum=data.baseparameters.busN;
T=param.T_windows;
uit_location=model.uit_location;
sit_location=model.sit_location;
dit_location=model.dit_location;
Sit_location=model.Sit_location;
PGit_location=model.PGit_location;
Seitait_location=model.Seita_location;
Zit_location=model.Zit_location;
Y0_location=model.Y0_location;
YP_location=model.YP_location;
YPhi_location=model.YPhi_location;
Y0_part=model.linearDecisionRule.Y0;
YP_part=model.linearDecisionRule.YP;
YPhi_part=model.linearDecisionRule.YPhi;
model_Pwan2PW_coeficent=model.linearDecisionRule.model_PW2P;
Pwan2PW_coeficent=model.linearDecisionRule.PW2P;
YP_miu=model.linearDecisionRule.YP_miu;
miu=model.miu;
K=model.K;
P_wan=model.P_wan;

Y0=Y0_part*repmat(x(Y0_location));
end