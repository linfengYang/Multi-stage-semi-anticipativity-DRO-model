function [model] = function_DRO_MIQP_construct(UC_model,data,data_partion,PI,data_wind_history,N,T,param)
%FUNCTION_DRO_ �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
bus_PDQR=data.busLoad.bus_PDQR;
bool_partition=param.partition;
T_wan=param.T_wan;
T_windows=param.T_windows;
rho = param.rho;
gap_pri = param.gap_pri;
gap_dual =param.gap_dual;
iter_k=param.k;
NO_wind=param.NoWind;

R=data.Wind.wind_Number;
NodeNum=data.baseparameters.busN;
ThHot_cost_start = data.units.start_cost'; 
Lk=4;
rou=1e-3;
if(NO_wind==1)
    R=length(data_wind_history);
    bool_partition=1;
end
%Wind unit
for i=1:R
    M(i)=length(data_wind_history{i});
end
M_min=min(M);
data_wind{length(PI)}=[];
%P_w(1,1) P_w(2,1) P_w(3,1)...

P_wan_Wind_Min=[];
P_wan_Wind_Max=[];
R_wan_len=0;
P_wan=[];
for i=1:length(PI)
    R_partiton_num(i)=data_partion{i}.Wind.wind_Number;
    for t=1:T
        data_wind_part=[];
        for j=1:R_partiton_num(i)
            data_wind_part=[data_wind_part;data_partion{i}.data_wind_history{j}(t,1:M_min)];
        end
        if(bool_partition==1)
            data_wind_part=sum(data_wind_part,1);
        end
        data_wind{i}=[data_wind{i};data_wind_part];
    end
    data_wind_partion=data_wind{i};
miu_average{i}=mean(data_wind_partion,2);
covariance=cov(data_wind_partion');
[U{i},S{i},V] = svd (covariance);
diag_S=diag(S{i});
diag_S_1_2=power(diag_S,0.5);
mean_S=mean(diag_S);
S_log=floor(log10(mean_S));
R_wan_partion{i}=find(log10(diag_S)>S_log);
R_wan_partion_len=length(R_wan_partion{i});
P_wan_partition=(U{i}(:,R_wan_partion{i})*((S{i}(R_wan_partion{i},R_wan_partion{i}))^0.5)^(-1))'*(data_wind_partion-repmat(miu_average{i},1,M_min));
P_wan_Wind_partion_Max=max(P_wan_partition,[],2);
P_wan_Wind_partion_Min=min(P_wan_partition,[],2);
P_wan_Wind_Min=[P_wan_Wind_Min;P_wan_Wind_partion_Min];
P_wan_Wind_Max=[P_wan_Wind_Max;P_wan_Wind_partion_Max];
R_wan_len=R_wan_len+R_wan_partion_len;
P_wan=[P_wan;P_wan_partition];
end

Ckl=repmat(P_wan_Wind_Min,1,Lk)+...
    repmat((P_wan_Wind_Max-P_wan_Wind_Min),1,Lk).*...
    repmat(([1:Lk]/Lk),R_wan_len,1);
gamma_R_T_L=[];

for j=1:Lk-1
    gamma_R_T_L=[gamma_R_T_L,mean(max(P_wan-repmat(Ckl(:,j),1,M_min),0),2)+rou*ones(R_wan_len,1)];
end
gamma_k_l=gamma_R_T_L;
%% uit,sit,dit,Sit_wan,PGit,Seitait,Zit,PWrt
% x
x_num=0;
uit_num=N*T;
sit_num=N*T;
dit_num=N*T;
Sit_num=N*T;
x_num=uit_num+sit_num+dit_num+Sit_num;

%other variables
PGit_num=N*T;
Seitait_num=NodeNum*T;
Zit_num=N*T;
PWrt_num=R*T;

if(NO_wind==1)
    y_num=PGit_num+Seitait_num+Zit_num;
else
    y_num=PGit_num+Seitait_num+Zit_num+PWrt_num;
    
end
y_location=x_num+1:x_num+y_num;
%location
%x
total_num=0;
uit_location=1:uit_num;
total_num=total_num+length(uit_location);

sit_location=total_num+1:total_num+sit_num;
total_num=total_num+length(sit_location);

dit_location=total_num+1:total_num+dit_num;
total_num=total_num+length(dit_location);

Sit_location=total_num+1:total_num+Sit_num;
total_num=total_num+length(Sit_location);
%y
PGit_location=total_num+1:total_num+PGit_num;
PGit_in_y_location=1:PGit_num;
total_num=total_num+length(PGit_location);

Seitait_location=total_num+1:total_num+Seitait_num;
Seitait_in_y_location=1+PGit_num:PGit_num+Seitait_num;
total_num=total_num+length(Seitait_location);

Zit_location=total_num+1:total_num+Zit_num;
Zit_in_y_location=1+PGit_num+Seitait_num:PGit_num+Seitait_num+Zit_num;
total_num=total_num+length(Zit_location);

PWrt_location=total_num+1:total_num+PWrt_num;
PWrt_in_y_location=PGit_num+Seitait_num+Zit_num+1:PGit_num+Seitait_num+Zit_num+PWrt_num;
total_num=total_num+length(PWrt_location);

[row_index,col_index]=find(UC_model.Aineq(:,y_location)~=0);
Aineq_constraints=UC_model.Aineq(unique(row_index),:);
bineq_constraints=UC_model.bineq(unique(row_index),:);

Auxiluary_Aineq=UC_model.Aineq;
Auxiluary_bineq=UC_model.bineq;
Auxiluary_Aineq(unique(row_index),:)=[];
Auxiluary_bineq(unique(row_index),:)=[];
Aineq_x_constraints=Auxiluary_Aineq;
bineq_x_constraints=Auxiluary_bineq;

if(~isempty(UC_model.Aeq))
[row_index,col_index]=find(UC_model.Aeq(:,y_location)~=0);
Aeq_constraints=UC_model.Aeq(unique(row_index),:);
beq_constraints=UC_model.beq(unique(row_index),:);
Auxiluary_Aeq=UC_model.Aeq;
Auxiluary_beq=UC_model.beq;
Auxiluary_Aeq(unique(row_index),:)=[];
Auxiluary_beq(unique(row_index),:)=[];
Aeq_x_constraints=Auxiluary_Aeq;
beq_x_constraints=Auxiluary_beq;
else
    Aeq_constraints=[];
    beq_constraints=[];
    Auxiluary_Aeq=[];
    Auxiluary_beq=[];
    Aeq_x_constraints=[];
    beq_x_constraints=[];
end

Aineq_constraints=[Aineq_constraints;Aeq_constraints;-1*Aeq_constraints];
bineq_constraints=[bineq_constraints;beq_constraints;-1*beq_constraints];
%% DRO
%uncertain set

%E(u)<=gamma
%p(Pw,u in Q)=1

%Pw_min<=Pw<=Pw_max
%max{v,0}<=u

C=[];
D=[];
d=[];

%P_wind<=P_wind_max
C=[C;sparse(diag(ones(R_wan_len,1)))];
D=[D;sparse(R_wan_len,R_wan_len*(Lk-1))];
d=[d;P_wan_Wind_Max];

%-P_wind<=-P_wind_min
C=[C;sparse(diag(-1*ones(R_wan_len,1)))];
D=[D;sparse(R_wan_len,R_wan_len*(Lk-1))];
d=[d;-1*P_wan_Wind_Min];

%-phi<=0
C=[C;sparse(R_wan_len*(Lk-1),R_wan_len)];
D=[D;sparse(diag(-1*ones(R_wan_len*(Lk-1),1)))];
d=[d;sparse(R_wan_len*(Lk-1),1)];

%P_wind_r_t - phi_r,t,l <=Cr,t,l
for i=1:R_wan_len
    C_part=sparse(Lk-1,R_wan_len);
    D_part=sparse(Lk-1,R_wan_len*(Lk-1));
    
    C_part(:,i)=1;
    D_part(:,(i-1)*(Lk-1)+1:i*(Lk-1))=sparse(diag(-1*ones((Lk-1),1)));
    
    C=[C;C_part];
    D=[D;D_part];
    
    d=[d;Ckl(i,1:Lk-1)'];
end

%%
Y0_PG=[];
PG_in_Y0=[];
Y0_Seita=[];
Seita_in_Y0=[];
Y0_Zit=[];
Zit_in_Y0=[];
YP_PG=[];
PG_in_YP=[];
YP_Seita=[];
Seita_in_YP=[];
YP_Zit=[];
Zit_in_YP=[];
YPhi_PG=[];
PG_in_YPhi=[];
YPhi_Zit=[];
Zit_in_YPhi=[];
YPhi_Seita=[];
Seita_in_YPhi=[];

DRO_total_var_num=0;
Y0_num=0;
YP_num=0;
YPhi_num=0;

x_location=1:x_num;
DRO_total_var_num=DRO_total_var_num+length(x_location);

Eta_location=DRO_total_var_num+1;
DRO_total_var_num=DRO_total_var_num+length(Eta_location);

lambda_location=DRO_total_var_num+1:DRO_total_var_num+R_wan_len*(Lk-1);
DRO_total_var_num=DRO_total_var_num+length(lambda_location);

Y0_PG_partition{length(PI)}=[];
for i=1:N
    for j=1:length(PI)
        [row_index,col_index]=find(i==data_partion{j}.units.bus_G);
        if(~isempty(col_index))
            Y0_PG_partition{j}=[Y0_PG_partition{j},DRO_total_var_num+1:DRO_total_var_num+T];
            Y0_PG=[Y0_PG,DRO_total_var_num+1:DRO_total_var_num+T];
            DRO_total_var_num=DRO_total_var_num+T;
            PG_in_Y0=[PG_in_Y0,Y0_num+1:Y0_num+T];
            Y0_num=T+Y0_num;
        end
    end
end

Y0_Seita_partition{length(PI)}=[];
for i=1:NodeNum
    for j=1:length(PI)
        [row_index,col_index]=find(i==PI{j});
        if(~isempty(col_index))
            Y0_Seita_partition{j}=[Y0_Seita_partition{j},DRO_total_var_num+1:DRO_total_var_num+T];
            Y0_Seita=[Y0_Seita,DRO_total_var_num+1:DRO_total_var_num+T];
            DRO_total_var_num=DRO_total_var_num+T;
            Seita_in_Y0=[Seita_in_Y0,Y0_num+1:Y0_num+T];
            Y0_num=T+Y0_num;
        end
    end
end

Y0_Zit_partition{length(PI)}=[];
for i=1:N
    for j=1:length(PI)
        [row_index,col_index]=find(i==data_partion{j}.units.bus_G);
        if(~isempty(col_index))
            Y0_Zit_partition{j}=[Y0_Zit_partition{j},DRO_total_var_num+1:DRO_total_var_num+T];
            Y0_Zit=[Y0_Zit,DRO_total_var_num+1:DRO_total_var_num+T];
            DRO_total_var_num=DRO_total_var_num+T;
            Zit_in_Y0=[Zit_in_Y0,Y0_num+1:Y0_num+T];
            Y0_num=T+Y0_num;
        end
    end
end

Y0_location=[Y0_PG,Y0_Seita,Y0_Zit];

YP_PG_partition{length(PI)}=[];
for i=1:N
    for j=1:length(PI)
        [row_index,col_index]=find(i==data_partion{j}.units.bus_G);
        if(~isempty(col_index))
            YP_PG_partition{j}=[YP_PG_partition{j},DRO_total_var_num+1:DRO_total_var_num+...
                T_wan*R_partiton_num(j)*(0.5-0.5*T_wan+T)]; 
            YP_PG=[YP_PG,DRO_total_var_num+1:DRO_total_var_num+T_wan*R_partiton_num(j)*(0.5-0.5*T_wan+T)];
            DRO_total_var_num=DRO_total_var_num+T_wan*R_partiton_num(j)*(0.5-0.5*T_wan+T);
            PG_in_YP=[PG_in_YP,YP_num+1:YP_num+T_wan*R_partiton_num(j)*(0.5-0.5*T_wan+T)];
            YP_num=T_wan*R_partiton_num(j)*(0.5-0.5*T_wan+T)+YP_num;
        end
    end
end

YP_Seita_partition{length(PI)}=[];
for i=1:NodeNum
    for j=1:length(PI)
        [row_index,col_index]=find(i==PI{j});
        if(~isempty(col_index))
            YP_Seita_partition{j}=[YP_Seita_partition{j},DRO_total_var_num+1:DRO_total_var_num+...
                T_wan*R_partiton_num(j)*(0.5-0.5*T_wan+T)]; 
            YP_Seita=[YP_Seita,DRO_total_var_num+1:DRO_total_var_num+T_wan*R_partiton_num(j)*(0.5-0.5*T_wan+T)];
            DRO_total_var_num=DRO_total_var_num+T_wan*R_partiton_num(j)*(0.5-0.5*T_wan+T);
            Seita_in_YP=[Seita_in_YP,YP_num+1:YP_num+T_wan*R_partiton_num(j)*(0.5-0.5*T_wan+T)];
            YP_num=T_wan*R_partiton_num(j)*(0.5-0.5*T_wan+T)+YP_num;
        end
    end
end

YP_Zit_partition{length(PI)}=[];
for i=1:N
    for j=1:length(PI)
        [row_index,col_index]=find(i==data_partion{j}.units.bus_G);
        if(~isempty(col_index))
            YP_Zit_partition{j}=[YP_Zit_partition{j},DRO_total_var_num+1:DRO_total_var_num+...
                T_wan*R_partiton_num(j)*(0.5-0.5*T_wan+T)]; 
            YP_Zit=[YP_Zit,DRO_total_var_num+1:DRO_total_var_num+T_wan*R_partiton_num(j)*(0.5-0.5*T_wan+T)];
            DRO_total_var_num=DRO_total_var_num+T_wan*R_partiton_num(j)*(0.5-0.5*T_wan+T);
            Zit_in_YP=[Zit_in_YP,YP_num+1:YP_num+T_wan*R_partiton_num(j)*(0.5-0.5*T_wan+T)];
            YP_num=T_wan*R_partiton_num(j)*(0.5-0.5*T_wan+T)+YP_num;
        end
    end
end


YP_location=[YP_PG,YP_Seita,YP_Zit];

YPhi_PG_partition{length(PI)}=[];
for i=1:N
    for j=1:length(PI)
        [row_index,col_index]=find(i==data_partion{j}.units.bus_G);
        if(~isempty(col_index))
            YPhi_PG_partition{j}=[YPhi_PG_partition{j},DRO_total_var_num+1:DRO_total_var_num+...
                T*R_wan_len*(Lk-1)]; 
            YPhi_PG=[YPhi_PG,DRO_total_var_num+1:DRO_total_var_num+T*R_wan_len*(Lk-1)];
            DRO_total_var_num=DRO_total_var_num+T*R_wan_len*(Lk-1);
            PG_in_YPhi=[PG_in_YPhi,YPhi_num+1:YPhi_num+T*R_wan_len*(Lk-1)];
            YPhi_num=T*R_wan_len*(Lk-1)+YPhi_num;
        end
    end
end

YPhi_Seita_partition{length(PI)}=[];
for i=1:NodeNum
    for j=1:length(PI)
        [row_index,col_index]=find(i==PI{j});
        if(~isempty(col_index))
            YPhi_Seita_partition{j}=[YPhi_Seita_partition{j},DRO_total_var_num+1:DRO_total_var_num+...
                T*R_wan_len*(Lk-1)]; 
            YPhi_Seita=[YPhi_Seita,DRO_total_var_num+1:DRO_total_var_num+T*R_wan_len*(Lk-1)];
            DRO_total_var_num=DRO_total_var_num+T*R_wan_len*(Lk-1);
            Seita_in_YPhi=[Seita_in_YPhi,YPhi_num+1:YPhi_num+T*R_wan_len*(Lk-1)];
            YPhi_num=T*R_wan_len*(Lk-1)+YPhi_num;
        end
    end
end

YPhi_Zit_partition{length(PI)}=[];
for i=1:N
    for j=1:length(PI)
        [row_index,col_index]=find(i==data_partion{j}.units.bus_G);
        if(~isempty(col_index))
            YPhi_Zit_partition{j}=[YPhi_Zit_partition{j},DRO_total_var_num+1:DRO_total_var_num+...
                T*R_wan_len*(Lk-1)]; 
            YPhi_Zit=[YPhi_Zit,DRO_total_var_num+1:DRO_total_var_num+T*R_wan_len*(Lk-1)];
            DRO_total_var_num=DRO_total_var_num+T*R_wan_len*(Lk-1);
            Zit_in_YPhi=[Zit_in_YPhi,YPhi_num+1:YPhi_num+T*R_wan_len*(Lk-1)];
            YPhi_num=T*R_wan_len*(Lk-1)+YPhi_num;
        end
    end
end

YPhi_location=[YPhi_PG,YPhi_Seita,YPhi_Zit];

Y_location=[Y0_location,YP_location,YPhi_location];

pai_2_location=DRO_total_var_num+1:...
    DRO_total_var_num+size(C,1)*(size(Aineq_constraints,1));
DRO_total_var_num=DRO_total_var_num+length(pai_2_location);

total_var_num=DRO_total_var_num;
p_location=[Y0_location,YP_location];
if(iter_k==1)
    z=sparse(Y0_num+YP_num,1);
    u=sparse(Y0_num+YP_num,1);
else
    z=param.z;
    u=param.u;
end


%% linear decision rule
Y0_part=sparse(diag(ones(y_num-PWrt_num,1)));

YP_part{length(PI)}=[];
for i=1:length(PI)
    for t=1:T
        if(t<=T_wan)
            YP_part{i}=sparse(blkdiag(YP_part{i},ones(1,t*R_partiton_num(i))));
        else
            YP_part{i}=sparse(blkdiag(YP_part{i},ones(1,T_wan*R_partiton_num(i))));
        end
    end
end
YP_part_PG=[];
for i=1:N
    for j=1:length(PI)
        [row_index,col_index]=find(i==data_partion{j}.units.bus_G);
        if(~isempty(col_index))
            YP_part_PG=sparse(blkdiag(YP_part_PG,YP_part{j}));
        end
    end
end

YP_part_Seita=[];
for i=1:NodeNum
    for j=1:length(PI)
        [row_index,col_index]=find(i==PI{j});
        if(~isempty(col_index))
            YP_part_Seita=sparse(blkdiag(YP_part_Seita,YP_part{j}));
        end
    end
    
end
YP_part_Zit=YP_part_PG;

YP_part=sparse(y_num-PWrt_num,YP_num);
YP_part(PGit_location-x_num,YP_PG-x_num-length(Eta_location)-length(lambda_location)-Y0_num)=YP_part_PG;
YP_part(Seitait_location-x_num,YP_Seita-x_num-length(Eta_location)-length(lambda_location)-Y0_num)=YP_part_Seita;
YP_part(Zit_location-x_num,YP_Zit-x_num-length(Eta_location)-length(lambda_location)-Y0_num)=YP_part_Zit;


YPhi_part=[];
for i=1:T
    YPhi_part=sparse(blkdiag(YPhi_part,ones(1,R_wan_len*(Lk-1))));
end
YPhi_part_PG=[];
for i=1:N
    YPhi_part_PG=sparse(blkdiag(YPhi_part_PG,YPhi_part));
end
YPhi_part_Seita=[];
for i=1:NodeNum
    YPhi_part_Seita=sparse(blkdiag(YPhi_part_Seita,YPhi_part));
end
YPhi_part_Zit=YPhi_part_PG;
YPhi_part=sparse(blkdiag(YPhi_part_PG,YPhi_part_Seita,YPhi_part_Zit));

YPhi_part=sparse(y_num-PWrt_num,YPhi_num);
YPhi_part(PGit_location-x_num,YPhi_PG-x_num-length(Eta_location)-length(lambda_location)-Y0_num-YP_num)=YPhi_part_PG;
YPhi_part(Seitait_location-x_num,YPhi_Seita-x_num-length(Eta_location)-length(lambda_location)-Y0_num-YP_num)=YPhi_part_Seita;
YPhi_part(Zit_location-x_num,YPhi_Zit-x_num-length(Eta_location)-length(lambda_location)-Y0_num-YP_num)=YPhi_part_Zit;

%PCA


Pwan2PW_coeficent_part=[];
Pwan2PW_diag=[];
Pwan2PW_part=[];
Pwan2PW=[];
miu_mean=[];
for i=1:length(PI)
    K{i}=U{i}*power(S{i},0.5);
    Pwan2PW_location{i}=size(Pwan2PW_diag,1)+1:size(Pwan2PW_diag,1)+size(K{i},1);
    Pwan2PW_diag=blkdiag(Pwan2PW_diag,K{i}(:,R_wan_partion{i}));
    
end
for i=1:length(PI)
    Pwan2PW_coeficent{i}=Pwan2PW_diag(Pwan2PW_location{i},:);
end
for t=1:T
    for i=1:length(PI)         
        Pwan2PW_part=blkdiag(Pwan2PW_part,K{i}((t-1)*R_partiton_num(i)+1:t*R_partiton_num(i),R_wan_partion{i}));
        miu_mean=[miu_mean;miu_average{i}((t-1)*R_partiton_num(i)+1:t*R_partiton_num(i))];
    end
    Pwan2PW_part=[];
end

%model variable
model_Pwan2PW_coeficent=[];
model_Pwan2PW_coeficent_part{length(PI)}=[];
miu=[];
miu_avarge_part{length(PI)}=[];
for i=1:length(PI)
    for t=1:T
        if(t>T_wan)
            model_Pwan2PW_coeficent_part{i}=sparse(blkdiag(model_Pwan2PW_coeficent_part{i},Pwan2PW_coeficent{i}((t-T_wan)*R_partiton_num(i)+1:t*R_partiton_num(i),:)'));
            miu_avarge_part{i}=[miu_avarge_part{i};miu_average{i}((t-T_wan)*R_partiton_num(i)+1:t*R_partiton_num(i),:)];
        else
            model_Pwan2PW_coeficent_part{i}=sparse(blkdiag(model_Pwan2PW_coeficent_part{i},Pwan2PW_coeficent{i}(1:t*R_partiton_num(i),:)'));
            miu_avarge_part{i}=[miu_avarge_part{i};miu_average{i}(1:t*R_partiton_num(i),:)];
        end
    end
end
%PG
for i=1:N
    for j=1:length(PI)
        [row_index,col_index]=find(i==data_partion{j}.units.bus_G);
        if(~isempty(col_index))
            model_Pwan2PW_coeficent=sparse(blkdiag(model_Pwan2PW_coeficent,model_Pwan2PW_coeficent_part{j}));
            miu=[miu;miu_avarge_part{j}];
        end
    end

end
%seita
for i=1:NodeNum
    for j=1:length(PI)
        [row_index,col_index]=find(i==PI{j});
        if(~isempty(col_index))
            model_Pwan2PW_coeficent=sparse(blkdiag(model_Pwan2PW_coeficent,model_Pwan2PW_coeficent_part{j}));
            miu=[miu;miu_avarge_part{j}];
        end
    end
end
%Zit
for i=1:N
    for j=1:length(PI)
        [row_index,col_index]=find(i==data_partion{j}.units.bus_G);
        if(~isempty(col_index))
            model_Pwan2PW_coeficent=sparse(blkdiag(model_Pwan2PW_coeficent,model_Pwan2PW_coeficent_part{j}));
            miu=[miu;miu_avarge_part{j}];
        end
    end
end

if(NO_wind==1)
    miu=sparse(repmat(miu',y_num,1));
else
miu=sparse(repmat(miu',y_num-PWrt_num,1));
end
YP_miu=YP_part.*miu;

%%

Q=sparse(1,total_var_num);
Q(1,Y_location)=0.5*rho; 
Q=sparse(diag(Q));

f=sparse(1,total_var_num);
% f(1,sit_location)=reshape(repmat(ThHot_cost_start,1,T)',N*T,1);
% f(1,Sit_location)=1;
% f(1,Eta_location)=1;
% f(1,lambda_location)=reshape(gamma_k_l',size(gamma_k_l,1)*size(gamma_k_l,2),1);
f(1,Y_location)=rho*(u-z);


% part_YP_Zit_T=[];
% part_YP_Zit=[];
% for t=1:T
%     if(t>T_wan)
%         part_YP_Zit_T=[part_YP_Zit_T,miu_average((t-T_wan)*R+1:t*R)'];
%     else
%         part_YP_Zit_T=[part_YP_Zit_T,miu_average(1:R*t)'];
%     end
% end
% for i=1:N
%     part_YP_Zit=[part_YP_Zit,part_YP_Zit_T];
% end
% 
% Aineq_constraint_pai_1=sparse(1,total_var_num);
% Aineq_constraint_pai_1(1,Eta_location)=-1; %Eta
% Aineq_constraint_pai_1(1,Y0_Zit)=1;
% Aineq_constraint_pai_1(1,YP_Zit)=part_YP_Zit;
% Aineq_constraint_pai_1(1,pai_1_location)=d';
% bineq_constraint_pai_1=0;
% 
% %PCA
% 
% %YP Zit
% part_YP_Zit=sparse(size(C,2),length(YP_Zit));
% coefficience_YP_Zit=U(:,R_wan)*power(S(R_wan,R_wan),0.5);
% 
% for i=1:R_wan_len
%     m_YP_Zit=[];
%     for t=1:T
%         if(t>T_wan)
%             m_YP_Zit=[m_YP_Zit,coefficience_YP_Zit((t-T_wan)*R+1:t*R,i)'];
%         else
%             m_YP_Zit=[m_YP_Zit,coefficience_YP_Zit(1:t*R,i)'];
%         end
%     end
%     part_YP_Zit(i,:)=-1*repmat(m_YP_Zit,1,N);
% end
% 
% part_YPhi_Zit=[];
% for i=1:N*T
%     part_YPhi_Zit=[part_YPhi_Zit,diag(-1*ones(R_wan_len*(Lk-1),1))];
% end
% 
% 
% Aeq_constraint_pai_1=sparse(size(C,2)+size(D,2),total_var_num);
% Aeq_constraint_pai_1(size(C,2)+1:size(C,2)+size(D,2),lambda_location)=diag(ones(length(lambda_location),1));
% Aeq_constraint_pai_1(1:size(C,2),YP_Zit)=part_YP_Zit;
% Aeq_constraint_pai_1(size(C,2)+1:size(C,2)+size(D,2),YPhi_Zit)=part_YPhi_Zit;
% Aeq_constraint_pai_1(:,pai_1_location)=[C';D'];
% beq_constraint_pai_1=sparse(size(C,2)+size(D,2),1);

%% constraint
Aineq_constraint_pai_2=[];
bineq_constraint_pai_2=[];

Aeq_constraint_pai_2=[];
beq_constraint_pai_2=[];

part_pai_2_d=[];
part_pai_2_C=[];
part_pai_2_D=[];

YP_Aineq_PG=sparse(size(Aineq_constraints,1),length(YP_PG));
YP_Aeq_PG=sparse(size(C,2)*size(Aineq_constraints,1),length(YP_PG));
YPhi_Aeq_PG=sparse(size(D,2)*size(Aineq_constraints,1),length(YPhi_PG));

YP_Aineq_Zit=sparse(size(Aineq_constraints,1),length(YP_Zit));
YP_Aeq_Zit=sparse(size(C,2)*size(Aineq_constraints,1),length(YP_Zit));
YPhi_Aeq_Zit=sparse(size(D,2)*size(Aineq_constraints,1),length(YPhi_Zit));

YP_Aineq_Seita=sparse(size(Aineq_constraints,1),length(YP_Seita));
YP_Aeq_Seita=sparse(size(C,2)*size(Aineq_constraints,1),length(YP_Seita));
YPhi_Aeq_Seita=sparse(size(D,2)*size(Aineq_constraints,1),length(YPhi_Seita));

bineq_constraint_pai_2_part=sparse(size(Aineq_constraints,1),1);
for i=1:size(Aineq_constraints,1)
    beq_constraint_pai_2_part=sparse(size(C,2),1);
    part_pai_2_d=blkdiag(part_pai_2_d,d');
    part_pai_2_C=blkdiag(part_pai_2_C,C');
    part_pai_2_D=blkdiag(part_pai_2_D,D');
    
    PG_part_location=find(Aineq_constraints(i,PGit_location)~=0);
    Zit_part_location=find(Aineq_constraints(i,Zit_location)~=0);
    Seita_part_location=find(Aineq_constraints(i,Seitait_location)~=0);
    if(NO_wind==1)
        PWrt_part_location=[];
    else
    PWrt_part_location=find(Aineq_constraints(i,PWrt_location)~=0);
    end
    
    YP_Aineq_PG(i,:)=Aineq_constraints(i,PGit_location(PG_part_location))*...
        YP_miu(PG_part_location,PG_in_YP);
    YP_Aineq_Zit(i,:)=Aineq_constraints(i,Zit_location(Zit_part_location))*...
        YP_miu(Zit_in_Y0(Zit_part_location),Zit_in_YP);
    YP_Aineq_Seita(i,:)=Aineq_constraints(i,Seitait_location(Seita_part_location))*...
        YP_miu(Seita_in_Y0(Seita_part_location),Seita_in_YP);
    if(~isempty(PG_part_location))
        for k=1:length(PG_part_location)
            
            [YP_PG_part_location_row,YP_PG_part_location_col]=find(YP_part(PG_part_location(k),:)~=0);
            YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location_col)=-1*Aineq_constraints(i,PGit_location(PG_part_location(k)))*...
                model_Pwan2PW_coeficent((PG_part_location(k)-1)*size(C,2)+1:PG_part_location(k)*size(C,2),...
                PG_in_YP(1,YP_PG_part_location_col));
            
            YPhi_PG_part_location=find(YPhi_part(PG_part_location(k),:)~=0);
            YPhi_Aeq_PG((i-1)*size(D,2)+1:i*size(D,2),YPhi_PG_part_location)=-1*Aineq_constraints(i,PGit_location(PG_part_location(k)))*...
                diag(ones(R_wan_len*(Lk-1),1));
        end
    end
    if(~isempty(Zit_part_location))
        for k=1:length(Zit_part_location)
            [YP_Zit_part_location_row,YP_Zit_part_location_col]=find(YP_part(Zit_in_Y0(Zit_part_location(k)),:)~=0);
            YP_Aeq_Zit((i-1)*size(C,2)+1:i*size(C,2),YP_Zit_part_location_col-length(YP_PG)-length(YP_Seita))=-1*Aineq_constraints(i,Zit_location(Zit_part_location(k)))*...
                model_Pwan2PW_coeficent((Zit_in_Y0(Zit_part_location(k))-1)*size(C,2)+1:Zit_in_Y0(Zit_part_location(k))*size(C,2),...
                YP_Zit_part_location_col);
            
            YPhi_Zit_part_location=find(YPhi_part(Zit_in_Y0(Zit_part_location(k)),:)~=0);
            YPhi_Aeq_Zit((i-1)*size(D,2)+1:i*size(D,2),YPhi_Zit_part_location-length(YPhi_PG)-length(YPhi_Seita))=-1*Aineq_constraints(i,Zit_location(Zit_part_location(k)))*...
                diag(ones(R_wan_len*(Lk-1),1));
        end
    end
    if(~isempty(Seita_part_location))
        for k=1:length(Seita_part_location)
            [YP_Seita_part_location_row,YP_Seita_part_location_col]=find(YP_part(Seita_in_Y0(Seita_part_location(k)),:)~=0);
            YP_Aeq_Seita((i-1)*size(C,2)+1:i*size(C,2),YP_Seita_part_location_col-length(YP_PG))=-1*Aineq_constraints(i,Seitait_location(Seita_part_location(k)))*...
                model_Pwan2PW_coeficent((Seita_in_Y0(Seita_part_location(k))-1)*size(C,2)+1:Seita_in_Y0(Seita_part_location(k))*size(C,2),...
                YP_Seita_part_location_col);
            
            YPhi_Seita_part_location=find(YPhi_part(Seita_in_Y0(Seita_part_location(k)),:)~=0);
            YPhi_Aeq_Seita((i-1)*size(D,2)+1:i*size(D,2),YPhi_Seita_part_location-length(YPhi_PG))=-1*Aineq_constraints(i,Seitait_location(Seita_part_location(k)))*diag(ones(R_wan_len*(Lk-1),1));
        end
    end
    
    if(~isempty(PWrt_part_location))
        for r=1:length(PWrt_part_location)
            beq_constraint_pai_2_part=beq_constraint_pai_2_part+...
                Aineq_constraints(i,PWrt_location(PWrt_part_location(r)))*Pwan2PW(PWrt_part_location(r),:)';
            bineq_constraint_pai_2_part(i,1)=bineq_constraint_pai_2_part(i,1)+...
                -1*Aineq_constraints(i,PWrt_location(PWrt_part_location(r)))*miu_mean(PWrt_part_location(r));
        end
    end
    beq_constraint_pai_2=[beq_constraint_pai_2;beq_constraint_pai_2_part];

end

constraint_pai_2=sparse(size(Aineq_constraints,1),total_var_num);
constraint_pai_2(:,x_location)=Aineq_constraints(:,x_location);
constraint_pai_2(:,Y0_PG)=Aineq_constraints(:,PGit_location);
constraint_pai_2(:,Y0_Zit)=Aineq_constraints(:,Zit_location);
constraint_pai_2(:,Y0_Seita)=Aineq_constraints(:,Seitait_location);
constraint_pai_2(:,YP_PG)=YP_Aineq_PG;
constraint_pai_2(:,YP_Seita)=YP_Aineq_Seita;
constraint_pai_2(:,YP_Zit)=YP_Aineq_Zit;
constraint_pai_2(:,pai_2_location)=part_pai_2_d;

Aineq_constraint_pai_2=[Aineq_constraint_pai_2;constraint_pai_2];
bineq_constraint_pai_2=[bineq_constraint_pai_2;bineq_constraints+bineq_constraint_pai_2_part];

%eq
constraint_pai_2=sparse((size(C,2)+size(D,2))*size(Aineq_constraints,1),total_var_num);
constraint_pai_2(1:size(C,2)*size(Aineq_constraints,1),YP_PG)=YP_Aeq_PG;
constraint_pai_2(1:size(C,2)*size(Aineq_constraints,1),YP_Zit)=YP_Aeq_Zit;
constraint_pai_2(1:size(C,2)*size(Aineq_constraints,1),YP_Seita)=YP_Aeq_Seita;
constraint_pai_2(1:size(C,2)*size(Aineq_constraints,1),pai_2_location)=part_pai_2_C;
constraint_pai_2(size(C,2)*size(Aineq_constraints,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraints,1),YPhi_PG)=YPhi_Aeq_PG;
constraint_pai_2(size(C,2)*size(Aineq_constraints,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraints,1),YPhi_Zit)=YPhi_Aeq_Zit;
constraint_pai_2(size(C,2)*size(Aineq_constraints,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraints,1),YPhi_Seita)=YPhi_Aeq_Seita;
constraint_pai_2(size(C,2)*size(Aineq_constraints,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraints,1),pai_2_location)=part_pai_2_D;

Aeq_constraint_pai_2=[Aeq_constraint_pai_2;constraint_pai_2];
beq_constraint_pai_2=[beq_constraint_pai_2;sparse((size(D,2))*size(Aineq_constraints,1),1)];


%% DRO model


if(~isempty(Aeq_x_constraints))
Aeq_x=sparse(size(Aeq_x_constraints,1),total_var_num);
Aeq_x(:,x_location)=Aeq_x_constraints(:,x_location);
else
    Aeq_x=[];
end

Aineq=[Aineq_constraint_pai_2];%
bineq=[bineq_constraint_pai_2];%
Aeq=[Aeq_constraint_pai_2];%
beq=[beq_constraint_pai_2];%


lb=sparse(total_var_num,1);
lb(Eta_location,1)=-inf;
lb(Y_location,1)=-inf;


ub=inf*ones(total_var_num,1);
ub(uit_location,1)=1;
ub(sit_location,1)=1;
ub(dit_location,1)=1;

ctype='';
ctype(1:total_var_num)='C';


%%
model.Q=Q;
model.f=f;
model.Aeq=Aeq;
model.beq=beq;
model.Aineq=Aineq;
model.bineq=bineq;
model.lb=lb;
model.ub=ub;
model.ctype=ctype;
model.YP_location.PG=YP_PG;
model.YP_location.Zit=YP_Zit;
model.YP_location.Seita=YP_Seita;

model.Y0_location.Seita=Y0_Seita;
model.Y0_location.Zit=Y0_Zit;
model.Y0_location.PG=Y0_PG;

model.YPhi_location.Seita=YPhi_Seita;
model.YPhi_location.Zit=YPhi_Zit;
model.YPhi_location.PG=YPhi_PG;
model.linearDecisionRule.Y0=Y0_part;
model.linearDecisionRule.YP=YP_part;
model.linearDecisionRule.YPhi=YPhi_part;
model.linearDecisionRule.model_PW2P=model_Pwan2PW_coeficent;
model.linearDecisionRule.PW2P=Pwan2PW_coeficent;
model.linearDecisionRule.miu=YP_miu;
model.Y_location=Y_location;
model.pai_2_location=pai_2_location;
model.Aineq_constraint_pai_2=Aineq_constraint_pai_2(:,[Y_location,pai_2_location]);
model.bineq_constraint_pai_2=bineq_constraint_pai_2;
model.Aeq_constraint_pai_2=Aeq_constraint_pai_2(:,[Y_location,pai_2_location]);
model.beq_constraint_pai_2=beq_constraint_pai_2;
model.C=C;
model.D=D;
model.d=d;
end

