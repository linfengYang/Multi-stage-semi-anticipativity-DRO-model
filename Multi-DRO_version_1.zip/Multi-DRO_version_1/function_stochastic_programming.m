function [objval_avg,time] = function_stochastic_programming(data_unit,Filedir,param)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
sample_num=1000;
wind_num=data_unit.Wind.wind_Number;
WIND_MAX=200;
WIND_MIN=0;

wind=xlsread(Filedir);
data=wind(1:end,2:end);
data=reshape(data,[1,size(data,1)*size(data,2)]);
data=rmmissing(data',1)/(WIND_MAX-WIND_MIN);
data=0.5*param.windcoefficient*ones(size(data,1),size(data,2)).*data+...
    0.5*param.windcoefficient*ones(size(data,1),size(data,2));
data_day=reshape(data,[24,length(data)/24]);
data_wind_std=std(data_day',0,1)';
data_mean=mean(data_day')';
data_wind_sample={};
for i=1:wind_num
data_wind_sample{i}=repmat(data_wind_std,1,sample_num).*(normrnd(0,0.1,[size(data_wind_std,1),sample_num]))...
    + repmat(data_mean,1,sample_num);
end

objval=0;
time=0;
for i=1:sample_num
    data_wind=[];
    for j=1:wind_num
    data_wind=[data_wind;data_wind_sample{j}(:,i)];
    end
    [UC_model] = function_DC_UCmodel_wind_loss(data_unit,data_wind,param);
    [UC_resulttest] = solve(UC_model);
    objval=objval+UC_resulttest.objval;
    time=time+UC_resulttest.runtime;
end
objval_avg=objval/sample_num;
% 
% max_data=max(data');
% min_data=min(data');
% max_value=max(max_data);
% min_value=min(min_data);
% X=(data-min_value*ones(size(data)))/(max_value-min_value);      %贝塔分布
% x=reshape(X,[1,size(data,1)*size(data,2)]);
% pd=betafit(x);
% y=betapdf(x,pd(1),pd(2));%通过上一步将贝塔分布的两个参数求出来带入
% h=y/max_value;
% plot(sort(x),h,'LineWidth',1,'Color','r');hold on;
end

