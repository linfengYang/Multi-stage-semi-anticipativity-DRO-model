function [DRO_model]=function_UC_DROmodel_without_LoadCost(data,data_wind_history)
%2020-12-28 lw
%约束功率上下界 功率平衡 整数变量限制 目标函数线性化s
%2021-1-17 lw
%加入其他状态变量和约束
%
%% data
B=DCOPFNodeY(data);
Alpha = data.units.alpha;                           %机组发电函数系数Alpha--N*1矩阵
Beta = data.units.beta;                             %机组发电函数系数Beta--N*1矩阵
Gama = data.units.gamma;                            %机组发电函数系数Gama--N*1矩阵
ThPimin = data.units.PG_low;                         %机组发电功率下界--N*1矩阵
ThPimax = data.units.PG_up;                          %机组发电功率上界--N*1矩阵
Piup = data.units.ramp;                         %机组上坡功率上界--N*1矩阵
Pidown = data.units.ramp;                     %机组下坡功率上界--N*1矩阵
Pt = data.totalLoad.PD_T;                       %有功负荷--T*1矩阵
Qt=data.totalLoad.QD_T;                       %无功负荷--T*1
Bus_G=data.units.bus_G;                           %机组节点号
N = data.baseparameters.unitN;                 %机组数量--1*1矩阵
T = data.totalLoad.T;                          %时间段数--1*1矩阵
Dt = data.totalLoad.PD_T;                                 %负载需求--T*1矩阵
bus_P_factor=data.busLoad.bus_P_factor;           %节点有功负荷因子
bus_Q_factor=data.busLoad.bus_Q_factor;            %节点无功负荷因子
bus_P=data.busLoad.node_P;
Spin = data.totalLoad.R_T;                     %旋转热备用--T*1矩阵
ThTime_on_off_init = data.units.U_ini;        %机组在初始状态前已经开机/停机的时间--N*1矩阵
Thon_off_init =  data.units.PG_up*0.7;               %机组机组初始功率--N*1矩阵
ThTime_on_min = data.units.T_on;             %机组最小开机时间--N*1矩阵
ThTime_off_min = data.units.T_off;           %机组最小停机时间--N*1矩阵
Th_cost_start = data.units.start_cost;           %机组启动费用--N*1矩阵
ThCold_cost_start = data.units.start_cost*2;           %火电机组冷启动费用--N*1矩阵
ThHot_cost_start = data.units.start_cost;             %火电机组热启动费用--N*1矩阵
Pistartup = data.units.PG_low;      %火电机组开机功率--N*1矩阵
Pishutdown = data.units.PG_low;      %火电机组关机功率--N*1矩阵
Ui0 = full(spones(Thon_off_init));                                  %火电机组机组初始开/停机状态
Ui = max(0,min(ones(N,1) * T,Ui0 .* (ThTime_on_min - ThTime_on_off_init)));                    %--N*1矩阵
Li = max(0,min(ones(N,1) * T,(ones(N,1) - Ui0) .* (ThTime_off_min + ThTime_on_off_init)));     %--N*1矩阵
ThCold_time_start=min(max(2*ThTime_off_min,1),T);
L=4;

%net
NodeNum=data.baseparameters.busN;
branchI=data.branch.I;
branchJ=data.branch.J;
branchR=data.branch.R;
branchX=data.branch.X;
branchP=data.branch.P;
branchB=data.branch.B;
branchGroundI=0;
branchGroundB=0;
branchTransformerI=data.branchTransformer.I;
branchTransformerJ=data.branchTransformer.J;
branchTransformerR=data.branchTransformer.R;
branchTransformerX=data.branchTransformer.X;
branchTransformerK=data.branchTransformer.K;
branchTransformerP=data.branchTransformer.P;

All_branchI=[branchI;branchTransformerI];
All_branchJ=[branchJ;branchTransformerJ];
All_branchP=[branchP;branchTransformerP];

bus_PDQR=data.busLoad.bus_PDQR;
bus_G=data.units.bus_G;
wind_Node=data.Wind.wind_Node; 
R=data.Wind.wind_Number;
%% UC model
% x
uit=N*T;
sit=N*T;
dit=N*T;
Sit=N*T;
x_num=uit+sit+dit+Sit;

%continuous variables and some auxiliary variables
PGit=N*T;
Seitait=NodeNum*T;
Zit=N*T;
y_num=PGit+Zit+Seitait;

%% Constraints without uncertain

%state constraints
%s_(i,t)-d_(i,t)=u_(i,t)-u_(i,t-1)
%sit-dit=uit- uit-1
Aeq_constraints_state=[];
beq_constraints_state=-1*Ui0;

%t=1时
for i=1:N
    constraint_state=sparse(1,x_num);
    
    uit=sparse(1,N*T);
    sit=sparse(1,N*T);
    dit=sparse(1,N*T);
    
    uit(1,(i-1)*T+1)=-1;
    sit(1,(i-1)*T+1)=1;
    dit(1,(i-1)*T+1)=-1;
    
    constraint_state(1,1:N*T)=uit;
    constraint_state(1,N*T+1:2*N*T)=sit;
    constraint_state(1,2*N*T+1:3*N*T)=dit;
    
    Aeq_constraints_state=[Aeq_constraints_state;constraint_state];

end

%t>1
for i=1:N
    for t=2:T
        constraint_state=sparse(1,x_num);
        
        uit=sparse(1,N*T);
        sit=sparse(1,N*T);
        dit=sparse(1,N*T);
        
        uit(1,(i-1)*T+t)=-1;
        uit(1,(i-1)*T+t-1)=1;
        sit(1,(i-1)*T+t)=1;
        dit(1,(i-1)*T+t)=-1;
        
        constraint_state(1,1:N*T)=uit;
        constraint_state(1,N*T+1:2*N*T)=sit;
        constraint_state(1,2*N*T+1:3*N*T)=dit;
        
        Aeq_constraints_state=[Aeq_constraints_state;constraint_state];
    end
end
beq_constraints_state=[beq_constraints_state;sparse(N*(T-1),1)];

%% initial status
Aeq_constraints_initial_statues=[];
beq_constraints_initial_statues=[];

for i=1:N
    if(Ui(i) + Li(i) >= 1)
        for t=1:Ui(i)+Li(i)
            
            uit=sparse(1,N*T);
            
            uit(1,(i-1)*T+t)=1;
            
            constraints_initial_statues=sparse(1,x_num);
            constraints_initial_statues(1,1:N*T)=uit;
            
            Aeq_constraints_initial_statues=[Aeq_constraints_initial_statues;constraints_initial_statues];
            beq_constraints_initial_statues=[beq_constraints_initial_statues;Ui0(i)];
        end
    end
end
%% start_cost_constraint
%Sit>=Chot,i,t*sit
Aineq_constraint_start_cost=[];

for i=1:N
    for t=1:T
        constraint_start_cost=sparse(1,x_num);
        
        sit=sparse(1,N*T);
        Sit=sparse(1,N*T);
        
        sit(1,(i-1)*T+t)=ThHot_cost_start(i);
        Sit(1,(i-1)*T+t)=-1;
        
        constraint_start_cost(1,N*T+1:2*N*T)=sit;
        constraint_start_cost(1,3*N*T+1:4*N*T)=Sit;
        
        Aineq_constraint_start_cost=[Aineq_constraint_start_cost;constraint_start_cost];
    end
end
bineq_constraint_start_cost=sparse(N*T,1);

%Sit>=Ccold,i,t*[sit-sum(dit)-finint]
for i=1:N
    for t=1:T
        constraint_start_cost=sparse(1,x_num);
        
        sit=sparse(1,N*T);
        dit=sparse(1,N*T);
        Sit=sparse(1,N*T);
        
        sit(1,(i-1)*T+t)=ThCold_cost_start(i);
        dit(1,(i-1)*T+max(t-ThTime_off_min(i)-ThCold_time_start(i),1):(i-1)*T+t-1)=-1*ThCold_cost_start(i);
        Sit(1,(i-1)*T+t)=-1;
        
        constraint_start_cost(1,N*T+1:2*N*T)=sit;
        constraint_start_cost(1,2*N*T+1:3*N*T)=dit;
        constraint_start_cost(1,3*N*T+1:4*N*T)=Sit;
        
        Aineq_constraint_start_cost=[Aineq_constraint_start_cost;constraint_start_cost];
        
        if(t-ThTime_off_min(i)-ThCold_time_start(i))<=0&& max(0,-ThTime_on_off_init(i))<abs(t-ThTime_off_min(i)-ThCold_time_start(i)-1)+1
            bineq_constraint_start_cost=[bineq_constraint_start_cost;ThCold_cost_start(i)];
        else
            bineq_constraint_start_cost=[bineq_constraint_start_cost;0];
        end
    end
end
%% minim up/down time constraint
%∑s_(i,?) ≤u_(i,t)
Aineq_constraint_min_upordown_time=[];
bineq_constraint_min_upordown_time=[];
for i=1:N
    for t=Ui(i) + 1:T
        
        constraint_min_upordown_time=sparse(1,x_num);
        
        uit=sparse(1,N*T);
        sit=sparse(1,N*T);
        
        uit(1,(i-1)*T+t)=-1;
        sit(1,(i-1)*T+max(0,t-ThTime_on_min(i))+1:(i-1)*T+t)=1;
        
        constraint_min_upordown_time(1,1:N*T)=uit;
        constraint_min_upordown_time(1,N*T+1:2*N*T)=sit;
        
        Aineq_constraint_min_upordown_time=[Aineq_constraint_min_upordown_time;constraint_min_upordown_time];
        bineq_constraint_min_upordown_time=[bineq_constraint_min_upordown_time;0];
        
    end
end
%∑d_(i,?) ≤1-u_(i,t)
for i=1:N
    for t=Li(i)+1:T
        
        constraint_min_upordown_time=sparse(1,x_num);
        
        uit=sparse(1,N*T);
        dit=sparse(1,N*T);
        
        uit(1,(i-1)*T+t)=1;
        dit(1,(i-1)*T+max(0,t-ThTime_off_min(i))+1:(i-1)*T+t)=1;
        
        constraint_min_upordown_time(1,1:N*T)=uit;
        constraint_min_upordown_time(1,2*N*T+1:3*N*T)=dit;
        
        Aineq_constraint_min_upordown_time=[Aineq_constraint_min_upordown_time;constraint_min_upordown_time];
        bineq_constraint_min_upordown_time=[bineq_constraint_min_upordown_time;1];
    end
end

Aineq_ramp_limt=[];
bineq_ramp_limt=[];
Aineq_genration_limit_lower=[];
bineq_genration_limit_lower=[];
Aineq_genration_limit_upper=[];
bineq_genration_limit_upper=[];
for i=1:N
%     %P_(i,t)^G-P_(i,t-1)^G≤u_(i,t-1) P_(i,up)+ s_(i,t)*P_(i,start)
%     %t=1
%     constraint_ramp_limit=sparse(1,x_num+y_num);
%     
%     constraint_ramp_limit(1,N*T+(i-1)*T+1)=-1*Pistartup(i);%sit
%     constraint_ramp_limit(1,4*N*T+(i-1)*T+1)=1;%
%     
%     Aineq_ramp_limt=[Aineq_ramp_limt;constraint_ramp_limit];
%     bineq_ramp_limt=[bineq_ramp_limt;Ui0(i)*Piup(i)+Thon_off_init(i)];
%     
%     
%     %t>1
%     constraint_ramp_limit=sparse(T-1,x_num+y_num);
%     
%     constraint_ramp_limit(:,(i-1)*T+1:(i-1)*T+T-1)=sparse(diag(-1*Piup(i)*ones(T-1,1)));%uit
%     constraint_ramp_limit(:,N*T+(i-1)*T+2:N*T+(i-1)*T+T)=sparse(diag(-1*Pistartup(i)*ones(T-1,1)));%sit
%     constraint_ramp_limit(:,4*N*T+(i-1)*T+1:4*N*T+(i-1)*T+T)=[sparse(diag(-1*ones(T-1,1))),sparse(T-1,1)]+[sparse(T-1,1),sparse(diag(ones(T-1,1)))];%pit
%     Aineq_ramp_limt=[Aineq_ramp_limt;constraint_ramp_limit];
%     bineq_ramp_limt=[bineq_ramp_limt;sparse(T-1,1)];
%     
%     %P_(i,t-1)^G-P_(i,t)^G≤u_(i,t) P_(i,down)+d_(i,t) P_(i,shut)
%     %t=1
%     constraint_ramp_limit=sparse(1,x_num+y_num);
%     
%     constraint_ramp_limit(1,(i-1)*T+1)=-1*Pidown(i);%uit
%     constraint_ramp_limit(1,2*N*T+(i-1)*T+1)=-1*Pishutdown(i);%dit
%     constraint_ramp_limit(1,4*N*T+(i-1)*T+1)=-1;%pit
%     Aineq_ramp_limt=[Aineq_ramp_limt;constraint_ramp_limit];
%     bineq_ramp_limt=[bineq_ramp_limt;-1*Thon_off_init(i)];
%     
%     %t>1
%     constraint_ramp_limit=sparse(T-1,x_num+y_num);
%     constraint_ramp_limit(:,(i-1)*T+2:(i-1)*T+T)=sparse(diag(-1*Pidown(i)*ones(T-1,1)));%uit
%     constraint_ramp_limit(:,2*N*T+(i-1)*T+2:2*N*T+(i-1)*T+T)=sparse(diag(-1*Pishutdown(i)*ones(T-1,1)));%dit
%     constraint_ramp_limit(:,4*N*T+(i-1)*T+1:4*N*T+(i-1)*T+T)=[sparse(diag(ones(T-1,1))),sparse(T-1,1)]+[sparse(T-1,1),sparse(diag(-1*ones(T-1,1)))];%pit
%     Aineq_ramp_limt=[Aineq_ramp_limt;constraint_ramp_limit];
%     bineq_ramp_limt=[bineq_ramp_limt;sparse(T-1,1)];
    
    %generation limit
    %u_(i,t) P_min≤P_(i,t)^G≤u_(i,t) P_max

    %uit*Pmin<=Pit
    constraint_genration_limit=sparse(T,x_num+y_num);
    constraint_genration_limit(:,(i-1)*T+1:(i-1)*T+T)=sparse(diag(ThPimin(i)*ones(T,1)));%uit
    constraint_genration_limit(:,4*N*T+(i-1)*T+1:4*N*T+(i-1)*T+T)=sparse(diag(-1*ones(T,1)));%pit
    Aineq_genration_limit_upper=[Aineq_genration_limit_upper;constraint_genration_limit];
    bineq_genration_limit_upper=[bineq_genration_limit_upper;sparse(T,1)];
    
    %uit*Pmax>=Pit
    constraint_genration_limit=sparse(T,x_num+y_num);
    constraint_genration_limit(:,(i-1)*T+1:(i-1)*T+T)=sparse(diag(-1*ThPimax(i)*ones(T,1)));%uit
    constraint_genration_limit(:,4*N*T+(i-1)*T+1:4*N*T+(i-1)*T+T)=sparse(diag(ones(T,1)));%pit
    Aineq_genration_limit_lower=[Aineq_genration_limit_lower;constraint_genration_limit];
    bineq_genration_limit_lower=[bineq_genration_limit_lower;sparse(T,1)];
    
end

Aineq_constraint_power_balance_upper=[];
bineq_constraint_power_balance_upper=[];
Aineq_constraint_power_balance_lower=[];
bineq_constraint_power_balance_lower=[];

    pit=[];
    pwrt=[];
    for t=1:N
        pit=sparse([pit,eye(T)]);
    end
    for t=1:R
        pwrt=sparse([pwrt,eye(T)]);
    end
    Aineq_constraint_power_balance_upper=[pit,pwrt];%pwrt sparse(T,R*T)
    bineq_constraint_power_balance_upper=Dt;

    Aineq_constraint_power_balance_lower=[Aineq_constraint_power_balance_lower;-1*pit,-1*pwrt];
    bineq_constraint_power_balance_lower=[bineq_constraint_power_balance_lower;-1*Dt];



%objective function linear approximation
Aineq_linear_approximation=[];
bineq_linear_approximation=[];
a_alpha=reshape(repmat(Alpha,1,T)',N*T,1);
b_beta=reshape(repmat(Beta,1,T)',N*T,1);
c_gamma=reshape(repmat(Gama,1,T)',N*T,1);

J=0:L;
for j=1:L+1
    pil=reshape(repmat(ThPimin+(J(j)/L)*(ThPimax-ThPimin),1,T)',N*T,1);
    constraint_linear_approximation=sparse(N*T,x_num+y_num);
    constraint_linear_approximation(:,1:N*T)=sparse(diag(a_alpha-c_gamma.*power(pil,2)));%uit
    constraint_linear_approximation(:,4*N*T+1:5*N*T)=sparse(diag(2*c_gamma.*(pil)+b_beta));%pit
    constraint_linear_approximation(:,5*N*T+NodeNum*T+1:6*N*T+NodeNum*T)=sparse(diag(-1*ones(1,N*T)));%zit
    Aineq_linear_approximation=[Aineq_linear_approximation;constraint_linear_approximation];
    bineq_linear_approximation=[bineq_linear_approximation;sparse(N*T,1)];
end



%% DRO model
Lk=4;
rou=0;
R=data.Wind.wind_Number;

%Wind unit
for i=1:R
    M(i)=length(data_wind_history{i});
end
M_min=min(M);
data_wind=[];
%P_w(1,1) P_w(2,1) P_w(3,1)...
for t=1:T
    for i=1:R
        data_wind=[data_wind;data_wind_history{i}(t,1:M_min)];
    end
end
P_Wind_Max=max(data_wind,[],2);
P_Wind_Min=min(data_wind,[],2);
Ckl=repmat(P_Wind_Min,1,Lk)+...
    repmat((P_Wind_Max-P_Wind_Min),1,Lk).*...
    repmat(([1:Lk]/Lk),R,1);
gamma_R_T_L=[];

for j=1:Lk-1
    gamma_R_T_L=[gamma_R_T_L,mean(max(data_wind-repmat(Ckl(:,j),1,M_min),0),2)+rou*ones(R,1)];
end
gamma_k_l=gamma_R_T_L; 

%uncertain set 
%E(u)<=gamma
%p(Pw,u in Q)=1

%Pw_min<=Pw<=Pw_max
%max{v,0}<=u

C=[];
D=[];
d=[];

%P_wind<=P_wind_max
C=[C;sparse(diag(ones(R*T,1)))];
D=[D;sparse(R*T,R*T*(Lk-1))];
d=[d;P_Wind_Max];

%-P_wind<=-P_wind_min
C=[C;sparse(diag(-1*ones(R*T,1)))];
D=[D;sparse(R*T,R*T*(Lk-1))];
d=[d;-1*P_Wind_Min];

%-phi<=0
C=[C;sparse(R*T*(Lk-1),R*T)];
D=[D;sparse(diag(-1*ones(R*T*(Lk-1),1)))];
d=[d;sparse(R*T*(Lk-1),1)];

% %phi<=P_wind_max
% d_P_Wind_Max=repmat(P_Wind_Max,1,(Lk-1));
% d_P_Wind_Max=reshape(d_P_Wind_Max',(Lk-1)*length(P_Wind_Max),1);
% C=[C;sparse(R*T*(Lk-1),R*T)];
% D=[D;sparse(diag(ones(R*T*(Lk-1),1)))];
% d=[d;d_P_Wind_Max];


%P_wind_r_t - phi_r,t,l <=Cr,t,l
for i=1:R*T
            C_part=sparse(Lk-1,R*T);
            D_part=sparse(Lk-1,R*T*(Lk-1));
            
            C_part(:,i)=1;
            D_part(:,(i-1)*(Lk-1)+1:i*(Lk-1))=sparse(diag(-1*ones((Lk-1),1)));
            
            C=[C;C_part];
            D=[D;D_part];
            
            d=[d;Ckl(i,1:Lk-1)'];
end





%variable location
total_var_num=0;

x_location=1:x_num;
total_var_num=total_var_num+length(x_location);

x_uit=1:N*T;
x_sit=N*T+1:N*T+N*T;
x_dit=N*T+N*T+1:N*T+N*T+N*T;
x_Sit=N*T+N*T+N*T+1:N*T+N*T+N*T+N*T;

Eta_location=total_var_num+1;
total_var_num=total_var_num+length(Eta_location);

lambda_location=total_var_num+1:total_var_num+R*T*(Lk-1);
total_var_num=total_var_num+length(lambda_location);

Y0_PG=total_var_num+1:total_var_num+N*T;
total_var_num=total_var_num+length(Y0_PG);

Y0_Zit=total_var_num+1:total_var_num+N*T;
total_var_num=total_var_num+length(Y0_Zit);

YP_PG=total_var_num+1:...
    total_var_num+PGit*R*T;
total_var_num=total_var_num+length(YP_PG);

YP_Zit=total_var_num+1:...
    total_var_num+Zit*R*T;
total_var_num=total_var_num+length(YP_Zit);

YPhi_PG=total_var_num+1:...
    total_var_num+PGit*R*T*(Lk-1);
total_var_num=total_var_num+length(YPhi_PG);

YPhi_Zit=total_var_num+1:...
    total_var_num+Zit*R*T*(Lk-1);
total_var_num=total_var_num+length(YPhi_Zit);

pai_1_location=total_var_num+1:...
    total_var_num+size(C,1);
total_var_num=total_var_num+length(pai_1_location);

pai_2_location_upper=total_var_num+1:...
    total_var_num+size(C,1)*(size(Aineq_genration_limit_upper,1));
total_var_num=total_var_num+length(pai_2_location_upper);

pai_2_location_lower=total_var_num+1:...
    total_var_num+size(C,1)*(size(Aineq_genration_limit_lower,1));
total_var_num=total_var_num+length(pai_2_location_lower);

pai_3_location=total_var_num+1:total_var_num+size(C,1)*size(Aineq_linear_approximation,1);
total_var_num=total_var_num+length(pai_3_location);

pai_4_location_upper=total_var_num+1:...
    total_var_num+size(C,1)*(size(Aineq_constraint_power_balance_upper,1));
total_var_num=total_var_num+length(pai_4_location_upper);

pai_4_location_lower=total_var_num+1:...
    total_var_num+size(C,1)*(size(Aineq_constraint_power_balance_lower,1));
total_var_num=total_var_num+length(pai_4_location_lower);

%% 

%
f=sparse(1,total_var_num);
f(1,x_sit)=reshape(repmat(ThHot_cost_start,1,T)',N*T,1);
f(1,x_Sit)=1;
f(1,Eta_location)=1;
f(1,lambda_location)=reshape(gamma_k_l',size(gamma_k_l,1)*size(gamma_k_l,2),1);

Aineq_constraint_pai_1=sparse(1,total_var_num);
Aineq_constraint_pai_1(1,Eta_location)=-1; %Eta
Aineq_constraint_pai_1(1,Y0_Zit)=1;  
Aineq_constraint_pai_1(1,pai_1_location)=d';
bineq_constraint_pai_1=0;

%YP Zit
part_YP_Zit=[];
for i=1:N*T
    part_YP_Zit=[part_YP_Zit,diag(-1*ones(R*T,1))];
end

part_YPhi_Zit=[];
for i=1:N*T
    part_YPhi_Zit=[part_YPhi_Zit,diag(-1*ones(R*T*(Lk-1),1))];
end


Aeq_constraint_pai_1=sparse(size(C,2)+size(D,2),total_var_num);
Aeq_constraint_pai_1(size(C,2)+1:size(C,2)+size(D,2),lambda_location)=diag(ones(length(lambda_location),1));
Aeq_constraint_pai_1(1:size(C,2),YP_Zit)=part_YP_Zit;
Aeq_constraint_pai_1(size(C,2)+1:size(C,2)+size(D,2),YPhi_Zit)=part_YPhi_Zit;
Aeq_constraint_pai_1(:,pai_1_location)=[C';D'];
beq_constraint_pai_1=sparse(size(C,2)+size(D,2),1);

%% Aineq_genration_limit
Aineq_constraint_pai_2=[];
bineq_constraint_pai_2=[];

Aeq_constraint_pai_2=[];
beq_constraint_pai_2=[];

part_pai_2=[];
for i=1:size(Aineq_genration_limit_upper,1)
    part_pai_2=blkdiag(part_pai_2,d');
end

constraint_pai_2=sparse(size(Aineq_genration_limit_upper,1),total_var_num);
constraint_pai_2(:,x_uit)=diag(reshape(repmat(-1*ThPimax,1,T)',N*T,1));
constraint_pai_2(:,Y0_PG)=diag(ones(N*T,1));
constraint_pai_2(:,pai_2_location_upper)=part_pai_2;

Aineq_constraint_pai_2=[Aineq_constraint_pai_2;constraint_pai_2];
bineq_constraint_pai_2=[bineq_constraint_pai_2;sparse(N*T,1)];

part_pai_2=[];
for i=1:size(Aineq_genration_limit_upper,1)
    part_pai_2=blkdiag(part_pai_2,C');
end

constraint_pai_2=sparse((size(C,2)+size(D,2))*size(Aineq_genration_limit_upper,1),total_var_num);
constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_upper,1),YP_PG)=diag(-1*ones(N*T*R*T,1));
constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_upper,1),pai_2_location_upper)=part_pai_2;

part_pai_2=[];
for i=1:size(Aineq_genration_limit_upper,1)
    part_pai_2=blkdiag(part_pai_2,D');
end
constraint_pai_2(size(C,2)*size(Aineq_genration_limit_upper,1)+1:(size(C,2)+size(D,2))*size(Aineq_genration_limit_upper,1),YPhi_PG)=diag(-1*ones(N*T*R*T*(Lk-1),1));
constraint_pai_2(size(C,2)*size(Aineq_genration_limit_upper,1)+1:(size(C,2)+size(D,2))*size(Aineq_genration_limit_upper,1),pai_2_location_upper)=part_pai_2;

Aeq_constraint_pai_2=[Aeq_constraint_pai_2;constraint_pai_2];
beq_constraint_pai_2=[beq_constraint_pai_2;sparse((size(C,2)+size(D,2))*size(Aineq_genration_limit_upper,1),1)];

%Aineq_genration_limit_lower
part_pai_2=[];
for i=1:size(Aineq_genration_limit_lower,1)
    part_pai_2=blkdiag(part_pai_2,d');
end

constraint_pai_2=sparse(size(Aineq_genration_limit_lower,1),total_var_num);
constraint_pai_2(:,x_uit)=diag(reshape(repmat(ThPimin,1,T)',N*T,1));
constraint_pai_2(:,Y0_PG)=diag(-1*ones(N*T,1));
constraint_pai_2(:,pai_2_location_lower)=part_pai_2;

Aineq_constraint_pai_2=[Aineq_constraint_pai_2;constraint_pai_2];
bineq_constraint_pai_2=[bineq_constraint_pai_2;sparse(N*T,1)];

part_pai_2=[];
for i=1:size(Aineq_genration_limit_lower,1)
    part_pai_2=blkdiag(part_pai_2,C');
end

constraint_pai_2=sparse((size(C,2)+size(D,2))*size(Aineq_genration_limit_lower,1),total_var_num);
constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_lower,1),YP_PG)=diag(ones(N*T*R*T,1));
constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_lower,1),pai_2_location_lower)=part_pai_2;

part_pai_2=[];
for i=1:size(Aineq_genration_limit_lower,1)
    part_pai_2=blkdiag(part_pai_2,D');
end
constraint_pai_2(size(C,2)*size(Aineq_genration_limit_lower,1)+1:(size(C,2)+size(D,2))*size(Aineq_genration_limit_lower,1),YPhi_PG)=diag(ones(N*T*R*T*(Lk-1),1));
constraint_pai_2(size(C,2)*size(Aineq_genration_limit_lower,1)+1:(size(C,2)+size(D,2))*size(Aineq_genration_limit_lower,1),pai_2_location_lower)=part_pai_2;

Aeq_constraint_pai_2=[Aeq_constraint_pai_2;constraint_pai_2];
beq_constraint_pai_2=[beq_constraint_pai_2;sparse((size(C,2)+size(D,2))*size(Aineq_genration_limit_lower,1),1)];

%% Aineq_linear_approximation
Aineq_constraint_pai_3=[];
bineq_constraint_pai_3=[];
Aeq_constraint_pai_3=[];
beq_constraint_pai_3=[];


J=0:L;
for j=1:L+1
    pil=reshape(repmat(ThPimin+(J(j)/L)*(ThPimax-ThPimin),1,T)',N*T,1);
    
    
    part_pai_3=[];
    for i=1:Zit
        part_pai_3=blkdiag(part_pai_3,d');
    end
    
    constraint_pai_3=sparse(Zit,total_var_num);
    constraint_pai_3(:,x_uit)=diag(a_alpha-c_gamma.*power(pil,2));
    constraint_pai_3(:,Y0_PG)=diag(2*c_gamma.*(pil)+b_beta);
    constraint_pai_3(:,Y0_Zit)=diag(-1*ones(Zit,1));
    constraint_pai_3(:,pai_3_location((j-1)*Zit*size(C,1)+1:j*Zit*size(C,1)))=part_pai_3;
    
    Aineq_constraint_pai_3=[Aineq_constraint_pai_3;constraint_pai_3];
    bineq_constraint_pai_3=[bineq_constraint_pai_3;sparse(Zit,1)];
    

    
    part_pai_3=[];
    for i=1:Zit
        part_pai_3=blkdiag(part_pai_3,C');
    end
    constraint_pai_3=sparse(Zit*(size(C,2)+size(D,2)),total_var_num);
    constraint_pai_3(1:size(C,2)*Zit,YP_PG)=-1*diag(reshape(repmat(2*c_gamma.*(pil)+b_beta,1,R*T),R*T*Zit,1));
    constraint_pai_3(1:size(C,2)*Zit,YP_Zit)=diag(ones(R*T*Zit,1));
    constraint_pai_3(1:size(C,2)*Zit,pai_3_location((j-1)*Zit*size(C,1)+1:j*Zit*size(C,1)))=part_pai_3;
    
    part_pai_3=[];
    for i=1:Zit
        part_pai_3=blkdiag(part_pai_3,D');
    end
    
    constraint_pai_3(size(C,2)*Zit+1:(size(C,2)+size(D,2))*Zit,YPhi_PG)=-1*diag(reshape(repmat(2*c_gamma.*(pil)+b_beta,1,(Lk-1)*R*T),(Lk-1)*R*T*Zit,1));
    constraint_pai_3(size(C,2)*Zit+1:(size(C,2)+size(D,2))*Zit,YPhi_Zit)=diag(ones((Lk-1)*R*T*Zit,1));    
    constraint_pai_3(size(C,2)*Zit+1:(size(C,2)+size(D,2))*Zit,pai_3_location((j-1)*Zit*size(C,1)+1:j*Zit*size(C,1)))=part_pai_3;
    
    Aeq_constraint_pai_3=[Aeq_constraint_pai_3;constraint_pai_3];
    beq_constraint_pai_3=[beq_constraint_pai_3;sparse(Zit*(size(C,2)+size(D,2)),1)];

end


%% Aineq_constraint_power_balance
Aineq_constraint_pai_4=[];
bineq_constraint_pai_4=[];

Aeq_constraint_pai_4=[];
beq_constraint_pai_4=[];

part_pai_4=[];
for i=1:size(Aineq_constraint_power_balance_upper,1)
    part_pai_4=blkdiag(part_pai_4,d');
end

Y0_part=[];
for i=1:N
    Y0_part=[Y0_part,eye(T)];
end

constraint_pai_4=sparse(size(Aineq_constraint_power_balance_upper,1),total_var_num);
constraint_pai_4(:,Y0_PG)=Y0_part;
constraint_pai_4(:,pai_4_location_upper)=part_pai_4;

Aineq_constraint_pai_4=[Aineq_constraint_pai_4;constraint_pai_4];
bineq_constraint_pai_4=[bineq_constraint_pai_4;bineq_constraint_power_balance_upper];

part_pai_4=[];
for i=1:size(Aineq_constraint_power_balance_upper,1)
    part_pai_4=blkdiag(part_pai_4,C');
    b_part_4=sparse(size(C,2),1);
    b_part_4(i,1)=1;  %只对单风电机组
    beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
end

YP_part=[];
for i=1:N
    YP_part=[YP_part,-1*eye(T*R*T)];
end

constraint_pai_4=sparse((size(C,2)+size(D,2))*size(Aineq_constraint_power_balance_upper,1),total_var_num);
constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance_upper,1),YP_PG)=YP_part;
constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance_upper,1),pai_4_location_upper)=part_pai_4;


part_pai_4=[];
for i=1:size(Aineq_constraint_power_balance_upper,1)
    part_pai_4=blkdiag(part_pai_4,D');
    b_part_4=sparse(size(D,2),1);
    beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
end

YPhi_part=[];
for i=1:N
    YPhi_part=[YPhi_part,-1*eye(T*R*T*(Lk-1))];
end
constraint_pai_4(size(C,2)*size(Aineq_constraint_power_balance_upper,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_power_balance_upper,1),YPhi_PG)=YPhi_part;
constraint_pai_4(size(C,2)*size(Aineq_constraint_power_balance_upper,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_power_balance_upper,1),pai_4_location_upper)=part_pai_4;

Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];

%Aineq_constraint_power_balance_lower
part_pai_4=[];
for i=1:size(Aineq_constraint_power_balance_lower,1)
    part_pai_4=blkdiag(part_pai_4,d');
end

Y0_part=[];
for i=1:N
    Y0_part=[Y0_part,-1*eye(T)];
end
constraint_pai_4=sparse(size(Aineq_constraint_power_balance_lower,1),total_var_num);
constraint_pai_4(:,Y0_PG)=Y0_part;
constraint_pai_4(:,pai_4_location_lower)=part_pai_4;

Aineq_constraint_pai_4=[Aineq_constraint_pai_4;constraint_pai_4];
bineq_constraint_pai_4=[bineq_constraint_pai_4;bineq_constraint_power_balance_lower];

part_pai_4=[];
for i=1:size(Aineq_constraint_power_balance_lower,1)
    part_pai_4=blkdiag(part_pai_4,C');
    b_part_4=sparse(size(C,2),1);
    b_part_4(i,1)=-1;  %只对单风电机组
    beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
end

YP_part=[];
for i=1:N
    YP_part=[YP_part,eye(T*R*T)];
end

constraint_pai_4=sparse((size(C,2)+size(D,2))*size(Aineq_constraint_power_balance_lower,1),total_var_num);
constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance_lower,1),YP_PG)=YP_part;
constraint_pai_4(1:size(C,2)*size(Aineq_constraint_power_balance_lower,1),pai_4_location_lower)=part_pai_4;

part_pai_4=[];
for i=1:size(Aineq_constraint_power_balance_lower,1)
    part_pai_4=blkdiag(part_pai_4,D');
    b_part_4=sparse(size(D,2),1);
    beq_constraint_pai_4=[beq_constraint_pai_4;b_part_4];
end

YPhi_part=[];
for i=1:N
    YPhi_part=[YPhi_part,eye(T*R*T*(Lk-1))];
end
constraint_pai_4(size(C,2)*size(Aineq_constraint_power_balance_lower,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_power_balance_lower,1),YPhi_PG)=YPhi_part;
constraint_pai_4(size(C,2)*size(Aineq_constraint_power_balance_lower,1)+1:(size(C,2)+size(D,2))*size(Aineq_constraint_power_balance_lower,1),pai_4_location_lower)=part_pai_4;

Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];

%% test
%uncertain set 
%E(v)=0
%p(v,u in Q)=1
%E(u)<=70


% f=[b;1;70;60;... %x,Eta,gamma,rou
%     0;0;0;... Y0,Yv,Yu
%     sparse(size(C,1)*5,1)]; %pai_1,pai_2,pai_3,pai_4,,pai_5 
% 
% Aineq=[];
% bineq=[];
% Aeq=[];
% beq=[];
% 
% %pai_1
% Aineq=[Aineq;0,-1,0,0,...%x,Eta,gamma,rou
%     3,0,0,...Y0_1,Yv_1,Yu_1
%     d',sparse(1,size(C,1)*4)]; 
% bineq=[bineq;0];
% 
% Aeq=[Aeq;[0,0,0,1;0,0,1,0],...
%     sparse(2,1),[-3;0],[0;-3],...
%     C',sparse(2,size(C,1)*4)];
% beq=[beq;0;0];
% 
% %pai_2
% Aineq=[Aineq;-1*Pmax,0,0,0,...%x,Eta,gamma,rou
%     1,0,0,...Y0_1,Yv_1,Yu_1
%     sparse(1,size(C,1)),d',sparse(1,size(C,1)*3)]; 
% bineq=[bineq;0];
% 
% Aeq=[Aeq;sparse(2,4),...
%     sparse(2,1),[-1;0],[0;-1],...
%     sparse(2,size(C,1)),C',sparse(2,size(C,1)*3)];
% beq=[beq;0;0];
% 
% %pai_3
% Aineq=[Aineq;Pmin,0,0,0,...%x,Eta,gamma,rou
%     -1,0,0,...Y0_1,Yv_1,Yu_1
%     sparse(1,size(C,1)*2),d',sparse(1,size(C,1)*2)]; 
% bineq=[bineq;0];
% 
% Aeq=[Aeq;sparse(2,4),...
%     sparse(2,1),[1;0],[0;1],...
%     sparse(2,size(C,1)*2),C',sparse(2,size(C,1)*2)];
% beq=[beq;0;0];
% 
% 
% %pai_5
% Aineq=[Aineq;0,0,0,0,...%x,Eta,gamma,rou
%     1,0,0,...Y0_1,Yv_1,Yu_1
%     sparse(1,size(C,1)*3),d',sparse(1,size(C,1))]; 
% bineq=[bineq;310];
% 
% Aeq=[Aeq;sparse(2,4),...
%     sparse(2,1),[-1;0],[0;-1],...
%     sparse(2,size(C,1)*3),C',sparse(2,size(C,1))];
% beq=[beq;1;0];
% 
% %pai_6
% Aineq=[Aineq;0,0,0,0,...%Eta,gamma,rou
%     -1,0,0,...Y0_1,Yv_1,Yu_1,
%     sparse(1,size(C,1)*4),d']; 
% bineq=[bineq;-310];
% 
% Aeq=[Aeq;sparse(2,4),...
%     sparse(2,1),[1;0],[0;1],...
%     sparse(2,size(C,1)*4),C'];
% beq=[beq;-1;0];
% 
% % Aeq=[Aeq;sparse(3,4),...
% %     [0,1;0,0;0,0],[0,0;0,1;0,0],[0,0;0,0;0,1],...
% %     sparse(3,size(C,1)*6)];
% % beq=[beq;0;0;0];
% 
% 
% lb=[0;-inf;0;-inf;...
%     -inf*ones(1,1);-inf*ones(1,1);-inf*ones(1,1);...
%      zeros(size(C,1)*5,1)];
% ub=[1;inf;inf;inf;...
%      inf*ones(1,1);inf*ones(1,1);inf*ones(1,1);...
%      inf*ones(size(C,1)*5,1)];
% ctype='';
% ctype(1:length(f))='C';
% ctype(1)='B';
Aineq_two_bin_var_constraint=[Aineq_constraint_min_upordown_time;Aineq_constraint_start_cost];
bineq_two_bin_var_constraint=[bineq_constraint_min_upordown_time;bineq_constraint_start_cost];

Aeq_two_bin_var_constraint=[Aeq_constraints_state;Aeq_constraints_initial_statues];
beq_two_bin_var_constraint=[beq_constraints_state;beq_constraints_initial_statues];

Aineq_two_bin_var=sparse(size(Aineq_two_bin_var_constraint,1),total_var_num);
Aineq_two_bin_var(:,x_location)=Aineq_two_bin_var_constraint;

Aeq_two_bin_var=sparse(size(Aeq_two_bin_var_constraint,1),total_var_num);
Aeq_two_bin_var(:,x_location)=Aeq_two_bin_var_constraint;

Aineq=[Aineq_two_bin_var;Aineq_constraint_pai_1;Aineq_constraint_pai_2;Aineq_constraint_pai_3;Aineq_constraint_pai_4];
bineq=[bineq_two_bin_var_constraint;bineq_constraint_pai_1;bineq_constraint_pai_2;bineq_constraint_pai_3;bineq_constraint_pai_4];
Aeq=[Aeq_two_bin_var;Aeq_constraint_pai_1;Aeq_constraint_pai_2;Aeq_constraint_pai_3;Aeq_constraint_pai_4];
beq=[beq_two_bin_var_constraint;beq_constraint_pai_1;beq_constraint_pai_2;beq_constraint_pai_3;beq_constraint_pai_4];


lb=sparse(total_var_num,1);
lb(Eta_location,1)=-inf;
lb(Y0_PG,1)=-inf;
lb(Y0_Zit,1)=-inf;
lb(YP_PG,1)=-inf;
lb(YP_Zit,1)=-inf;
lb(YPhi_PG,1)=-inf;
lb(YPhi_Zit,1)=-inf;

ub=inf*ones(total_var_num,1);
ub(x_location,1)=1;

ctype='';
ctype(1:total_var_num)='C';
ctype(x_location)='B';

DRO_model.f=f;
DRO_model.Aeq=Aeq;
DRO_model.beq=beq;
DRO_model.Aineq=Aineq;
DRO_model.bineq=bineq;
DRO_model.lb=lb;
DRO_model.ub=ub;
DRO_model.ctype=ctype;

end




