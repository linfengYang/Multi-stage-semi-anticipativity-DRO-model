function [result] = solve(DRO_model)
%SOLVE �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

%GUROBI
names={};
for i=1:length(DRO_model.lb)
    names(i)={strcat('x',num2str(i))};
end
model.modelname='MDRO';
if(isfield(DRO_model,'Q'))
    if(~isempty(DRO_model.Q))
        model.Q=DRO_model.Q;
    end
end
model.obj = full(DRO_model.f);
model.A = [DRO_model.Aineq;DRO_model.Aeq];
model.rhs = full([DRO_model.bineq;DRO_model.beq]);
model.sense(1:size(DRO_model.Aineq,1)) = '<';
model.sense(size(DRO_model.Aineq,1)+1:size(DRO_model.Aineq,1)+size(DRO_model.Aeq,1)) = '=';
model.vtype = DRO_model.ctype;
model.modelsense = 'min';
model.varnames = names;
model.lb=full(DRO_model.lb);
model.ub=full(DRO_model.ub);
params.outputflag = 1;
params.MIPGap=1e-3;
% params.ResultFile = 'MDRO.mps';
% params.timelimit = 8000;
result = gurobi(model, params);
% disp(result);
% fprintf('Obj: %e\n', result.objval);

%CPLEX
% DRO_model.H=[];
% cplex_milp = Cplex('Milp for HTC');
% cplex_milp.Model.sense = 'minimize';
% cplex_milp.Model.obj = DRO_model.f;
% cplex_milp.Model.lb = DRO_model.lb;
% cplex_milp.Model.ub = DRO_model.ub;
% cplex_milp.Model.A = [DRO_model.Aineq;DRO_model.Aeq];
% cplex_milp.Model.lhs = [-Inf.*ones(size(DRO_model.bineq,1),1);DRO_model.beq];
% cplex_milp.Model.rhs = [DRO_model.bineq;DRO_model.beq];
% cplex_milp.Model.ctype = DRO_model.ctype;
% cplex_milp.Model.Q = DRO_model.H;
% cplex_milp.Param.mip.tolerances.mipgap.Cur = 0.001;%���MIP����ݲ�����ȣ�
% cplex_milp.Param.timelimit.Cur=10000;
% cplex_milp.solve();
% F = cplex_milp.Solution.objval;
% disp(F);
% result=cplex_milp.Solution;
end

