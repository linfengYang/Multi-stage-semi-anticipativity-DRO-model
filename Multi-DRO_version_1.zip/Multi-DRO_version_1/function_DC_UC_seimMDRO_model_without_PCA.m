function [model] = function_DC_UC_seimMDRO_model_without_PCA(UC_model,data,data_wind_history,param)
%FUNCTION_BUILD_DROMODEL �˴���ʾ�йش˺�����ժҪ
%   ���׶� ����PCA�ķֲ�³���Ż�
% DC +wind

%thermal unit
B=data.B;
Alpha = data.units.alpha;                           %���鷢�纯��ϵ��Alpha--N*1����
Beta = data.units.beta;                             %���鷢�纯��ϵ��Beta--N*1����
Gama = data.units.gamma;                            %���鷢�纯��ϵ��Gama--N*1����
ThPimin = data.units.PG_low;                         %���鷢�繦���½�--N*1����
ThPimax = data.units.PG_up;                          %���鷢�繦���Ͻ�--N*1����
Piup = data.units.ramp;                         %�������¹����Ͻ�--N*1����
Pidown = data.units.ramp;                     %�������¹����Ͻ�--N*1����
Pt = data.totalLoad.PD_T;                       %�й�����--T*1����
Qt=data.totalLoad.QD_T;                       %�޹�����--T*1
Bus_G=data.units.bus_G;                           %����ڵ��
N = data.baseparameters.unitN;                 %��������--1*1����
T = data.totalLoad.T;                          %ʱ�����--1*1����
Dt = data.totalLoad.PD_T;                                 %��������--T*1����
bus_P_factor=data.busLoad.bus_P_factor;           %�ڵ��й���������
bus_Q_factor=data.busLoad.bus_Q_factor;            %�ڵ��޹���������
bus_P=data.busLoad.node_P;
Spin = data.totalLoad.R_T;                     %��ת�ȱ���--T*1����
ThTime_on_off_init = data.units.U_ini;        %�����ڳ�ʼ״̬ǰ�Ѿ�����/ͣ����ʱ��--N*1����
Thon_off_init =  data.units.PG_up*0.7;               %��������ʼ����--N*1����
ThTime_on_min = data.units.T_on;             %������С����ʱ��--N*1����
ThTime_off_min = data.units.T_off;           %������Сͣ��ʱ��--N*1����
Th_cost_start = data.units.start_cost;           %������������--N*1����
ThCold_cost_start = data.units.start_cost*2;           %����������������--N*1����
ThHot_cost_start = data.units.start_cost;             %����������������--N*1����
Pistartup = data.units.PG_low;      %�����鿪������--N*1����
Pishutdown = data.units.PG_low;      %������ػ�����--N*1����
Ui0 = full(spones(Thon_off_init));                                  %����������ʼ��/ͣ��״̬
wind_Node=data.Wind.wind_Node;
NodeNum=data.baseparameters.busN;

bool_partition=param.partition;
T_wan=param.T_wan;
T_windows=param.T_windows;
WindRGap=param.WindRGap;
if(exist('windcoefficient.mat','file'))
    load windcoefficient.mat;

else
    windcoefficient=param.windcoefficient;
    save('windcoefficient.mat','windcoefficient');
end

if(NodeNum==118&T_windows<24)
Pt=Pt(2*T_windows+1:2*T_windows+T_windows);
Qt=Qt(2*T_windows+1:2*T_windows+T_windows);
T=T_windows;
Dt=Dt(2*T_windows+1:2*T_windows+T_windows);
Spin=Spin(2*T_windows+1:2*T_windows+T_windows);
bus_P=bus_P(2*T_windows+1:2*T_windows+T_windows);

else
    Pt=Pt(1:T_windows);
    Qt=Qt(1:T_windows);
    T=T_windows;
    Dt=Dt(1:T_windows);
    Spin=Spin(1:T_windows);
    bus_P=bus_P(1:T_windows);
end

Ui = max(0,min(ones(N,1) * T,Ui0 .* (ThTime_on_min - ThTime_on_off_init)));                    %--N*1����
Li = max(0,min(ones(N,1) * T,(ones(N,1) - Ui0) .* (ThTime_off_min + ThTime_on_off_init)));     %--N*1����
ThCold_time_start=min(max(2*ThTime_off_min,1),T);
L=4;

%net

branchI=data.branch.I;
branchJ=data.branch.J;
branchR=data.branch.R;
branchX=data.branch.X;
branchP=data.branch.P;
branchB=data.branch.B;
branchGroundI=0;
branchGroundB=0;
branchTransformerI=data.branchTransformer.I;
branchTransformerJ=data.branchTransformer.J;
branchTransformerR=data.branchTransformer.R;
branchTransformerX=data.branchTransformer.X;
branchTransformerK=data.branchTransformer.K;
branchTransformerP=data.branchTransformer.P;

All_branchI=[branchI;branchTransformerI];
All_branchJ=[branchJ;branchTransformerJ];
All_branchX=[branchX;branchTransformerX];
All_branchP=[branchP;branchTransformerP];
%% partion




%%

bus_PDQR=data.busLoad.bus_PDQR;

R=data.Wind.wind_Number;
Lk=4;
rou=1e-2;
%Wind unit
for i=1:R
    M(i)=length(data_wind_history{i});
end
M_min=min(M);
data_wind=[];
%P_w(1,1) P_w(2,1) P_w(3,1)...
for t=1:T
    data_wind_part=[];
    for i=1:R
        data_wind_part=[data_wind_part;data_wind_history{i}(t,1:M_min)];
    end
    if(bool_partition==1)
        data_wind_part=sum(data_wind_part,1);
    end
    data_wind=[data_wind;data_wind_part];
end

switch(NodeNum)
    case 6
        if(exist('data_wind_anticipated_6bus.mat','file')&windcoefficient==param.windcoefficient)
            load data_wind_anticipated_6bus.mat;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
        else
            data_wind_std=std(data_wind',0,1)';
            data_wind_anticipated = repmat(data_wind_std(R+1:end),1,M_min).*(normrnd(0,0.1,[size(data_wind((R+1:end),:),1),M_min])) + data_wind(R+1:end,:);
            [row_zero,col_zero]=find(data_wind_anticipated<0);
            for i=1:length(row_zero)
                data_wind_anticipated(row_zero(i),col_zero(i))=0;
            end
            windcoefficient=param.windcoefficient;
            save('data_wind_anticipated_6bus.mat','data_wind_anticipated');
            save('windcoefficient.mat','windcoefficient');
        end
    case 30
        if(exist('data_wind_anticipated_30bus.mat','file')&windcoefficient==param.windcoefficient)
        load data_wind_anticipated_30bus.mat;
        else
            data_wind_std=std(data_wind',0,1)';
            data_wind_anticipated = repmat(data_wind_std(R+1:end),1,M_min).*(normrnd(0,0.1,[size(data_wind((R+1:end),:),1),M_min])) + data_wind(R+1:end,:);
            [row_zero,col_zero]=find(data_wind_anticipated<0);
            for i=1:length(row_zero)
                data_wind_anticipated(row_zero(i),col_zero(i))=0;
            end
            windcoefficient=param.windcoefficient;
            save('windcoefficient.mat','windcoefficient');
            save('data_wind_anticipated_30bus.mat','data_wind_anticipated');
            
        end
    case 118
        if(exist('data_wind_anticipated_118bus.mat','file')&windcoefficient==param.windcoefficient)
        load data_wind_anticipated_118bus.mat;
        else
            data_wind_std=std(data_wind',0,1)';
            data_wind_anticipated = repmat(data_wind_std(R+1:end),1,M_min).*(normrnd(0,0.1,[size(data_wind((R+1:end),:),1),M_min])) + data_wind(R+1:end,:);
            [row_zero,col_zero]=find(data_wind_anticipated<0);
            for i=1:length(row_zero)
                data_wind_anticipated(row_zero(i),col_zero(i))=0;
            end
            windcoefficient=param.windcoefficient;
            save('data_wind_anticipated_118bus.mat','data_wind_anticipated');
            save('windcoefficient.mat','windcoefficient');
        end
end
% data_wind=[data_wind;data_wind_anticipated];
data_wind_origin=data_wind; 
% data_wind_anticipated_std=data_wind_anticipated-repmat(mean(data_wind(R+1:end,:),2),1,M_min);
data_wind=[data_wind;data_wind_anticipated];
miu_average=mean(data_wind,2);
R_wan_len=size(data_wind,1);
P_Wind_Max=max(data_wind,[],2);
P_Wind_Min=min(data_wind,[],2);
P_Wind_Max_origin=max(data_wind_origin,[],2);
P_Wind_Min_origin=min(data_wind_origin,[],2);
P_Wind_Max_anticipated=max(data_wind_anticipated,[],2);
P_Wind_Min_anticipated=min(data_wind_anticipated,[],2);

Ckl=repmat(P_Wind_Min,1,Lk)+...
    repmat((P_Wind_Max-P_Wind_Min),1,Lk).*...
    repmat(([1:Lk]/Lk),R_wan_len,1);
gamma_R_T_L=[];

Ckl_origin=repmat(P_Wind_Min_origin,1,Lk)+...
    repmat((P_Wind_Max_origin-P_Wind_Min_origin),1,Lk).*...
    repmat(([1:Lk]/Lk),size(data_wind_origin,1),1);

Ckl_anticipated=repmat(P_Wind_Min_anticipated,1,Lk)+...
    repmat((P_Wind_Max_anticipated-P_Wind_Min_anticipated),1,Lk).*...
    repmat(([1:Lk]/Lk),size(data_wind_anticipated,1),1);

for j=1:Lk-1
    
    gamma_R_T_L=[gamma_R_T_L,mean(max(data_wind-repmat(Ckl(:,j),1,M_min),0),2)+rou*ones(R_wan_len,1)];
end
gamma_k_l=gamma_R_T_L;
%% uit,sit,dit,Sit_wan,PGit,Seitait,Zit,PWrt
% x
x_num=0;
uit_num=N*T;
sit_num=N*T;
dit_num=N*T;
Sit_num=N*T;
x_num=uit_num+sit_num+dit_num+Sit_num;

%other variables
PGit_num=N*T;
Seitait_num=NodeNum*T;
Zit_num=N*T;
PWrt_num=R*T;
if(param.windLoss==1)
    windLoss_num=R*T;
    y_num=PGit_num+Seitait_num+Zit_num+PWrt_num+windLoss_num;
else
    y_num=PGit_num+Seitait_num+Zit_num+PWrt_num;
end

y_location=x_num+1:x_num+y_num;
%location
%x
total_num=0;
uit_location=1:uit_num;
total_num=total_num+length(uit_location);

sit_location=total_num+1:total_num+sit_num;
total_num=total_num+length(sit_location);

dit_location=total_num+1:total_num+dit_num;
total_num=total_num+length(dit_location);

Sit_location=total_num+1:total_num+Sit_num;
total_num=total_num+length(Sit_location);
%y
PGit_location=total_num+1:total_num+PGit_num;
PGit_in_y_location=1:PGit_num;
total_num=total_num+length(PGit_location);

Seitait_location=total_num+1:total_num+Seitait_num;
Seitait_in_y_location=1+PGit_num:PGit_num+Seitait_num;
total_num=total_num+length(Seitait_location);

Zit_location=total_num+1:total_num+Zit_num;
Zit_in_y_location=1+PGit_num+Seitait_num:PGit_num+Seitait_num+Zit_num;
total_num=total_num+length(Zit_location);

PWrt_location=total_num+1:total_num+PWrt_num;
PWrt_in_y_location=PGit_num+Seitait_num+Zit_num+1:PGit_num+Seitait_num+Zit_num+PWrt_num;
total_num=total_num+length(PWrt_location);

if(param.windLoss==1)
    windLoss_location=total_num+1:total_num+windLoss_num;
    windLoss_in_y_location=PGit_num+Seitait_num+Zit_num+PWrt_num+1:PGit_num+Seitait_num+Zit_num+PWrt_num+windLoss_num;
    total_num=total_num+length(windLoss_location);
end

% [UC_model] = function_DC_UCmodel_consider_wind(data);
%% Constraints without uncertain
% uit,sit,dit,Sit_wan,PGit,Seitait,Zit
%state constraints
%s_(i,t)-d_(i,t)=u_(i,t)-u_(i,t-1)
%sit-dit=uit- uit-1
% Aeq_constraints_state=[];
% beq_constraints_state=-1*Ui0;
% 
% %t=1ʱ
% for i=1:N
%     constraint_state=sparse(1,x_num+y_num);
%     
%     uit=sparse(1,N*T);
%     sit=sparse(1,N*T);
%     dit=sparse(1,N*T);
%     
%     uit(1,(i-1)*T+1)=-1;
%     sit(1,(i-1)*T+1)=1;
%     dit(1,(i-1)*T+1)=-1;
%     
%     constraint_state(1,1:N*T)=uit;
%     constraint_state(1,N*T+1:2*N*T)=sit;
%     constraint_state(1,2*N*T+1:3*N*T)=dit;
%     
%     Aeq_constraints_state=[Aeq_constraints_state;constraint_state];
%     
% end
% 
% %t>1
% for i=1:N
%     uit=[sparse(diag(-1*ones(1,T-1))),sparse(T-1,1)]+[sparse(T-1,1),sparse(diag(ones(1,T-1)))];
%     sit=[sparse(T-1,1),sparse(diag(-1*ones(1,T-1)))];
%     dit=[sparse(T-1,1),sparse(diag(ones(1,T-1)))];
%     
%     constraint_state=sparse(T-1,x_num+y_num);
%     constraint_state(1:T-1,(i-1)*T+1:i*T)=uit;
%     constraint_state(1:T-1,(i-1)*T+N*T+1:(i-1)*T+N*T+T)=sit;
%     constraint_state(1:T-1,(i-1)*T+2*N*T+1:(i-1)*T+2*N*T+T)=dit;
%     
%     Aeq_constraints_state=[Aeq_constraints_state;constraint_state];
% end
% beq_constraints_state=[beq_constraints_state;sparse(N*(T-1),1)];
Aeq_constraints_state=UC_model.Aeq_constraints_state;
beq_constraints_state=UC_model.beq_constraints_state;
%% initial status
% Aeq_constraints_initial_statues=[];
% beq_constraints_initial_statues=[];
% 
% for i=1:N
%     if(Ui(i) + Li(i) >= 1)
%         for t=1:Ui(i)+Li(i)
%             
%             uit=sparse(1,N*T);
%             
%             uit(1,(i-1)*T+t)=1;
%             
%             constraints_initial_statues=sparse(1,x_num+y_num);
%             constraints_initial_statues(1,1:N*T)=uit;
%             
%             Aeq_constraints_initial_statues=[Aeq_constraints_initial_statues;constraints_initial_statues];
%             beq_constraints_initial_statues=[beq_constraints_initial_statues;Ui0(i)];
%         end
%     end
% end
Aeq_constraints_initial_statues=[UC_model.Aeq_constraints_initial_statues];
beq_constraints_initial_statues=[UC_model.beq_constraints_initial_statues];
%% start_cost_constraint
%Sit>=Chot,i,t*sit
% Aineq_constraint_start_cost=[sparse(N*T,N*T),sparse(diag(reshape(repmat(ThHot_cost_start,1,T)',N*T,1))),sparse(N*T,N*T),sparse(-1*eye(N*T)),sparse(N*T,y_num)];
% bineq_constraint_start_cost=sparse(N*T,1);
% 
% 
% %Sit>=Ccold,i,t*[sit-sum(dit)-finint]
% for i=1:N
%     for t=1:T
%         constraint_start_cost=sparse(1,x_num+y_num);
%         
%         sit=sparse(1,N*T);
%         dit=sparse(1,N*T);
%         Sit=sparse(1,N*T);
%         
%         sit(1,(i-1)*T+t)=ThCold_cost_start(i);
%         dit(1,(i-1)*T+max(t-ThTime_off_min(i)-ThCold_time_start(i),1):(i-1)*T+t-1)=-1*ThCold_cost_start(i);
%         Sit(1,(i-1)*T+t)=-1;
%         
%         constraint_start_cost(1,N*T+1:2*N*T)=sit;
%         constraint_start_cost(1,2*N*T+1:3*N*T)=dit;
%         constraint_start_cost(1,3*N*T+1:4*N*T)=Sit;
%         
%         Aineq_constraint_start_cost=[Aineq_constraint_start_cost;constraint_start_cost];
%         
%         if(t-ThTime_off_min(i)-ThCold_time_start(i))<=0&& max(0,-ThTime_on_off_init(i))<abs(t-ThTime_off_min(i)-ThCold_time_start(i)-1)+1
%             bineq_constraint_start_cost=[bineq_constraint_start_cost;ThCold_cost_start(i)];
%         else
%             bineq_constraint_start_cost=[bineq_constraint_start_cost;0];
%         end
%     end
% end
Aineq_constraint_start_cost=[UC_model.Aineq_constraint_start_cost];
bineq_constraint_start_cost=UC_model.bineq_constraint_start_cost;
%% minim up/down time constraint
%��s_(i,?) ��u_(i,t)
% Aineq_constraint_min_upordown_time=[];
% bineq_constraint_min_upordown_time=[];
% for i=1:N
%     for t=Ui(i) + 1:T
%         
%         constraint_min_upordown_time=sparse(1,x_num+y_num);
%         
%         uit=sparse(1,N*T);
%         sit=sparse(1,N*T);
%         
%         uit(1,(i-1)*T+t)=-1;
%         sit(1,(i-1)*T+max(0,t-ThTime_on_min(i))+1:(i-1)*T+t)=1;
%         
%         constraint_min_upordown_time(1,1:N*T)=uit;
%         constraint_min_upordown_time(1,N*T+1:2*N*T)=sit;
%         
%         Aineq_constraint_min_upordown_time=[Aineq_constraint_min_upordown_time;constraint_min_upordown_time];
%         bineq_constraint_min_upordown_time=[bineq_constraint_min_upordown_time;0];
%         
%     end
% end
% %��d_(i,?) ��1-u_(i,t)
% for i=1:N
%     for t=Li(i)+1:T
%         
%         constraint_min_upordown_time=sparse(1,x_num+y_num);
%         
%         uit=sparse(1,N*T);
%         dit=sparse(1,N*T);
%         
%         uit(1,(i-1)*T+t)=1;
%         dit(1,(i-1)*T+max(0,t-ThTime_off_min(i))+1:(i-1)*T+t)=1;
%         
%         constraint_min_upordown_time(1,1:N*T)=uit;
%         constraint_min_upordown_time(1,2*N*T+1:3*N*T)=dit;
%         
%         Aineq_constraint_min_upordown_time=[Aineq_constraint_min_upordown_time;constraint_min_upordown_time];
%         bineq_constraint_min_upordown_time=[bineq_constraint_min_upordown_time;1];
%     end
% end
Aineq_constraint_min_upordown_time=[UC_model.Aineq_constraint_min_upordown_time];
bineq_constraint_min_upordown_time=[UC_model.bineq_constraint_min_upordown_time];
%% Constraints with uncertain
% uit=sparse(1,N*T);
% sit=sparse(1,N*T);
% dit=sparse(1,N*T);
% Sit=sparse(1,N*T);
% PGit=sparse(1,N*T);
% Seitait=sparse(1,NodeNum*T);
% Zit=sparse(1,N*T);
%ramping limit
% Aineq_ramp_limt=[];
% bineq_ramp_limt=[];
% Aineq_genration_limit=[];
% bineq_genration_limit=[];
% 
% Aineq_ramp_limt_up=[];
% bineq_ramp_limt_up=[];
% Aineq_ramp_limt_down=[];
% bineq_ramp_limt_down=[];
% 
% Aineq_genration_limit_upper=[];
% bineq_genration_limit_upper=[];
% Aineq_genration_limit_lower=[];
% bineq_genration_limit_lower=[];
% 
% for i=1:N
%     %P_(i,t)^G-P_(i,t-1)^G��u_(i,t-1) P_(i,up)+ s_(i,t)*P_(i,start)
%     %t=1
%     constraint_ramp_limit=sparse(1,x_num+y_num);
%     
%     constraint_ramp_limit(1,N*T+(i-1)*T+1)=-1*Pistartup(i);%sit
%     constraint_ramp_limit(1,4*N*T+(i-1)*T+1)=1;%
%     
%     Aineq_ramp_limt=[Aineq_ramp_limt;constraint_ramp_limit];
%     bineq_ramp_limt=[bineq_ramp_limt;Ui0(i)*Piup(i)+Thon_off_init(i)];
%     Aineq_ramp_limt_up=[Aineq_ramp_limt_up;constraint_ramp_limit];
%     bineq_ramp_limt_up=[bineq_ramp_limt_up;Ui0(i)*Piup(i)+Thon_off_init(i)];
%     
%     %t>1
%     constraint_ramp_limit=sparse(T-1,x_num+y_num);
%     
%     constraint_ramp_limit(:,(i-1)*T+1:(i-1)*T+T-1)=sparse(diag(-1*Piup(i)*ones(T-1,1)));%uit
%     constraint_ramp_limit(:,N*T+(i-1)*T+2:N*T+(i-1)*T+T)=sparse(diag(-1*Pistartup(i)*ones(T-1,1)));%sit
%     constraint_ramp_limit(:,4*N*T+(i-1)*T+1:4*N*T+(i-1)*T+T)=[sparse(diag(-1*ones(T-1,1))),sparse(T-1,1)]+[sparse(T-1,1),sparse(diag(ones(T-1,1)))];%pit
%     Aineq_ramp_limt=[Aineq_ramp_limt;constraint_ramp_limit];
%     bineq_ramp_limt=[bineq_ramp_limt;sparse(T-1,1)];
%     Aineq_ramp_limt_up=[Aineq_ramp_limt_up;constraint_ramp_limit];
%     bineq_ramp_limt_up=[bineq_ramp_limt_up;sparse(T-1,1)];
%     
%     
%     %P_(i,t-1)^G-P_(i,t)^G��u_(i,t) P_(i,down)+d_(i,t) P_(i,shut)
%     %t=1
%     constraint_ramp_limit=sparse(1,x_num+y_num);
%     
%     constraint_ramp_limit(1,(i-1)*T+1)=-1*Pidown(i);%uit
%     constraint_ramp_limit(1,2*N*T+(i-1)*T+1)=-1*Pishutdown(i);%dit
%     constraint_ramp_limit(1,4*N*T+(i-1)*T+1)=-1;%pit
%     Aineq_ramp_limt=[Aineq_ramp_limt;constraint_ramp_limit];
%     bineq_ramp_limt=[bineq_ramp_limt;-1*Thon_off_init(i)];
%     Aineq_ramp_limt_down=[Aineq_ramp_limt_down;constraint_ramp_limit];
%     bineq_ramp_limt_down=[bineq_ramp_limt_down;-1*Thon_off_init(i)];
%     
%     %t>1
%     constraint_ramp_limit=sparse(T-1,x_num+y_num);
%     constraint_ramp_limit(:,(i-1)*T+2:(i-1)*T+T)=sparse(diag(-1*Pidown(i)*ones(T-1,1)));%uit
%     constraint_ramp_limit(:,2*N*T+(i-1)*T+2:2*N*T+(i-1)*T+T)=sparse(diag(-1*Pishutdown(i)*ones(T-1,1)));%dit
%     constraint_ramp_limit(:,4*N*T+(i-1)*T+1:4*N*T+(i-1)*T+T)=[sparse(diag(ones(T-1,1))),sparse(T-1,1)]+[sparse(T-1,1),sparse(diag(-1*ones(T-1,1)))];%pit
%     Aineq_ramp_limt=[Aineq_ramp_limt;constraint_ramp_limit];
%     bineq_ramp_limt=[bineq_ramp_limt;sparse(T-1,1)];
%     Aineq_ramp_limt_down=[Aineq_ramp_limt_down;constraint_ramp_limit];
%     bineq_ramp_limt_down=[bineq_ramp_limt_down;sparse(T-1,1)];
%     
%     %generation limit
%     %u_(i,t) P_min��P_(i,t)^G��u_(i,t) P_max
%     %uit*Pmin<=Pit
%     constraint_genration_limit=sparse(T,x_num+y_num);
%     constraint_genration_limit(:,(i-1)*T+1:(i-1)*T+T)=sparse(diag(ThPimin(i)*ones(T,1)));%uit
%     constraint_genration_limit(:,4*N*T+(i-1)*T+1:4*N*T+(i-1)*T+T)=sparse(diag(-1*ones(T,1)));%pit
%     Aineq_genration_limit=[Aineq_genration_limit;constraint_genration_limit];
%     bineq_genration_limit=[bineq_genration_limit;sparse(T,1)];
%     Aineq_genration_limit_upper=[Aineq_genration_limit_upper;constraint_genration_limit];
%     bineq_genration_limit_upper=[bineq_genration_limit_upper;sparse(T,1)];
%     
%     
%     %uit*Pmax>=Pit
%     constraint_genration_limit=sparse(T,x_num+y_num);
%     constraint_genration_limit(:,(i-1)*T+1:(i-1)*T+T)=sparse(diag(-1*ThPimax(i)*ones(T,1)));%uit
%     constraint_genration_limit(:,4*N*T+(i-1)*T+1:4*N*T+(i-1)*T+T)=sparse(diag(ones(T,1)));%pit
%     Aineq_genration_limit=[Aineq_genration_limit;constraint_genration_limit];
%     bineq_genration_limit=[bineq_genration_limit;sparse(T,1)];
%     Aineq_genration_limit_lower=[Aineq_genration_limit_lower;constraint_genration_limit];
%     bineq_genration_limit_lower=[bineq_genration_limit_lower;sparse(T,1)];
% end

Aineq_ramp_limt=[UC_model.Aineq_constraint_ramp_limt_up;UC_model.Aineq_constraint_ramp_limt_down];
bineq_ramp_limt=[UC_model.bineq_constraint_ramp_limt_up;UC_model.bineq_constraint_ramp_limt_down];
Aineq_genration_limit=[UC_model.Aineq_constraint_genration_limit_upper;UC_model.Aineq_constraint_genration_limit_lower];
bineq_genration_limit=[UC_model.bineq_constraint_genration_limit_upper;UC_model.bineq_constraint_genration_limit_lower];

Aineq_ramp_limt_up=[UC_model.Aineq_constraint_ramp_limt_up];
bineq_ramp_limt_up=[UC_model.bineq_constraint_ramp_limt_up];
Aineq_ramp_limt_down=[UC_model.Aineq_constraint_ramp_limt_down];
bineq_ramp_limt_down=[UC_model.bineq_constraint_ramp_limt_down];

Aineq_genration_limit_upper=[UC_model.Aineq_constraint_genration_limit_upper];
bineq_genration_limit_upper=[UC_model.bineq_constraint_genration_limit_upper];
Aineq_genration_limit_lower=[UC_model.Aineq_constraint_genration_limit_lower];
bineq_genration_limit_lower=[UC_model.bineq_constraint_genration_limit_lower];


%%

%power balance
% pit=[];
% for t=1:N
%     pit=sparse([pit,eye(T)]);
% end
% Aeq_constraint_power_balance=[sparse(T,x_num),pit,sparse(T,(NodeNum+N)*T)];
% beq_constraint_power_balance=Dt;
%
% pw_part=[];
% for r=1:T
%     pw_part=sparse(blkdiag(pw_part,ones(1,R)));
% end
% Aeq_constraint_power_balance=[Aeq_constraint_power_balance,pw_part];
%
% Aineq_constraint_power_balance_upper=Aeq_constraint_power_balance;
% bineq_constraint_power_balance_upper=beq_constraint_power_balance;
% Aineq_constraint_power_balance_lower=-1*Aeq_constraint_power_balance;
% bineq_constraint_power_balance_lower=-1*beq_constraint_power_balance;
%
% Aineq_constraint_power_balance=[Aineq_constraint_power_balance_upper;Aineq_constraint_power_balance_lower];
% bineq_constraint_power_balance=[bineq_constraint_power_balance_upper;bineq_constraint_power_balance_lower];

%%

%DC
% [eq_DCPowerFlow,ineq_DCPowerFlow]=DC_flow_constraint(NodeNum,N,T,Bus_G,bus_PDQR,ThPimin,ThPimax,B,bus_P,All_branchI,All_branchJ,All_branchX,All_branchP,wind_Node);
% Aeq_DCPowerFlow=eq_DCPowerFlow.A;
% beq_DCPowerFlow=eq_DCPowerFlow.b;
% Aineq_DCPowerFlow=ineq_DCPowerFlow.A;
% bineq_DCPowerFlow=ineq_DCPowerFlow.b;
% 
% Aineq_DCPowerFlow_upper=Aeq_DCPowerFlow;
% bineq_DCPowerFlow_upper=beq_DCPowerFlow;
% Aineq_DCPowerFlow_lower=-1*Aeq_DCPowerFlow;
% bineq_DCPowerFlow_lower=-1*beq_DCPowerFlow;
% 
% if(param.eq==0)
%     Aineq_Aeq_DCPowerFlow=[Aineq_DCPowerFlow_upper;Aineq_DCPowerFlow_lower;Aineq_DCPowerFlow];
%     bineq_Aeq_DCPowerFlow=[bineq_DCPowerFlow_upper;bineq_DCPowerFlow_lower;bineq_DCPowerFlow];
% else
%     Aineq_DCPowerFlow_upper=[];
%     bineq_DCPowerFlow_upper=[];
%     Aineq_DCPowerFlow_lower=[];
%     bineq_DCPowerFlow_lower=[];
%     Aineq_Aeq_DCPowerFlow=Aineq_DCPowerFlow;
%     bineq_Aeq_DCPowerFlow=bineq_DCPowerFlow;
% end




if(param.eq==1)
Aineq_Aeq_DCPowerFlow=[UC_model.Aineq_DCPowerFlow];
bineq_Aeq_DCPowerFlow=[UC_model.bineq_DCPowerFlow];
else
    Aineq_Aeq_DCPowerFlow=[UC_model.Aineq_constraint_DCPowerFlow];
bineq_Aeq_DCPowerFlow=[UC_model.bineq_constraint_DCPowerFlow];
end
%%

%objective function linear approximation
% Aineq_linear_approximation=[];
% bineq_linear_approximation=[];
% a_alpha=reshape(repmat(Alpha,1,T)',N*T,1);
% b_beta=reshape(repmat(Beta,1,T)',N*T,1);
% c_gamma=reshape(repmat(Gama,1,T)',N*T,1);
% 
% J=0:L;
% for j=1:L+1
%     pil=reshape(repmat(ThPimin+(J(j)/L)*(ThPimax-ThPimin),1,T)',N*T,1);
%     constraint_linear_approximation=sparse(N*T,x_num+y_num);
%     constraint_linear_approximation(:,1:N*T)=sparse(diag(a_alpha-c_gamma.*power(pil,2)));%uit
%     constraint_linear_approximation(:,4*N*T+1:5*N*T)=sparse(diag(2*c_gamma.*(pil)+b_beta));%pit
%     constraint_linear_approximation(:,5*N*T+NodeNum*T+1:6*N*T+NodeNum*T)=sparse(diag(-1*ones(1,N*T)));%zit
%     Aineq_linear_approximation=[Aineq_linear_approximation;constraint_linear_approximation];
%     bineq_linear_approximation=[bineq_linear_approximation;sparse(N*T,1)];
% end

Aineq_linear_approximation=[UC_model.Aineq_constraint_linear_approximation];
bineq_linear_approximation=[UC_model.bineq_constraint_linear_approximation];
%% Wind loss
Aineq_windLoss_constraint=[UC_model.Aineq_LoadLoss_constraint];
bineq_windLoss_constraint=[UC_model.bineq_LoadLoss_constraint];


%% %% UC model
% first-order uit sit dit Sit
% f_sit=reshape(repmat(ThHot_cost_start,1,T)',N*T,1);
% f_Sit=ones(N*T,1);
% f_Zit=ones(N*T,1);
% f_x=[sparse(N*T,1);f_sit;sparse(N*T,1);f_Sit];
% 
% f_d=[sparse(N*T+NodeNum*T,1);f_Zit];% PGit(N*T) Setait(NodeNum*T) Zit(N*T)
% UC_model.f=[f_x;f_d;sparse(PWrt_num,1)];
% 
% UC_model.Aeq=[Aeq_constraints_state;Aeq_constraints_initial_statues;Aeq_DCPowerFlow];%];Aeq_constraint_power_balance
% UC_model.beq=[beq_constraints_state;beq_constraints_initial_statues;beq_DCPowerFlow];%];beq_constraint_power_balance
% UC_model.Aineq=[Aineq_constraint_min_upordown_time;Aineq_constraint_start_cost;Aineq_genration_limit;Aineq_linear_approximation;Aineq_ramp_limt;Aineq_DCPowerFlow];%
% UC_model.bineq=[bineq_constraint_min_upordown_time;bineq_constraint_start_cost;bineq_genration_limit;bineq_linear_approximation;bineq_ramp_limt;bineq_DCPowerFlow];%;
% UC_model.lb=[sparse(x_num,1);sparse(N*T,1);-inf*ones((NodeNum+N)*T,1);P_Wind_Min];
% UC_model.ub=[ones(3*N*T,1);inf*ones(N*T,1);inf*ones((NodeNum+2*N)*T,1);P_Wind_Max];
% UC_model.ctype='';
% UC_model.ctype(1:3*N*T)='B';
% UC_model.ctype(3*N*T+1:total_num)='C';

% [MDRO_model] = function_Universal_DRO_MILP_construct(UC_model,data,data_wind_history,N,T,param);
%% DRO
%uncertain set

%E(u)<=gamma
%p(Pw,u in Q)=1

%Pw_min<=Pw<=Pw_max
%max{v,0}<=u

C=[];
D=[];
d=[];

%P_wind<=P_wind_max
C=[C;sparse(diag(ones(R_wan_len,1)))];
D=[D;sparse(R_wan_len,R_wan_len*(Lk-1))];
d=[d;P_Wind_Max];

%-P_wind<=-P_wind_min
C=[C;sparse(diag(-1*ones(R_wan_len,1)))];
D=[D;sparse(R_wan_len,R_wan_len*(Lk-1))];
d=[d;-1*P_Wind_Min];

%-phi<=0
C=[C;sparse(R_wan_len*(Lk-1),R_wan_len)];
D=[D;sparse(diag(-1*ones(R_wan_len*(Lk-1),1)))];
d=[d;sparse(R_wan_len*(Lk-1),1)];

%abs(P_wind-P_wind_wan)<=Gap
C=[C;sparse(R*(T-1),R),diag((1-param.WindRGap)*ones(R*(T-1),1)),diag(-1*ones(R*(T-1),1))];
D=[D;sparse(R*(T-1),R_wan_len*(Lk-1))];
d=[d;sparse(R*(T-1),1)];

C=[C;sparse(R*(T-1),R),diag(-1*(1+param.WindRGap)*ones(R*(T-1),1)),diag(ones(R*(T-1),1))];
D=[D;sparse(R*(T-1),R_wan_len*(Lk-1))];
d=[d;sparse(R*(T-1),1)];

%P_wind_r_t - phi_r,t,l <=Cr,t,l
for i=1:R_wan_len
    C_part=sparse(Lk-1,R_wan_len);
    D_part=sparse(Lk-1,R_wan_len*(Lk-1));
    
    C_part(:,i)=1;
    D_part(:,(i-1)*(Lk-1)+1:i*(Lk-1))=sparse(diag(-1*ones((Lk-1),1)));
    
    C=[C;C_part];
    D=[D;D_part];
    
    d=[d;Ckl(i,1:Lk-1)'];
end

%%

DRO_total_var_num=0;
Y0_num=0;
YP_num=0;
YPhi_num=0;

x_location=1:x_num;
DRO_total_var_num=DRO_total_var_num+length(x_location);

Eta_location=DRO_total_var_num+1;
DRO_total_var_num=DRO_total_var_num+length(Eta_location);

lambda_location=DRO_total_var_num+1:DRO_total_var_num+R_wan_len*(Lk-1);
DRO_total_var_num=DRO_total_var_num+length(lambda_location);

Y0_PG=DRO_total_var_num+1:DRO_total_var_num+PGit_num;
DRO_total_var_num=DRO_total_var_num+length(Y0_PG);
PG_in_Y0=Y0_num+1:Y0_num+length(Y0_PG);
Y0_num=length(Y0_PG)+Y0_num;

Y0_Seita=DRO_total_var_num+1:DRO_total_var_num+Seitait_num;
DRO_total_var_num=DRO_total_var_num+length(Y0_Seita);
Seita_in_Y0=Y0_num+1:Y0_num+length(Y0_Seita);
Y0_num=length(Y0_Seita)+Y0_num;

Y0_Zit=DRO_total_var_num+1:DRO_total_var_num+Zit_num;
DRO_total_var_num=DRO_total_var_num+length(Y0_Zit);
Zit_in_Y0=Y0_num+1:Y0_num+length(Y0_Zit);
Y0_num=length(Y0_Zit)+Y0_num;

if(param.windLoss==1)
    Y0_windLoss=DRO_total_var_num+1:DRO_total_var_num+windLoss_num;
    DRO_total_var_num=DRO_total_var_num+length(Y0_windLoss);
    windLoss_in_Y0=Y0_num+1:Y0_num+length(Y0_windLoss);
    Y0_num=length(Y0_windLoss)+Y0_num;
end


if(param.semi_participation==1)
    if(T_wan<T)
        YP_PG=DRO_total_var_num+1:...
            DRO_total_var_num+N*(R*T_wan+0.5*T_wan*(T_wan-1)*R+(T-T_wan)*T_wan*R+(T-1)*R);
        DRO_total_var_num=DRO_total_var_num+length(YP_PG);
        PG_in_YP=YP_num+1:YP_num+length(YP_PG);
        YP_num=YP_num+length(YP_PG);
        
        YP_Seita=DRO_total_var_num+1:...
            DRO_total_var_num+NodeNum*(R*T_wan+0.5*T_wan*(T_wan-1)*R+(T-T_wan)*T_wan*R+(T-1)*R);
        DRO_total_var_num=DRO_total_var_num+length(YP_Seita);
        Seita_in_YP=YP_num+1:YP_num+length(YP_Seita);
        YP_num=YP_num+length(YP_Seita);
        
        YP_Zit=DRO_total_var_num+1:...
            DRO_total_var_num+N*(R*T_wan+0.5*T_wan*(T_wan-1)*R+(T-T_wan)*T_wan*R+(T-1)*R);
        DRO_total_var_num=DRO_total_var_num+length(YP_Zit);
        Zit_in_YP=YP_num+1:YP_num+length(YP_Zit);
        YP_num=YP_num+length(YP_Zit);
        if(param.windLoss==1)
            YP_windLoss=DRO_total_var_num+1:...
                DRO_total_var_num+R*(R*T_wan+0.5*T_wan*(T_wan-1)*R+(T-T_wan)*T_wan*R+(T-1)*R);
            DRO_total_var_num=DRO_total_var_num+length(YP_windLoss);
            windLoss_in_YP=YP_num+1:YP_num+length(YP_windLoss);
            YP_num=YP_num+length(YP_windLoss);
        end
        YPhi_PG=DRO_total_var_num+1:...
            DRO_total_var_num+N*(R*T_wan+0.5*T_wan*(T_wan-1)*R+(T-T_wan)*T_wan*R+(T-1)*R)*(Lk-1);
        DRO_total_var_num=DRO_total_var_num+length(YPhi_PG);
        PG_in_YPhi=YPhi_num+1:YPhi_num+length(YPhi_PG);
        YPhi_num=YPhi_num+length(YPhi_PG);
        
        YPhi_Seita=DRO_total_var_num+1:...
            DRO_total_var_num+NodeNum*(R*T_wan+0.5*T_wan*(T_wan-1)*R+(T-T_wan)*T_wan*R+(T-1)*R)*(Lk-1);
        DRO_total_var_num=DRO_total_var_num+length(YPhi_Seita);
        Seita_in_YPhi=YPhi_num+1:YPhi_num+length(YPhi_Seita);
        YPhi_num=YPhi_num+length(YPhi_Seita);
        
        YPhi_Zit=DRO_total_var_num+1:...
            DRO_total_var_num+N*(R*T_wan+0.5*T_wan*(T_wan-1)*R+(T-T_wan)*T_wan*R+(T-1)*R)*(Lk-1);
        DRO_total_var_num=DRO_total_var_num+length(YPhi_Zit);
        Zit_in_YPhi=YPhi_num+1:YPhi_num+length(YPhi_Zit);
        YPhi_num=YPhi_num+length(YPhi_Zit);
        
        if(param.windLoss==1)
            YPhi_windLoss=DRO_total_var_num+1:...
                DRO_total_var_num+R*(R*T_wan+0.5*T_wan*(T_wan-1)*R+(T-T_wan)*T_wan*R+(T-1)*R)*(Lk-1);
            DRO_total_var_num=DRO_total_var_num+length(YPhi_windLoss);
            windLoss_in_YPhi=YPhi_num+1:YPhi_num+length(YPhi_windLoss);
            YPhi_num=YPhi_num+length(YPhi_windLoss);
        end
        
    else
        YP_PG=DRO_total_var_num+1:...
            DRO_total_var_num+N*(T_wan*R*(0.5-0.5*T_wan+T)+(T-1)*R);
        DRO_total_var_num=DRO_total_var_num+length(YP_PG);
        PG_in_YP=YP_num+1:YP_num+length(YP_PG);
        YP_num=YP_num+length(YP_PG);
        
        YP_Seita=DRO_total_var_num+1:...
            DRO_total_var_num+NodeNum*(T_wan*R*(0.5-0.5*T_wan+T)+(T-1)*R);
        DRO_total_var_num=DRO_total_var_num+length(YP_Seita);
        Seita_in_YP=YP_num+1:YP_num+length(YP_Seita);
        YP_num=YP_num+length(YP_Seita);
        
        YP_Zit=DRO_total_var_num+1:...
            DRO_total_var_num+N*(T_wan*R*(0.5-0.5*T_wan+T)+(T-1)*R);
        DRO_total_var_num=DRO_total_var_num+length(YP_Zit);
        Zit_in_YP=YP_num+1:YP_num+length(YP_Zit);
        YP_num=YP_num+length(YP_Zit);
        if(param.windLoss==1)
            YP_windLoss=DRO_total_var_num+1:...
                DRO_total_var_num+R*(T_wan*R*(0.5-0.5*T_wan+T)+(T-1)*R);
            DRO_total_var_num=DRO_total_var_num+length(YP_windLoss);
            windLoss_in_YP=YP_num+1:YP_num+length(YP_windLoss);
            YP_num=YP_num+length(YP_windLoss);
        end
        
        YPhi_PG=DRO_total_var_num+1:...
            DRO_total_var_num+N*(2*R*T+0.5*T*(T-1)*R-R)*(Lk-1);
        DRO_total_var_num=DRO_total_var_num+length(YPhi_PG);
        PG_in_YPhi=YPhi_num+1:YPhi_num+length(YPhi_PG);
        YPhi_num=YPhi_num+length(YPhi_PG);
        
        YPhi_Seita=DRO_total_var_num+1:...
            DRO_total_var_num+NodeNum*(2*R*T+0.5*T*(T-1)*R-R)*(Lk-1);
        DRO_total_var_num=DRO_total_var_num+length(YPhi_Seita);
        Seita_in_YPhi=YPhi_num+1:YPhi_num+length(YPhi_Seita);
        YPhi_num=YPhi_num+length(YPhi_Seita);
        
        YPhi_Zit=DRO_total_var_num+1:...
            DRO_total_var_num+N*(2*R*T+0.5*T*(T-1)*R-R)*(Lk-1);
        DRO_total_var_num=DRO_total_var_num+length(YPhi_Zit);
        Zit_in_YPhi=YPhi_num+1:YPhi_num+length(YPhi_Zit);
        YPhi_num=YPhi_num+length(YPhi_Zit);
        
        if(param.windLoss==1)
            YPhi_windLoss=DRO_total_var_num+1:...
                DRO_total_var_num+R*(2*R*T+0.5*T*(T-1)*R-R)*(Lk-1);
            DRO_total_var_num=DRO_total_var_num+length(YPhi_windLoss);
            windLoss_in_YPhi=YPhi_num+1:YPhi_num+length(YPhi_windLoss);
            YPhi_num=YPhi_num+length(YPhi_windLoss);
        end
    end
    
    
else
    YP_PG=DRO_total_var_num+1:...
        DRO_total_var_num+N*T_wan*R*(0.5-0.5*T_wan+T);
    DRO_total_var_num=DRO_total_var_num+length(YP_PG);
    PG_in_YP=YP_num+1:YP_num+length(YP_PG);
    YP_num=YP_num+N*T_wan*R*(0.5-0.5*T_wan+T);
    
    YP_Seita=DRO_total_var_num+1:...
        DRO_total_var_num+NodeNum*T_wan*R*(0.5-0.5*T_wan+T);
    DRO_total_var_num=DRO_total_var_num+length(YP_Seita);
    Seita_in_YP=YP_num+1:YP_num+length(YP_Seita);
    YP_num=YP_num+NodeNum*T_wan*R*(0.5-0.5*T_wan+T);
    
    YP_Zit=DRO_total_var_num+1:...
        DRO_total_var_num+N*T_wan*R*(0.5-0.5*T_wan+T);
    DRO_total_var_num=DRO_total_var_num+length(YP_Zit);
    Zit_in_YP=YP_num+1:YP_num+length(YP_Zit);
    YP_num=YP_num+N*T_wan*R*(0.5-0.5*T_wan+T);
    if(param.windLoss==1)
        YP_windLoss=DRO_total_var_num+1:...
            DRO_total_var_num+R*T_wan*R*(0.5-0.5*T_wan+T);
        DRO_total_var_num=DRO_total_var_num+length(YP_windLoss);
        windLoss_in_YP=YP_num+1:YP_num+length(YP_windLoss);
        YP_num=YP_num+length(YP_windLoss);
    end
    
    
    YPhi_PG=DRO_total_var_num+1:...
        DRO_total_var_num+N*(T_wan*R+T_wan*(T_wan-1)*R/2+(T-T_wan)*R*T_wan)*(Lk-1);
    DRO_total_var_num=DRO_total_var_num+length(YPhi_PG);
    PG_in_YPhi=YPhi_num+1:YPhi_num+length(YPhi_PG);
    YPhi_num=YPhi_num+length(YPhi_PG);
    
    YPhi_Seita=DRO_total_var_num+1:...
        DRO_total_var_num+NodeNum*(T_wan*R+T_wan*(T_wan-1)*R/2+(T-T_wan)*R*T_wan)*(Lk-1);
    DRO_total_var_num=DRO_total_var_num+length(YPhi_Seita);
    Seita_in_YPhi=YPhi_num+1:YPhi_num+length(YPhi_Seita);
    YPhi_num=YPhi_num+length(YPhi_Seita);
    
    YPhi_Zit=DRO_total_var_num+1:...
        DRO_total_var_num+N*(T_wan*R+T_wan*(T_wan-1)*R/2+(T-T_wan)*R*T_wan)*(Lk-1);
    DRO_total_var_num=DRO_total_var_num+length(YPhi_Zit);
    Zit_in_YPhi=YPhi_num+1:YPhi_num+length(YPhi_Zit);
    YPhi_num=YPhi_num+length(YPhi_Zit);
    if(param.windLoss==1)
        YPhi_windLoss=DRO_total_var_num+1:...
            DRO_total_var_num+R*(T_wan*R+T_wan*(T_wan-1)*R/2+(T-T_wan)*R*T_wan)*(Lk-1);
        DRO_total_var_num=DRO_total_var_num+length(YPhi_windLoss);
        windLoss_in_YPhi=YPhi_num+1:YPhi_num+length(YPhi_windLoss);
        YPhi_num=YPhi_num+length(YPhi_windLoss);
    end
    
end


if(param.windLoss==1)
    Y0_location=[Y0_PG,Y0_Seita,Y0_Zit,Y0_windLoss];
    YP_location=[YP_PG,YP_Seita,YP_Zit,YP_windLoss];
    YPhi_location=[YPhi_PG,YPhi_Seita,YPhi_Zit,YPhi_windLoss];
else
    Y0_location=[Y0_PG,Y0_Seita,Y0_Zit];
    YP_location=[YP_PG,YP_Seita,YP_Zit];
    YPhi_location=[YPhi_PG,YPhi_Seita,YPhi_Zit];
end

pai_1_location=DRO_total_var_num+1:...
    DRO_total_var_num+size(C,1);
DRO_total_var_num=DRO_total_var_num+length(pai_1_location);

pai_2_location_upper=DRO_total_var_num+1:...
    DRO_total_var_num+size(C,1)*(size(Aineq_genration_limit_upper,1));
DRO_total_var_num=DRO_total_var_num+length(pai_2_location_upper);

pai_2_location_lower=DRO_total_var_num+1:...
    DRO_total_var_num+size(C,1)*(size(Aineq_genration_limit_lower,1));
DRO_total_var_num=DRO_total_var_num+length(pai_2_location_lower);

pai_3_location=DRO_total_var_num+1:DRO_total_var_num+size(C,1)*size(Aineq_linear_approximation,1);
DRO_total_var_num=DRO_total_var_num+length(pai_3_location);

% pai_4_location_upper=DRO_total_var_num+1:...
%     DRO_total_var_num+size(C,1)*(size(Aineq_constraint_power_balance_upper,1));
% DRO_total_var_num=DRO_total_var_num+length(pai_4_location_upper);
%
% pai_4_location_lower=DRO_total_var_num+1:...
%     DRO_total_var_num+size(C,1)*(size(Aineq_constraint_power_balance_lower,1));
% DRO_total_var_num=DRO_total_var_num+length(pai_4_location_lower);

% pai_4_location_upper=DRO_total_var_num+1:...
%     DRO_total_var_num+size(C,1)*(size(Aineq_DCPowerFlow_upper,1));
% DRO_total_var_num=DRO_total_var_num+length(pai_4_location_upper);
% 
% pai_4_location_lower=DRO_total_var_num+1:...
%     DRO_total_var_num+size(C,1)*(size(Aineq_DCPowerFlow_lower,1));
% DRO_total_var_num=DRO_total_var_num+length(pai_4_location_lower);
if(~isempty(Aineq_Aeq_DCPowerFlow))
    pai_4_location=DRO_total_var_num+1:...
        DRO_total_var_num+size(C,1)*(size(Aineq_Aeq_DCPowerFlow,1));
    DRO_total_var_num=DRO_total_var_num+length(pai_4_location);
else
    pai_4_location=[];
end


% pai_4_location=[pai_4_location_upper,pai_4_location_lower,pai_4_location_seita];

% pai_4_location=DRO_total_var_num+1:...
%     DRO_total_var_num+size(C,1)*(size(Aineq_constraint_power_balance,1));
% DRO_total_var_num=DRO_total_var_num+length(pai_4_location);

pai_5_location_upper=DRO_total_var_num+1:...
    DRO_total_var_num+size(C,1)*(size(Aineq_ramp_limt_up,1));
DRO_total_var_num=DRO_total_var_num+length(pai_5_location_upper);

pai_5_location_down=DRO_total_var_num+1:...
    DRO_total_var_num+size(C,1)*(size(Aineq_ramp_limt_down,1));
DRO_total_var_num=DRO_total_var_num+length(pai_5_location_down);

pai_5_location=[pai_5_location_upper,pai_5_location_down];

if(param.windLoss==1)
    pai_6_location=DRO_total_var_num+1:...
        DRO_total_var_num+size(C,1)*(size(Aineq_windLoss_constraint,1));
    DRO_total_var_num=DRO_total_var_num+length(pai_6_location);
end

total_var_num=DRO_total_var_num;

%% linear decision rule

Y0_part=sparse(diag(ones(y_num-PWrt_num,1)));


YP_part=[];
if(param.semi_participation==1)
    for t=1:T
        if(T_wan<T)
            if(t<=T_wan)
                YP_part=sparse(blkdiag(YP_part,ones(1,(t+1)*R)));
            end
            if(t>T_wan&t<=T-1)
                YP_part=sparse(blkdiag(YP_part,ones(1,(T_wan+1)*R)));
            end
            if(t==T)
                YP_part=sparse(blkdiag(YP_part,ones(1,T_wan*R)));
            end
        end
        if(T_wan==T)
            if(t<T)
                YP_part=sparse(blkdiag(YP_part,ones(1,(t+1)*R)));
            else
                YP_part=sparse(blkdiag(YP_part,ones(1,T*R)));
            end
        end
    end
    YP_part_PG=[];
    for i=1:N
        YP_part_PG=sparse(blkdiag(YP_part_PG,YP_part));
    end
    YP_part_Seita=[];
    for i=1:NodeNum
        YP_part_Seita=sparse(blkdiag(YP_part_Seita,YP_part));
    end
    YP_part_Zit=YP_part_PG;

    
    if(param.windLoss==1)
        YP_part_windLoss=[];
        for i=1:R
            YP_part_windLoss=sparse(blkdiag(YP_part_windLoss,YP_part));
        end
    end
    
    YP_part=sparse(y_num-PWrt_num,YP_num);
    YP_part(PGit_location-x_num,YP_PG-x_num-length(Eta_location)-length(lambda_location)-Y0_num)=YP_part_PG;
    YP_part(Seitait_location-x_num,YP_Seita-x_num-length(Eta_location)-length(lambda_location)-Y0_num)=YP_part_Seita;
    YP_part(Zit_location-x_num,YP_Zit-x_num-length(Eta_location)-length(lambda_location)-Y0_num)=YP_part_Zit;
    if(param.windLoss==1)
        YP_part(windLoss_location-x_num-PWrt_num,YP_windLoss-x_num-length(Eta_location)-length(lambda_location)-Y0_num)=YP_part_windLoss;
    end
    
    YPhi_part=[];
    for i=1:T
        if(i<T_wan)
            YPhi_part=sparse(blkdiag(YPhi_part,ones(1,(i+1)*R*(Lk-1))));
        else
            if(i<T)
                YPhi_part=sparse(blkdiag(YPhi_part,ones(1,(T_wan+1)*R*(Lk-1))));
            else
                YPhi_part=sparse(blkdiag(YPhi_part,ones(1,T_wan*R*(Lk-1))));
            end
        end
    end
    YPhi_part_PG=[];
    for i=1:N
        YPhi_part_PG=sparse(blkdiag(YPhi_part_PG,YPhi_part));
    end
    YPhi_part_Seita=[];
    for i=1:NodeNum
        YPhi_part_Seita=sparse(blkdiag(YPhi_part_Seita,YPhi_part));
    end
    YPhi_part_Zit=YPhi_part_PG;

    if(param.windLoss==1)
        YPhi_part_windLoss=[];
        for i=1:R
            YPhi_part_windLoss=sparse(blkdiag(YPhi_part_windLoss,YPhi_part));
        end
    end
    
    
    YPhi_part=sparse(y_num-PWrt_num,YPhi_num);
    YPhi_part(PGit_location-x_num,YPhi_PG-x_num-length(Eta_location)-length(lambda_location)-Y0_num-YP_num)=YPhi_part_PG;
    YPhi_part(Seitait_location-x_num,YPhi_Seita-x_num-length(Eta_location)-length(lambda_location)-Y0_num-YP_num)=YPhi_part_Seita;
    YPhi_part(Zit_location-x_num,YPhi_Zit-x_num-length(Eta_location)-length(lambda_location)-Y0_num-YP_num)=YPhi_part_Zit;
    if(param.windLoss==1)
        YPhi_part(windLoss_location-x_num-PWrt_num,YPhi_windLoss-x_num-length(Eta_location)-length(lambda_location)-Y0_num-YP_num)=YPhi_part_windLoss;
    end
    %model variable
    
    model_coeficent_YP=[];
    model_coeficent_YPhi=[];
    part_YP=sparse(R*T,length(YP_Zit)/N);
    part_YPwan=sparse(R*(T-1),length(YP_Zit)/N);
    part_YPhi=sparse(R*T*(Lk-1),length(YPhi_Zit)/N);
    part_YPhiwan=sparse(R*(T-1)*(Lk-1),length(YPhi_Zit)/N);
    for i=1:T
        if(i<=T_wan)
            if(i<T)
                part_YP(1:i*R,(i-1)*R+(i-1)*(i-2)*R/2+(i-1)*R+1:i*R+(i-1)*i*R/2+(i-1)*R)=diag(ones(R*i,1));
                part_YPhi(1:i*R*(Lk-1),(i-1)*R*(Lk-1)+(i-1)*(i-2)*R*(Lk-1)/2+(i-1)*R*(Lk-1)+1:i*R*(Lk-1)+(i-1)*i*R*(Lk-1)/2+(i-1)*R*(Lk-1))=diag(ones(R*(Lk-1)*i,1));
                
                part_YPwan((i-1)*R+1:i*R,i*R+(i-1)*i*R/2+(i-1)*R+1:i*R+(i-1)*i*R/2+i*R)=diag(ones(R,1));
                part_YPhiwan((i-1)*R*(Lk-1)+1:i*R*(Lk-1),i*R*(Lk-1)+(i-1)*i*R*(Lk-1)/2+(i-1)*R*(Lk-1)+1:i*R*(Lk-1)+(i-1)*i*R*(Lk-1)/2+i*R*(Lk-1))=diag(ones(R*(Lk-1),1));
            else
                part_YP(1:T*R,(T-1)*R+(T-1)*(T-2)*R/2+(T-1)*R+1:T*R+(T-1)*T*R/2+(T-1)*R)=diag(ones(R*T,1));
                part_YPhi(1:T*R*(Lk-1),(T-1)*R*(Lk-1)+(T-1)*(T-2)*R*(Lk-1)/2+(T-1)*R*(Lk-1)+1:T*R*(Lk-1)+(T-1)*T*R*(Lk-1)/2+(T-1)*R*(Lk-1))=diag(ones(R*(Lk-1)*T,1));
            end
        else
            if(i<T)
%                 T_wan*R+(T_wan-1)*T_wan*R/2+(i-1-T_wan)*T_wan*R+1
                part_YP((i-T_wan)*R+1:i*R,T_wan*R+(T_wan-1)*T_wan*R/2+T_wan*R+(i-1-T_wan)*(T_wan+1)*R+1:T_wan*R+(T_wan-1)*T_wan*R/2+T_wan*R+(i-T_wan)*(T_wan+1)*R-R)=diag(ones(R*T_wan,1));
                part_YPhi((i-T_wan)*R*(Lk-1)+1:i*R*(Lk-1),...
                    T_wan*R*(Lk-1)+(T_wan-1)*T_wan*R*(Lk-1)/2+T_wan*R*(Lk-1)+(i-1-T_wan)*(T_wan+1)*R*(Lk-1)+1:...
                    T_wan*R*(Lk-1)+(T_wan-1)*T_wan*R*(Lk-1)/2+T_wan*R*(Lk-1)+(i-T_wan)*(T_wan+1)*R*(Lk-1)-R*(Lk-1))=diag(ones(R*(Lk-1)*T_wan,1));
                
                part_YPwan((i-1)*R+1:i*R,T_wan*R+(T_wan-1)*T_wan*R/2+T_wan*R+(i-T_wan)*(T_wan+1)*R-R+1:T_wan*R+(T_wan-1)*T_wan*R/2+T_wan*R+(i-T_wan)*(T_wan+1)*R)=diag(ones(R,1));
                part_YPhiwan((i-1)*R*(Lk-1)+1:i*R*(Lk-1),T_wan*R*(Lk-1)+(T_wan-1)*T_wan*R*(Lk-1)/2+T_wan*R*(Lk-1)+(i-T_wan)*(T_wan+1)*R*(Lk-1)-R*(Lk-1)+1:T_wan*R*(Lk-1)+(T_wan-1)*T_wan*R*(Lk-1)/2+T_wan*R*(Lk-1)+(i-T_wan)*(T_wan+1)*R*(Lk-1))=diag(ones(R*(Lk-1),1));
            else
                part_YP((i-T_wan)*R+1:i*R,T_wan*R+(T_wan-1)*T_wan*R/2+(i-T_wan-1)*R*T_wan+(T-1)*R+1:T_wan*R+(T_wan-1)*T_wan*R/2+(i-T_wan)*R*T_wan+(T-1)*R)=diag(ones(R*T_wan,1));
                part_YPhi((i-T_wan)*R*(Lk-1)+1:i*R*(Lk-1),T_wan*R*(Lk-1)+(T_wan-1)*T_wan*R*(Lk-1)/2+(i-T_wan-1)*R*(Lk-1)*T_wan+(T-1)*R*(Lk-1)+1:T_wan*R*(Lk-1)+(T_wan-1)*T_wan*R*(Lk-1)/2+(i-T_wan)*R*(Lk-1)*T_wan+(T-1)*R*(Lk-1))=diag(ones(R*(Lk-1)*T_wan,1));
            end
        end
    end
    
    part_YP=[part_YP;part_YPwan];
    part_YPhi=[part_YPhi;part_YPhiwan];
    %PG
    for i=1:N
        model_coeficent_YP=[model_coeficent_YP,part_YP];
        model_coeficent_YPhi=[model_coeficent_YPhi,part_YPhi];
    end
    %seita
    for i=1:NodeNum
        model_coeficent_YP=[model_coeficent_YP,part_YP];
        model_coeficent_YPhi=[model_coeficent_YPhi,part_YPhi];
    end
    %Zit
    for i=1:N
        model_coeficent_YP=[model_coeficent_YP,part_YP];
        model_coeficent_YPhi=[model_coeficent_YPhi,part_YPhi];
    end
    
    if(param.windLoss==1)
        for i=1:R
            model_coeficent_YP=[model_coeficent_YP,part_YP];
            model_coeficent_YPhi=[model_coeficent_YPhi,part_YPhi];
        end
    end
else
    for t=1:T
        if(t<=T_wan)
            YP_part=sparse(blkdiag(YP_part,ones(1,t*R)));
        else
            YP_part=sparse(blkdiag(YP_part,ones(1,T_wan*R)));
        end
    end
    YP_part_PG=[];
    for i=1:N
        YP_part_PG=sparse(blkdiag(YP_part_PG,YP_part));
    end
    YP_part_Seita=[];
    for i=1:NodeNum
        YP_part_Seita=sparse(blkdiag(YP_part_Seita,YP_part));
    end
    YP_part_Zit=YP_part_PG;
    if(param.windLoss==1)
        YP_part_windLoss=[];
        for i=1:R
            YP_part_windLoss=sparse(blkdiag(YP_part_windLoss,YP_part));
        end
    end
    
    YP_part=sparse(y_num-PWrt_num,YP_num);
    YP_part(PGit_location-x_num,YP_PG-x_num-length(Eta_location)-length(lambda_location)-Y0_num)=YP_part_PG;
    YP_part(Seitait_location-x_num,YP_Seita-x_num-length(Eta_location)-length(lambda_location)-Y0_num)=YP_part_Seita;
    YP_part(Zit_location-x_num,YP_Zit-x_num-length(Eta_location)-length(lambda_location)-Y0_num)=YP_part_Zit;
    if(param.windLoss==1)
        YP_part(windLoss_location-x_num-PWrt_num,YP_windLoss-x_num-length(Eta_location)-length(lambda_location)-Y0_num)=YP_part_windLoss;
    end
    
    YPhi_part=[];
    for i=1:T
        YPhi_part=sparse(blkdiag(YPhi_part,ones(1,i*R*(Lk-1))));
    end
    YPhi_part_PG=[];
    for i=1:N
        YPhi_part_PG=sparse(blkdiag(YPhi_part_PG,YPhi_part));
    end
    YPhi_part_Seita=[];
    for i=1:NodeNum
        YPhi_part_Seita=sparse(blkdiag(YPhi_part_Seita,YPhi_part));
    end
    YPhi_part_Zit=YPhi_part_PG;
    if(param.windLoss==1)
        YPhi_part_windLoss=[];
        for i=1:R
            YPhi_part_windLoss=sparse(blkdiag(YPhi_part_windLoss,YPhi_part));
        end
    end
    
    YPhi_part=sparse(y_num-PWrt_num,YPhi_num);
    YPhi_part(PGit_location-x_num,YPhi_PG-x_num-length(Eta_location)-length(lambda_location)-Y0_num-YP_num)=YPhi_part_PG;
    YPhi_part(Seitait_location-x_num,YPhi_Seita-x_num-length(Eta_location)-length(lambda_location)-Y0_num-YP_num)=YPhi_part_Seita;
    YPhi_part(Zit_location-x_num,YPhi_Zit-x_num-length(Eta_location)-length(lambda_location)-Y0_num-YP_num)=YPhi_part_Zit;
        if(param.windLoss==1)
                YPhi_part(windLoss_location-x_num-PWrt_num,YPhi_windLoss-x_num-length(Eta_location)-length(lambda_location)-Y0_num-YP_num)=YPhi_part_windLoss;
        end
    %model variable
    
    model_coeficent_YP=[];
    model_coeficent_YPhi=[];
    part_YP=sparse(R*T,length(YP_Zit)/N);
    part_YPhi=sparse(R*T*(Lk-1),length(YPhi_Zit)/N);
    for i=1:T
        part_YP(1:i*R,(i-1)*R+(i-1)*(i-2)*R/2+1:i*R+(i-1)*i*R/2)=diag(ones(R*i,1));
        part_YPhi(1:i*R*(Lk-1),(i-1)*R*(Lk-1)+(i-1)*(i-2)*R*(Lk-1)/2+1:i*R*(Lk-1)+(i-1)*i*R*(Lk-1)/2)=diag(ones(R*(Lk-1)*i,1));
    end
    
    
    %PG
    for i=1:N
        model_coeficent_YP=[model_coeficent_YP,part_YP];
        model_coeficent_YPhi=[model_coeficent_YPhi,part_YPhi];
    end
    %seita
    for i=1:NodeNum
        model_coeficent_YP=[model_coeficent_YP,part_YP];
        model_coeficent_YPhi=[model_coeficent_YPhi,part_YPhi];
    end
    %Zit
    for i=1:N
        model_coeficent_YP=[model_coeficent_YP,part_YP];
        model_coeficent_YPhi=[model_coeficent_YPhi,part_YPhi];
    end
    if(param.windLoss==1)
        for i=1:R
            model_coeficent_YP=[model_coeficent_YP,part_YP];
            model_coeficent_YPhi=[model_coeficent_YPhi,part_YPhi];
        end
    end
end
%%

%
f=sparse(1,total_var_num);
f(1,sit_location)=reshape(repmat(ThHot_cost_start,1,T)',N*T,1);
f(1,Sit_location)=1;
f(1,Eta_location)=1;
f(1,lambda_location)=reshape(gamma_k_l',size(gamma_k_l,1)*size(gamma_k_l,2),1);


Aineq_constraint_pai_1=sparse(1,total_var_num);
Aineq_constraint_pai_1(1,Eta_location)=-1; %Eta
Aineq_constraint_pai_1(1,Y0_Zit)=1;
if(param.windLoss==1)
Aineq_constraint_pai_1(1,Y0_windLoss)=UC_model.f(windLoss_location,1);
end
Aineq_constraint_pai_1(1,pai_1_location)=d';
bineq_constraint_pai_1=0;

%YP Zit
part_YP_Zit=sparse(R*T,length(YP_Zit)/N);
part_YPhi_Zit=sparse(R*T*(Lk-1),length(YPhi_Zit)/N);
% for i=1:T
%     
%     if(i<T)
%         part_YP_Zit(1:i*R,(i-1)*R+(i-1)*(i-2)*R/2+(i-1)*R+1:i*R+(i-1)*i*R/2+(i-1)*R)=diag(-1*ones(R*i,1));
%         part_YPhi_Zit(1:i*R*(Lk-1),(i-1)*R*(Lk-1)+(i-1)*(i-2)*R*(Lk-1)/2+(i-1)*R*(Lk-1)+1:i*R*(Lk-1)+(i-1)*i*R*(Lk-1)/2+(i-1)*R*(Lk-1))=diag(-1*ones(R*(Lk-1)*i,1));
%         
%         part_YP_Zitwan((i-1)*R+1:i*R,i*R+(i-1)*i*R/2+(i-1)*R+1:i*R+(i-1)*i*R/2+i*R)=diag(-1*ones(R,1));
%         part_YP_Zitwan((i-1)*R*(Lk-1)+1:i*R*(Lk-1),i*R*(Lk-1)+(i-1)*i*R*(Lk-1)/2+(i-1)*R*(Lk-1)+1:i*R*(Lk-1)+(i-1)*i*R*(Lk-1)/2+i*R*(Lk-1))=diag(-1*ones(R*(Lk-1),1));
%     else
%         part_YP_Zit(1:T*R,(T-1)*R+(T-1)*(T-2)*R/2+(T-1)*R+1:T*R+(T-1)*T*R/2+(T-1)*R)=diag(-1*ones(R*T,1));
%         part_YPhi_Zit(1:T*R*(Lk-1),(T-1)*R*(Lk-1)+(T-1)*(T-2)*R*(Lk-1)/2+(T-1)*R*(Lk-1)+1:T*R*(Lk-1)+(T-1)*T*R*(Lk-1)/2+(T-1)*R*(Lk-1))=diag(-1*ones(R*(Lk-1)*T,1));
%     end
% end
part_YP_Zit=-1*part_YP;
part_YPhi_Zit=-1*part_YPhi;
YP_Zit_part=[];
YPhi_Zit_part=[];
for i=1:N
    YP_Zit_part=[YP_Zit_part,part_YP_Zit];
    YPhi_Zit_part=[YPhi_Zit_part,part_YPhi_Zit];
end
if(param.windLoss==1)
    part_YP_windLoss=-1*UC_model.f(windLoss_location(1),1)*part_YP;
    part_YPhi_windLoss=-1*UC_model.f(windLoss_location(1),1)*part_YPhi;
    YP_windLoss_part=[];
    YPhi_windLoss_part=[];
    for i=1:R
        YP_windLoss_part=[YP_windLoss_part,part_YP_windLoss];
        YPhi_windLoss_part=[YPhi_windLoss_part,part_YPhi_windLoss];
    end
end
Aeq_constraint_pai_1=sparse(size(C,2)+size(D,2),total_var_num);
Aeq_constraint_pai_1(size(C,2)+1:size(C,2)+size(D,2),lambda_location)=diag(ones(length(lambda_location),1));
Aeq_constraint_pai_1(1:size(C,2),YP_Zit)=YP_Zit_part;
Aeq_constraint_pai_1(size(C,2)+1:size(C,2)+size(D,2),YPhi_Zit)=YPhi_Zit_part;
if(param.windLoss==1)
Aeq_constraint_pai_1(1:size(C,2),YP_windLoss)=YP_windLoss_part;
Aeq_constraint_pai_1(size(C,2)+1:size(C,2)+size(D,2),YPhi_windLoss)=YPhi_windLoss_part;
end
Aeq_constraint_pai_1(:,pai_1_location)=[C';D'];
beq_constraint_pai_1=sparse(size(C,2)+size(D,2),1);


% for i=1:R_wan_len
%     m_YP_Zit=[];
%     for t=1:T
%         if(t>T_wan)
%             m_YP_Zit=[m_YP_Zit,coefficience_YP_Zit((t-T_wan)*R+1:t*R,i)'];
%         else
%             m_YP_Zit=[m_YP_Zit,coefficience_YP_Zit(1:t*R,i)'];
%         end
%     end
%     part_YP_Zit(i,:)=-1*repmat(m_YP_Zit,1,N);
% end
%
% part_YPhi_Zit=[];
% for i=1:N*T
%     part_YPhi_Zit=[part_YPhi_Zit,diag(-1*ones(R_wan_len*(Lk-1),1))];
% end
%
%
% Aeq_constraint_pai_1=sparse(size(C,2)+size(D,2),total_var_num);
% Aeq_constraint_pai_1(size(C,2)+1:size(C,2)+size(D,2),lambda_location)=diag(ones(length(lambda_location),1));
% Aeq_constraint_pai_1(1:size(C,2),YP_Zit)=part_YP_Zit;
% Aeq_constraint_pai_1(size(C,2)+1:size(C,2)+size(D,2),YPhi_Zit)=part_YPhi_Zit;
% Aeq_constraint_pai_1(:,pai_1_location)=[C';D'];
% beq_constraint_pai_1=sparse(size(C,2)+size(D,2),1);

%% Aineq_genration_limit
Aineq_constraint_pai_2=[];
bineq_constraint_pai_2=[];

Aeq_constraint_pai_2=[];
beq_constraint_pai_2=[];

part_pai_2_d=[];
part_pai_2_C=[];
part_pai_2_D=[];
YP_Aeq_PG=sparse(size(C,2)*size(Aineq_genration_limit_upper,1),length(YP_PG));
YPhi_Aeq_PG=sparse(size(D,2)*size(Aineq_genration_limit_upper,1),length(YPhi_PG));
for i=1:size(Aineq_genration_limit_upper,1)
    part_pai_2_d=blkdiag(part_pai_2_d,d');
    part_pai_2_C=blkdiag(part_pai_2_C,C');
    part_pai_2_D=blkdiag(part_pai_2_D,D');
    
    PG_part_location=find(Aineq_genration_limit_upper(i,PGit_location)~=0);
    
    YP_PG_part_location=find(YP_part(PG_part_location,:)~=0);
    YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location)=-1*Aineq_genration_limit_upper(i,PGit_location(PG_part_location))*model_coeficent_YP(:,YP_PG_part_location);
    %         YP_miu((PG_part_location-1)*size(C,2)+1:PG_part_location*size(C,2),PG_in_YP(1,YP_PG_part_location));
    
    YPhi_PG_part_location=find(YPhi_part(PG_part_location,:)~=0);
    YPhi_Aeq_PG((i-1)*size(D,2)+1:i*size(D,2),YPhi_PG_part_location)=-1*Aineq_genration_limit_upper(i,PGit_location(PG_part_location))*model_coeficent_YPhi(:,YPhi_PG_part_location);
end

constraint_pai_2=sparse(size(Aineq_genration_limit_upper,1),total_var_num);
constraint_pai_2(:,x_location)=Aineq_genration_limit_upper(:,x_location);
constraint_pai_2(:,Y0_PG)=Aineq_genration_limit_upper(:,PGit_location);
constraint_pai_2(:,pai_2_location_upper)=part_pai_2_d;
Aineq_constraint_pai_2=[Aineq_constraint_pai_2;constraint_pai_2];
bineq_constraint_pai_2=[bineq_constraint_pai_2;bineq_genration_limit_upper];

%eq
constraint_pai_2=sparse((size(C,2)+size(D,2))*size(Aineq_genration_limit_upper,1),total_var_num);
constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_upper,1),YP_PG)=YP_Aeq_PG;
constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_upper,1),pai_2_location_upper)=part_pai_2_C;
constraint_pai_2(size(C,2)*size(Aineq_genration_limit_upper,1)+1:(size(C,2)+size(D,2))*size(Aineq_genration_limit_upper,1),YPhi_PG)=YPhi_Aeq_PG;
constraint_pai_2(size(C,2)*size(Aineq_genration_limit_upper,1)+1:(size(C,2)+size(D,2))*size(Aineq_genration_limit_upper,1),pai_2_location_upper)=part_pai_2_D;

Aeq_constraint_pai_2=[Aeq_constraint_pai_2;constraint_pai_2];
beq_constraint_pai_2=[beq_constraint_pai_2;sparse((size(C,2)+size(D,2))*size(Aineq_genration_limit_upper,1),1)];

%Aineq_genration_limit_lower
part_pai_2_d=[];
part_pai_2_C=[];
part_pai_2_D=[];
YP_Aeq_PG=sparse(size(C,2)*size(Aineq_genration_limit_lower,1),length(YP_PG));
YPhi_Aeq_PG=sparse(size(D,2)*size(Aineq_genration_limit_lower,1),length(YPhi_PG));
for i=1:size(Aineq_genration_limit_lower,1)
    part_pai_2_d=blkdiag(part_pai_2_d,d');
    part_pai_2_C=blkdiag(part_pai_2_C,C');
    part_pai_2_D=blkdiag(part_pai_2_D,D');
    
    PG_part_location=find(Aineq_genration_limit_lower(i,PGit_location)~=0);
    
    YP_PG_part_location=find(YP_part(PG_part_location,:)~=0);
    YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location)=-1*Aineq_genration_limit_lower(i,PGit_location(PG_part_location))*model_coeficent_YP(:,YP_PG_part_location);
    
    YPhi_PG_part_location=find(YPhi_part(PG_part_location,:)~=0);
    YPhi_Aeq_PG((i-1)*size(D,2)+1:i*size(D,2),YPhi_PG_part_location)=-1*Aineq_genration_limit_lower(i,PGit_location(PG_part_location))*model_coeficent_YPhi(:,YPhi_PG_part_location);
end

constraint_pai_2=sparse(size(Aineq_genration_limit_lower,1),total_var_num);
constraint_pai_2(:,x_location)=Aineq_genration_limit_lower(:,x_location);
constraint_pai_2(:,Y0_PG)=Aineq_genration_limit_lower(:,PGit_location);
constraint_pai_2(:,pai_2_location_lower)=part_pai_2_d;

Aineq_constraint_pai_2=[Aineq_constraint_pai_2;constraint_pai_2];
bineq_constraint_pai_2=[bineq_constraint_pai_2;bineq_genration_limit_lower];

%eq
constraint_pai_2=sparse((size(C,2)+size(D,2))*size(Aineq_genration_limit_lower,1),total_var_num);
constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_lower,1),YP_PG)=YP_Aeq_PG;
constraint_pai_2(1:size(C,2)*size(Aineq_genration_limit_lower,1),pai_2_location_lower)=part_pai_2_C;
constraint_pai_2(size(C,2)*size(Aineq_genration_limit_lower,1)+1:(size(C,2)+size(D,2))*size(Aineq_genration_limit_lower,1),YPhi_PG)=YPhi_Aeq_PG;
constraint_pai_2(size(C,2)*size(Aineq_genration_limit_lower,1)+1:(size(C,2)+size(D,2))*size(Aineq_genration_limit_lower,1),pai_2_location_lower)=part_pai_2_D;

Aeq_constraint_pai_2=[Aeq_constraint_pai_2;constraint_pai_2];
beq_constraint_pai_2=[beq_constraint_pai_2;sparse((size(C,2)+size(D,2))*size(Aineq_genration_limit_lower,1),1)];


%% Aineq_linear_approximation
Aineq_constraint_pai_3=[];
bineq_constraint_pai_3=[];
Aeq_constraint_pai_3=[];
beq_constraint_pai_3=[];

part_pai_3_d=[];
part_pai_3_C=[];
part_pai_3_D=[];

YP_Aeq_PG=sparse(size(C,2)*size(Aineq_linear_approximation,1),length(YP_PG));
YP_Aeq_Zit=sparse(size(C,2)*size(Aineq_linear_approximation,1),length(YP_Zit));

YPhi_Aeq_PG=sparse(size(D,2)*size(Aineq_linear_approximation,1),length(YPhi_PG));
YPhi_Aeq_Zit=sparse(size(D,2)*size(Aineq_linear_approximation,1),length(YPhi_Zit));

for i=1:size(Aineq_linear_approximation,1)
    part_pai_3_d=blkdiag(part_pai_3_d,d');
    part_pai_3_C=blkdiag(part_pai_3_C,C');
    part_pai_3_D=blkdiag(part_pai_3_D,D');
    
    PG_part_location=find(Aineq_linear_approximation(i,PGit_location)~=0);
    Zit_part_location=find(Aineq_linear_approximation(i,Zit_location)~=0);
    
    YP_PG_part_location=find(YP_part(PG_part_location,:)~=0);
    YP_Zit_part_location=find(YP_part(Zit_in_Y0(Zit_part_location),:)~=0);
    
    YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location)=-1*Aineq_linear_approximation(i,PGit_location(PG_part_location))*model_coeficent_YP(:,YP_PG_part_location);
    
    YP_Aeq_Zit((i-1)*size(C,2)+1:i*size(C,2),YP_Zit_part_location-length(YP_PG)-length(YP_Seita))=-1*Aineq_linear_approximation(i,Zit_location(Zit_part_location))*model_coeficent_YP(:,YP_Zit_part_location);
    
    YPhi_PG_part_location=find(YPhi_part(PG_part_location,:)~=0);
    YPhi_Zit_part_location=find(YPhi_part(Zit_in_Y0(Zit_part_location),:)~=0);
    YPhi_Aeq_PG((i-1)*size(D,2)+1:i*size(D,2),YPhi_PG_part_location)=-1*Aineq_linear_approximation(i,PGit_location(PG_part_location))*model_coeficent_YPhi(:,YPhi_PG_part_location);
    
    YPhi_Aeq_Zit((i-1)*size(D,2)+1:i*size(D,2),YPhi_Zit_part_location-length(YPhi_PG)-length(YPhi_Seita))=-1*Aineq_linear_approximation(i,Zit_location(Zit_part_location))*model_coeficent_YPhi(:,YPhi_Zit_part_location);
end

constraint_pai_3=sparse(size(Aineq_linear_approximation,1),total_var_num);
constraint_pai_3(:,x_location)=Aineq_linear_approximation(:,x_location);
constraint_pai_3(:,Y0_PG)=Aineq_linear_approximation(:,PGit_location);
constraint_pai_3(:,Y0_Zit)=Aineq_linear_approximation(:,Zit_location);
constraint_pai_3(:,pai_3_location)=part_pai_3_d;

Aineq_constraint_pai_3=[Aineq_constraint_pai_3;constraint_pai_3];
bineq_constraint_pai_3=[bineq_constraint_pai_3;bineq_linear_approximation];

%eq

constraint_pai_3=sparse((size(C,2)+size(D,2))*size(Aineq_linear_approximation,1),total_var_num);
% for i=1:size(constraint_pai_3,1)
%     if(i<=size(C,2)*size(Aineq_linear_approximation,1))
%         constraint_pai_3(i,YP_PG)=YP_Aeq_PG(i,:);
%         constraint_pai_3(i,YP_Zit)=YP_Aeq_Zit(i,:);
%         constraint_pai_3(i,pai_3_location)=part_pai_3_C(i,:);
%     else
%         constraint_pai_3(i,YPhi_PG)=YPhi_Aeq_PG(i,:);
%         constraint_pai_3(i,YPhi_Zit)=YPhi_Aeq_Zit(i,:);
%         constraint_pai_3(i,pai_3_location)=part_pai_3_D(i,:);
%     end
% end

    constraint_pai_3=sparse((size(C,2)+size(D,2))*size(Aineq_linear_approximation,1),total_var_num);
    constraint_pai_3(1:size(C,2)*size(Aineq_linear_approximation,1),YP_PG)=YP_Aeq_PG;
    constraint_pai_3(1:size(C,2)*size(Aineq_linear_approximation,1),YP_Zit)=YP_Aeq_Zit;
    constraint_pai_3(1:size(C,2)*size(Aineq_linear_approximation,1),pai_3_location)=part_pai_3_C;
    constraint_pai_3(size(C,2)*size(Aineq_linear_approximation,1)+1:(size(C,2)+size(D,2))*size(Aineq_linear_approximation,1),YPhi_PG)=YPhi_Aeq_PG;
    constraint_pai_3(size(C,2)*size(Aineq_linear_approximation,1)+1:(size(C,2)+size(D,2))*size(Aineq_linear_approximation,1),YPhi_Zit)=YPhi_Aeq_Zit;
    constraint_pai_3(size(C,2)*size(Aineq_linear_approximation,1)+1:(size(C,2)+size(D,2))*size(Aineq_linear_approximation,1),pai_3_location)=part_pai_3_D;
    
Aeq_constraint_pai_3=[Aeq_constraint_pai_3;constraint_pai_3];
beq_constraint_pai_3=[beq_constraint_pai_3;sparse((size(C,2)+size(D,2))*size(Aineq_linear_approximation,1),1)];




%% Aineq_constraint_power_balance

%% DC flow

Aineq_constraint_pai_4=[];
bineq_constraint_pai_4=[];

Aeq_constraint_pai_4=[];
beq_constraint_pai_4=[];

part_pai_4_d=[];
part_pai_4_C=[];
part_pai_4_D=[];

YP_Aeq_PG=sparse(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YP_PG));
YP_Aeq_Seita=sparse(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YP_Seita));
if(param.windLoss==1)
YP_Aeq_windLoss=sparse(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YP_windLoss));
end

YPhi_Aeq_PG=sparse(size(D,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YPhi_PG));
YPhi_Aeq_Seita=sparse(size(D,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YPhi_Seita));
if(param.windLoss==1)
YPhi_Aeq_windLoss=sparse(size(D,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YPhi_windLoss));
end
bineq_constraint_pai_4_part=sparse(size(Aineq_Aeq_DCPowerFlow,1),1);
for i=1:size(Aineq_Aeq_DCPowerFlow,1)
    
    beq_constraint_pai_4_part=sparse(size(C,2),1);
    part_pai_4_d=blkdiag(part_pai_4_d,d');
    part_pai_4_C=blkdiag(part_pai_4_C,C');
    part_pai_4_D=blkdiag(part_pai_4_D,D');
    
    PG_part_location=find(Aineq_Aeq_DCPowerFlow(i,PGit_location)~=0);
    Seita_part_location=find(Aineq_Aeq_DCPowerFlow(i,Seitait_location)~=0);
    PWrt_part_location=find(Aineq_Aeq_DCPowerFlow(i,PWrt_location)~=0);
    if(param.windLoss==1)
    windLoss_part_location=find(Aineq_Aeq_DCPowerFlow(i,windLoss_location)~=0);
    end
    
    for k=1:length(PG_part_location)
        
        [YP_PG_part_location_row,YP_PG_part_location_col]=find(YP_part(PG_part_location(k),:)~=0);
        YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location_col)=-1*Aineq_Aeq_DCPowerFlow(i,PGit_location(PG_part_location(k)))*model_coeficent_YP(:,YP_PG_part_location_col);
        
        YPhi_PG_part_location=find(YPhi_part(PG_part_location(k),:)~=0);
        YPhi_Aeq_PG((i-1)*size(D,2)+1:i*size(D,2),YPhi_PG_part_location)=-1*Aineq_Aeq_DCPowerFlow(i,PGit_location(PG_part_location(k)))*model_coeficent_YPhi(:,YPhi_PG_part_location);
    end
    for k=1:length(Seita_part_location)
        [YP_Seita_part_location_row,YP_Seita_part_location_col]=find(YP_part(Seita_in_Y0(Seita_part_location(k)),:)~=0);
        YP_Aeq_Seita((i-1)*size(C,2)+1:i*size(C,2),YP_Seita_part_location_col-length(YP_PG))=-1*Aineq_Aeq_DCPowerFlow(i,Seitait_location(Seita_part_location(k)))*model_coeficent_YP(:,YP_Seita_part_location_col);
        
        YPhi_Seita_part_location=find(YPhi_part(Seita_in_Y0(Seita_part_location(k)),:)~=0);
        YPhi_Aeq_Seita((i-1)*size(D,2)+1:i*size(D,2),YPhi_Seita_part_location-length(YPhi_PG))=-1*Aineq_Aeq_DCPowerFlow(i,Seitait_location(Seita_part_location(k)))*model_coeficent_YPhi(:,YPhi_Seita_part_location);
    end
    
    if(~isempty(PWrt_part_location))
        for r=1:length(PWrt_part_location)
            beq_constraint_pai_4_part(PWrt_part_location,1)=Aineq_Aeq_DCPowerFlow(i,PWrt_location(PWrt_part_location(r)));
        end
    end
    if(param.windLoss==1)
        for k=1:length(windLoss_part_location)
            [YP_windLoss_part_location_row,YP_windLoss_part_location_col]=find(YP_part(windLoss_in_Y0(windLoss_part_location(k)),:)~=0);
            YP_Aeq_windLoss((i-1)*size(C,2)+1:i*size(C,2),YP_windLoss_part_location_col-length(YP_PG)-length(YP_Seita)-length(YP_Zit))=-1*Aineq_Aeq_DCPowerFlow(i,windLoss_location(windLoss_part_location(k)))*model_coeficent_YP(:,YP_windLoss_part_location_col);
            
            YPhi_windLoss_part_location=find(YPhi_part(windLoss_in_Y0(windLoss_part_location(k)),:)~=0);
            YPhi_Aeq_windLoss((i-1)*size(D,2)+1:i*size(D,2),YPhi_windLoss_part_location-length(YPhi_PG)-length(YPhi_Seita)-length(YPhi_Zit))=-1*Aineq_Aeq_DCPowerFlow(i,windLoss_location(windLoss_part_location(k)))*model_coeficent_YPhi(:,YPhi_windLoss_part_location);
        end
    end
    beq_constraint_pai_4=[beq_constraint_pai_4;beq_constraint_pai_4_part];
end

constraint_pai_4=sparse(size(Aineq_Aeq_DCPowerFlow,1),total_var_num);
constraint_pai_4(:,x_location)=Aineq_Aeq_DCPowerFlow(:,x_location);
constraint_pai_4(:,Y0_PG)=Aineq_Aeq_DCPowerFlow(:,PGit_location);
constraint_pai_4(:,Y0_Seita)=Aineq_Aeq_DCPowerFlow(:,Seitait_location);
if(param.windLoss==1)
constraint_pai_4(:,Y0_windLoss)=Aineq_Aeq_DCPowerFlow(:,windLoss_location);
end
constraint_pai_4(:,pai_4_location)=part_pai_4_d;

Aineq_constraint_pai_4=[Aineq_constraint_pai_4;constraint_pai_4];
bineq_constraint_pai_4=[bineq_constraint_pai_4;bineq_Aeq_DCPowerFlow];


    constraint_pai_4=sparse((size(C,2)+size(D,2))*size(Aineq_Aeq_DCPowerFlow,1),total_var_num);
    constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),YP_PG)=YP_Aeq_PG;
    constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),YP_Seita)=YP_Aeq_Seita;
    if(param.windLoss==1)
    constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),YP_windLoss)=YP_Aeq_windLoss;
    end
    constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),pai_4_location)=part_pai_4_C;
    constraint_pai_4(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1)+1:(size(C,2)+size(D,2))*size(Aineq_Aeq_DCPowerFlow,1),YPhi_PG)=YPhi_Aeq_PG;
    constraint_pai_4(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1)+1:(size(C,2)+size(D,2))*size(Aineq_Aeq_DCPowerFlow,1),YPhi_Seita)=YPhi_Aeq_Seita;
    if(param.windLoss==1)
    constraint_pai_4(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1)+1:(size(C,2)+size(D,2))*size(Aineq_Aeq_DCPowerFlow,1),YPhi_windLoss)=YPhi_Aeq_windLoss;
    end
    constraint_pai_4(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1)+1:(size(C,2)+size(D,2))*size(Aineq_Aeq_DCPowerFlow,1),pai_4_location)=part_pai_4_D;
  

Aeq_constraint_pai_4=[Aeq_constraint_pai_4;constraint_pai_4];
beq_constraint_pai_4=[beq_constraint_pai_4;sparse(size(D,2)*size(Aineq_Aeq_DCPowerFlow,1),1)];

Aineq_constraint_pai_4_1=[];
bineq_constraint_pai_4_1=[];

Aeq_constraint_pai_4_1=[];
beq_constraint_pai_4_1=[];
if(param.eq==1)
    Aineq_Aeq_DCPowerFlow=UC_model.Aeq_DCPowerFlow;
    bineq_Aeq_DCPowerFlow=UC_model.beq_DCPowerFlow;
    
    YP_Aeq_PG=sparse(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YP_PG));
    YP_Aeq_Seita=sparse(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YP_Seita));
    if(param.windLoss==1)
    YP_Aeq_windLoss=sparse(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YP_windLoss));
    end
    
    YPhi_Aeq_PG=sparse(size(D,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YPhi_PG));
    YPhi_Aeq_Seita=sparse(size(D,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YPhi_Seita));
    if(param.windLoss==1)
    YPhi_Aeq_windLoss=sparse(size(D,2)*size(Aineq_Aeq_DCPowerFlow,1),length(YPhi_windLoss));
    end
    bineq_constraint_pai_4_part=sparse(size(Aineq_Aeq_DCPowerFlow,1),1);
    for i=1:size(Aineq_Aeq_DCPowerFlow,1)
        
        beq_constraint_pai_4_part=sparse(size(C,2),1);
        
        PG_part_location=find(Aineq_Aeq_DCPowerFlow(i,PGit_location)~=0);
        Seita_part_location=find(Aineq_Aeq_DCPowerFlow(i,Seitait_location)~=0);
        PWrt_part_location=find(Aineq_Aeq_DCPowerFlow(i,PWrt_location)~=0);
        if(param.windLoss==1)
        windLoss_part_location=find(Aineq_Aeq_DCPowerFlow(i,windLoss_location)~=0);
        end
        
        for k=1:length(PG_part_location)
            
            [YP_PG_part_location_row,YP_PG_part_location_col]=find(YP_part(PG_part_location(k),:)~=0);
            YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location_col)=-1*Aineq_Aeq_DCPowerFlow(i,PGit_location(PG_part_location(k)))*model_coeficent_YP(:,YP_PG_part_location_col);
            
            YPhi_PG_part_location=find(YPhi_part(PG_part_location(k),:)~=0);
            YPhi_Aeq_PG((i-1)*size(D,2)+1:i*size(D,2),YPhi_PG_part_location)=-1*Aineq_Aeq_DCPowerFlow(i,PGit_location(PG_part_location(k)))*model_coeficent_YPhi(:,YPhi_PG_part_location);
        end
        for k=1:length(Seita_part_location)
            [YP_Seita_part_location_row,YP_Seita_part_location_col]=find(YP_part(Seita_in_Y0(Seita_part_location(k)),:)~=0);
            YP_Aeq_Seita((i-1)*size(C,2)+1:i*size(C,2),YP_Seita_part_location_col-length(YP_PG))=-1*Aineq_Aeq_DCPowerFlow(i,Seitait_location(Seita_part_location(k)))*model_coeficent_YP(:,YP_Seita_part_location_col);
            
            YPhi_Seita_part_location=find(YPhi_part(Seita_in_Y0(Seita_part_location(k)),:)~=0);
            YPhi_Aeq_Seita((i-1)*size(D,2)+1:i*size(D,2),YPhi_Seita_part_location-length(YPhi_PG))=-1*Aineq_Aeq_DCPowerFlow(i,Seitait_location(Seita_part_location(k)))*model_coeficent_YPhi(:,YPhi_Seita_part_location);
        end
        
        if(~isempty(PWrt_part_location))
            for r=1:length(PWrt_part_location)
                beq_constraint_pai_4_part(PWrt_part_location,1)=Aineq_Aeq_DCPowerFlow(i,PWrt_location(PWrt_part_location(r)));
            end
        end
        if(param.windLoss==1)
        for k=1:length(windLoss_part_location)
            [YP_windLoss_part_location_row,YP_windLoss_part_location_col]=find(YP_part(windLoss_in_Y0(windLoss_part_location(k)),:)~=0);
            YP_Aeq_windLoss((i-1)*size(C,2)+1:i*size(C,2),YP_windLoss_part_location_col-length(YP_PG)-length(YP_Seita)-length(YP_Zit))=-1*Aineq_Aeq_DCPowerFlow(i,windLoss_location(windLoss_part_location(k)))*model_coeficent_YP(:,YP_windLoss_part_location_col);
            
            YPhi_windLoss_part_location=find(YPhi_part(windLoss_in_Y0(windLoss_part_location(k)),:)~=0);
            YPhi_Aeq_windLoss((i-1)*size(D,2)+1:i*size(D,2),YPhi_windLoss_part_location-length(YPhi_PG)-length(YPhi_Seita)-length(YPhi_Zit))=-1*Aineq_Aeq_DCPowerFlow(i,windLoss_location(windLoss_part_location(k)))*model_coeficent_YPhi(:,YPhi_windLoss_part_location);
        end
        end
        beq_constraint_pai_4_1=[beq_constraint_pai_4_1;beq_constraint_pai_4_part];
    end
    
    constraint_pai_4=sparse(size(Aineq_Aeq_DCPowerFlow,1),total_var_num);
    constraint_pai_4(:,x_location)=Aineq_Aeq_DCPowerFlow(:,x_location);
    constraint_pai_4(:,Y0_PG)=Aineq_Aeq_DCPowerFlow(:,PGit_location);
    constraint_pai_4(:,Y0_Seita)=Aineq_Aeq_DCPowerFlow(:,Seitait_location);
    if(param.windLoss==1)
    constraint_pai_4(:,Y0_windLoss)=Aineq_Aeq_DCPowerFlow(:,windLoss_location);
    end
    
    
    Aineq_constraint_pai_4_1=[Aineq_constraint_pai_4_1;constraint_pai_4];
    bineq_constraint_pai_4_1=[bineq_constraint_pai_4_1;bineq_Aeq_DCPowerFlow];
    
    %eq
%     constraint_pai_4=sparse((size(C,2)+size(D,2))*size(Aineq_Aeq_DCPowerFlow,1),total_var_num);
%     for i=1:size(constraint_pai_4,1)
%         if(i<=size(C,2)*size(Aineq_Aeq_DCPowerFlow,1))
%             constraint_pai_4(i,YP_PG)=YP_Aeq_PG(i,:);
%             constraint_pai_4(i,YP_Seita)=YP_Aeq_Seita(i,:);
%         else
%             constraint_pai_4(i,YPhi_PG)=YPhi_Aeq_PG(i,:);
%             constraint_pai_4(i,YPhi_Seita)=YPhi_Aeq_Seita(i,:);
%         end
%     end

constraint_pai_4=sparse((size(C,2)+size(D,2))*size(Aineq_Aeq_DCPowerFlow,1),total_var_num);
constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),YP_PG)=YP_Aeq_PG;
constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),YP_Seita)=YP_Aeq_Seita;
if(param.windLoss==1)
constraint_pai_4(1:size(C,2)*size(Aineq_Aeq_DCPowerFlow,1),YP_windLoss)=YP_Aeq_windLoss;
end
constraint_pai_4(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1)+1:(size(C,2)+size(D,2))*size(Aineq_Aeq_DCPowerFlow,1),YPhi_PG)=YPhi_Aeq_PG;
if(param.windLoss==1)
constraint_pai_4(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1)+1:(size(C,2)+size(D,2))*size(Aineq_Aeq_DCPowerFlow,1),YPhi_windLoss)=YPhi_Aeq_windLoss;
end
constraint_pai_4(size(C,2)*size(Aineq_Aeq_DCPowerFlow,1)+1:(size(C,2)+size(D,2))*size(Aineq_Aeq_DCPowerFlow,1),YPhi_Seita)=YPhi_Aeq_Seita;

Aeq_constraint_pai_4_1=[Aeq_constraint_pai_4_1;constraint_pai_4];
beq_constraint_pai_4_1=[beq_constraint_pai_4_1;sparse(size(D,2)*size(Aineq_Aeq_DCPowerFlow,1),1)];

end


%% Aineq_ramp_limt
Aineq_constraint_pai_5=[];
bineq_constraint_pai_5=[];

Aeq_constraint_pai_5=[];
beq_constraint_pai_5=[];

part_pai_5_d=[];
part_pai_5_C=[];
part_pai_5_D=[];

YP_Aeq_PG=sparse(size(C,2)*size(Aineq_ramp_limt,1),length(YP_PG));

YPhi_Aeq_PG=sparse(size(D,2)*size(Aineq_ramp_limt,1),length(YPhi_PG));
for i=1:size(Aineq_ramp_limt,1)
    part_pai_5_d=blkdiag(part_pai_5_d,d');
    part_pai_5_C=blkdiag(part_pai_5_C,C');
    part_pai_5_D=blkdiag(part_pai_5_D,D');
    
    PG_part_location=find(Aineq_ramp_limt(i,PGit_location)~=0);
    
    
    for k=1:length(PG_part_location)
        [YP_PG_part_location_row,YP_PG_part_location_col]=find(YP_part(PG_part_location(k),:)~=0);
        YP_Aeq_PG((i-1)*size(C,2)+1:i*size(C,2),YP_PG_part_location_col)=-1*Aineq_ramp_limt(i,PGit_location(PG_part_location(k)))*model_coeficent_YP(:,YP_PG_part_location_col);
        
        YPhi_PG_part_location=find(YPhi_part(PG_part_location(k),:)~=0);
        YPhi_Aeq_PG((i-1)*size(D,2)+1:i*size(D,2),YPhi_PG_part_location)=-1*Aineq_ramp_limt(i,PGit_location(PG_part_location(k)))*model_coeficent_YPhi(:,YPhi_PG_part_location);
    end
    
end

constraint_pai_5=sparse(size(Aineq_ramp_limt,1),total_var_num);
constraint_pai_5(:,x_location)=Aineq_ramp_limt(:,x_location);
constraint_pai_5(:,Y0_PG)=Aineq_ramp_limt(:,PGit_location);
constraint_pai_5(:,pai_5_location)=part_pai_5_d;

Aineq_constraint_pai_5=[Aineq_constraint_pai_5;constraint_pai_5];
bineq_constraint_pai_5=[bineq_constraint_pai_5;bineq_ramp_limt];

%eq
% constraint_pai_5=sparse((size(C,2)+size(D,2))*size(Aineq_ramp_limt,1),total_var_num);
% for i=1:size(constraint_pai_5,1)
%     if(i<=size(C,2)*size(Aineq_ramp_limt,1))
%         constraint_pai_5(i,YP_PG)=YP_Aeq_PG(i,:);
%         constraint_pai_5(i,pai_5_location)=part_pai_5_C(i,:);
%     else
%         constraint_pai_5(i,YPhi_PG)=YPhi_Aeq_PG(i,:);
%         constraint_pai_5(i,pai_5_location)=part_pai_5_D(i,:);
%     end
% end
    constraint_pai_5=sparse((size(C,2)+size(D,2))*size(Aineq_ramp_limt,1),total_var_num);
    constraint_pai_5(1:size(C,2)*size(Aineq_ramp_limt,1),YP_PG)=YP_Aeq_PG;
    constraint_pai_5(1:size(C,2)*size(Aineq_ramp_limt,1),pai_5_location)=part_pai_5_C;
    constraint_pai_5(size(C,2)*size(Aineq_ramp_limt,1)+1:(size(C,2)+size(D,2))*size(Aineq_ramp_limt,1),YPhi_PG)=YPhi_Aeq_PG;
    constraint_pai_5(size(C,2)*size(Aineq_ramp_limt,1)+1:(size(C,2)+size(D,2))*size(Aineq_ramp_limt,1),pai_5_location)=part_pai_5_D;
    

Aeq_constraint_pai_5=[Aeq_constraint_pai_5;constraint_pai_5];
beq_constraint_pai_5=[beq_constraint_pai_5;sparse((size(C,2)+size(D,2))*size(Aineq_ramp_limt,1),1)];
%% windLoss
Aineq_constraint_pai_6=[];
bineq_constraint_pai_6=[];

Aeq_constraint_pai_6=[];
beq_constraint_pai_6=[];
if(param.windLoss==1)
    part_pai_6_d=[];
    part_pai_6_C=[];
    part_pai_6_D=[];
    
    YP_Aeq_windLoss=sparse(size(C,2)*size(Aineq_windLoss_constraint,1),length(YP_windLoss));
    
    YPhi_Aeq_windLoss=sparse(size(D,2)*size(Aineq_windLoss_constraint,1),length(YPhi_windLoss));
    for i=1:size(Aineq_windLoss_constraint,1)
        beq_constraint_pai_6_part=sparse(size(C,2),1);
        part_pai_6_d=blkdiag(part_pai_6_d,d');
        part_pai_6_C=blkdiag(part_pai_6_C,C');
        part_pai_6_D=blkdiag(part_pai_6_D,D');
        
        windLoss_part_location=find(Aineq_windLoss_constraint(i,windLoss_location)~=0);
        PWrt_part_location=find(Aineq_windLoss_constraint(i,PWrt_location)~=0);
        
        for k=1:length(windLoss_part_location)
            [YP_windLoss_part_location_row,YP_windLoss_part_location_col]=find(YP_part(windLoss_in_Y0(windLoss_part_location(k)),:)~=0);
            YP_Aeq_windLoss((i-1)*size(C,2)+1:i*size(C,2),YP_windLoss_part_location_col-length(YP_PG)-length(YP_Seita)-length(YP_Zit))=-1*Aineq_windLoss_constraint(i,windLoss_location(windLoss_part_location(k)))*model_coeficent_YP(:,YP_windLoss_part_location_col);
            
            YPhi_windLoss_part_location=find(YPhi_part(windLoss_in_Y0(windLoss_part_location(k)),:)~=0);
            YPhi_Aeq_windLoss((i-1)*size(D,2)+1:i*size(D,2),YPhi_windLoss_part_location-length(YPhi_PG)-length(YPhi_Seita)-length(YPhi_Zit))=-1*Aineq_windLoss_constraint(i,windLoss_location(windLoss_part_location(k)))*model_coeficent_YPhi(:,YPhi_windLoss_part_location);
        end
        
        if(~isempty(PWrt_part_location))
            for r=1:length(PWrt_part_location)
                beq_constraint_pai_6_part(PWrt_part_location,1)=Aineq_windLoss_constraint(i,PWrt_location(PWrt_part_location(r)));
            end
        end
        beq_constraint_pai_6=[beq_constraint_pai_6;beq_constraint_pai_6_part];
    end
    
    constraint_pai_6=sparse(size(Aineq_windLoss_constraint,1),total_var_num);
    constraint_pai_6(:,Y0_windLoss)=Aineq_windLoss_constraint(:,windLoss_location);
    constraint_pai_6(:,pai_6_location)=part_pai_6_d;
    
    Aineq_constraint_pai_6=[Aineq_constraint_pai_6;constraint_pai_6];
    bineq_constraint_pai_6=[bineq_constraint_pai_6;bineq_windLoss_constraint];
    
    constraint_pai_6=sparse((size(C,2)+size(D,2))*size(Aineq_windLoss_constraint,1),total_var_num);
    constraint_pai_6(1:size(C,2)*size(Aineq_windLoss_constraint,1),YP_windLoss)=YP_Aeq_windLoss;
    constraint_pai_6(1:size(C,2)*size(Aineq_windLoss_constraint,1),pai_6_location)=part_pai_6_C;
    constraint_pai_6(size(C,2)*size(Aineq_windLoss_constraint,1)+1:(size(C,2)+size(D,2))*size(Aineq_windLoss_constraint,1),YPhi_windLoss)=YPhi_Aeq_windLoss;
    constraint_pai_6(size(C,2)*size(Aineq_windLoss_constraint,1)+1:(size(C,2)+size(D,2))*size(Aineq_windLoss_constraint,1),pai_6_location)=part_pai_6_D;
    
    Aeq_constraint_pai_6=[Aeq_constraint_pai_6;constraint_pai_6];
    beq_constraint_pai_6=[beq_constraint_pai_6;sparse((size(D,2))*size(Aineq_windLoss_constraint,1),1)];
end
%% DRO model
Aineq_two_bin_var_constraint=[Aineq_constraint_min_upordown_time;Aineq_constraint_start_cost];
bineq_two_bin_var_constraint=[bineq_constraint_min_upordown_time;bineq_constraint_start_cost];

Aeq_two_bin_var_constraint=[Aeq_constraints_state;Aeq_constraints_initial_statues];
beq_two_bin_var_constraint=[beq_constraints_state;beq_constraints_initial_statues];

Aineq_two_bin_var=sparse(size(Aineq_two_bin_var_constraint,1),total_var_num);
Aineq_two_bin_var(:,x_location)=Aineq_two_bin_var_constraint(:,x_location);

Aeq_two_bin_var=sparse(size(Aeq_two_bin_var_constraint,1),total_var_num);
Aeq_two_bin_var(:,x_location)=Aeq_two_bin_var_constraint(:,x_location);

Aineq=[Aineq_two_bin_var;Aineq_constraint_pai_1;Aineq_constraint_pai_2;Aineq_constraint_pai_3;Aineq_constraint_pai_4;Aineq_constraint_pai_5;Aineq_constraint_pai_6];%
bineq=[bineq_two_bin_var_constraint;bineq_constraint_pai_1;bineq_constraint_pai_2;bineq_constraint_pai_3;bineq_constraint_pai_4;bineq_constraint_pai_5;bineq_constraint_pai_6];%
Aeq=[Aeq_two_bin_var;Aeq_constraint_pai_1;Aeq_constraint_pai_2;Aeq_constraint_pai_3;Aeq_constraint_pai_4;Aeq_constraint_pai_5;Aineq_constraint_pai_4_1;Aeq_constraint_pai_4_1;Aeq_constraint_pai_6];%
beq=[beq_two_bin_var_constraint;beq_constraint_pai_1;beq_constraint_pai_2;beq_constraint_pai_3;beq_constraint_pai_4;beq_constraint_pai_5;bineq_constraint_pai_4_1;beq_constraint_pai_4_1;beq_constraint_pai_6];%


lb=sparse(total_var_num,1);
lb(Eta_location,1)=-inf;
lb(Y0_PG,1)=-inf;
lb(Y0_Seita,1)=-inf;
lb(Y0_Zit,1)=-inf;
lb(YP_PG,1)=-inf;
lb(YP_Seita,1)=-inf;
lb(YP_Zit,1)=-inf;
lb(YPhi_PG,1)=-inf;
lb(YPhi_Seita,1)=-inf;
lb(YPhi_Zit,1)=-inf;
if(param.windLoss==1)
    lb(Y0_windLoss,1)=-inf;
    lb(YP_windLoss,1)=-inf;
    lb(YPhi_windLoss,1)=-inf;    
end

ub=inf*ones(total_var_num,1);
ub(uit_location,1)=1;
ub(sit_location,1)=1;
ub(dit_location,1)=1;

ctype='';
ctype(1:total_var_num)='C';
ctype(uit_location)='B';
ctype(sit_location)='B';
ctype(dit_location)='B';


%%


model.Q=[];
model.f=f;
model.Aeq=Aeq;
model.beq=beq;
model.Aineq=Aineq;
model.bineq=bineq;
model.lb=lb;
model.ub=ub;
model.ctype=ctype;

model.PG_in_Y0=PG_in_Y0;
model.PG_in_YP=PG_in_YP;
model.PG_in_YPhi=PG_in_YPhi;

model.windLoss_in_Y0=windLoss_in_Y0;
model.windLoss_in_YP=windLoss_in_YP;
model.windLoss_in_YPhi=windLoss_in_YPhi;


model.Y0_part=Y0_part;
model.YP_part=YP_part;
model.YPhi_part=YPhi_part;

model.Y0_location=Y0_location;
model.YP_location=YP_location;
model.YPhi_location=YPhi_location;

model.data_wind_origin=data_wind_origin; 
model.data_wind_anticipated=data_wind_anticipated;

model.Ckl_origin=Ckl_origin;
model.Ckl_anticipated=Ckl_anticipated;

model.data_wind_origin=data_wind; 
model.Ckl_origin=Ckl;

model.Y0_location_without_PCA=Y0_location;
model.YP_location_without_PCA=YP_location;

model.PG_in_Y0_without_PCA=PG_in_Y0;
model.PG_in_YP_without_PCA=PG_in_YP;

if(param.windLoss==1)
model.windLoss_in_Y0_without_PCA=windLoss_in_Y0;
model.windLoss_in_YP_without_PCA=windLoss_in_YP;
end

model.Y0_index_without_PCA=Y0_part;
model.YP_index_without_PCA=YP_part;

end


function [eq,ineq]=DC_flow_constraint(NodeNum,N,T,Bus_G,Bus_D,ThPimin,ThPimax,B,bus_P,branchI,branchJ,branchX,branchP,wind_node)
Aeq_constraints_DCPowerFlow=[];
beq_constraints_DCPowerFlow=[];

Aineq_constraints_DCPowerFlow=[];
bineq_constraints_DCPowerFlow=[];

R=length(wind_node);

PG=sparse(1,NodeNum);
PD=sparse(1,NodeNum);
PG(1,Bus_G)=1;
PD(1,Bus_D)=1;

P_index=1;
D_index=1;
for i=1:NodeNum
    if(PG(i)==1&&PD(i)==1)
        P_no=find(i==Bus_G);
        D_no=find(i==Bus_D);
        PW_no=find(i==wind_node);
        
        uit=sparse(T,N*T);
        PitWan=sparse(T,N*T);
        Seita=sparse(T,NodeNum*T);
        
        uit(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag(ThPimin(P_no)*ones(1,T)));
        PitWan(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag((ThPimax(P_no)-ThPimin(P_no))*ones(1,T)));
        coefficient=[];
        for j=1:NodeNum
            coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
        end
        Seita=-1*coefficient;
        
        Pit=sparse(T,N*T);
        Pit(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag(ones(1,T)));
        
        PWrt=sparse(T,R*T);
        if(~isempty(PW_no))
            PWrt=[];
            for t=1:T
                PW_part=sparse(1,R);
                PW_part(1,PW_no)=1;
                PWrt=blkdiag(PWrt,PW_part);
            end
        end
        
        
        Aeq_DCPowerFlow=[sparse(T,4*N*T),Pit,Seita,sparse(T,N*T),PWrt];
        beq_DCPowerFlow=[bus_P(:,D_no)];
        
        Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
        beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
        
        P_index=P_index+1;
        D_index=D_index+1;
    end
    if(PG(i)==1&&PD(i)==0)
        P_no=find(i==Bus_G);
        PW_no=find(i==wind_node);
        
        uit=sparse(T,N*T);
        PitWan=sparse(T,N*T);
        Seita=sparse(T,NodeNum*T);
        
        uit(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag(ThPimin(P_no)*ones(1,T)));
        PitWan(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag((ThPimax(P_no)-ThPimin(P_no))*ones(1,T)));
        coefficient=[];
        for j=1:NodeNum
            coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
        end
        Seita=-1*coefficient;
        
        
        Pit=sparse(T,N*T);
        Pit(1:T,(P_no-1)*T+1:P_no*T)=sparse(diag(ones(1,T)));
        
        PWrt=sparse(T,R*T);
        if(~isempty(PW_no))
            PWrt=[];
            for t=1:T
                PW_part=sparse(1,R);
                PW_part(1,PW_no)=1;
                PWrt=blkdiag(PWrt,PW_part);
            end
        end
        
        Aeq_DCPowerFlow=[sparse(T,4*N*T),Pit,Seita,sparse(T,N*T),PWrt];
        beq_DCPowerFlow=[sparse(T,1)];
        
        Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
        beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
        
        
        P_index=P_index+1;
    end
    if(PG(i)==0&&PD(i)==1)
        
        D_no=find(i==Bus_D);
        PW_no=find(i==wind_node);
        Seita=sparse(T,NodeNum*T);
        coefficient=[];
        for j=1:NodeNum
            coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
        end
        Seita=-1*coefficient;
        
        PWrt=sparse(T,R*T);
        if(~isempty(PW_no))
            PWrt=[];
            for t=1:T
                PW_part=sparse(1,R);
                PW_part(1,PW_no)=1;
                PWrt=blkdiag(PWrt,PW_part);
            end
        end
        
        Aeq_DCPowerFlow=[sparse(T,5*N*T),Seita,sparse(T,N*T),PWrt];
        beq_DCPowerFlow=[bus_P(:,D_no)];
        Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
        beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
        D_index=D_index+1;
    end
    if(PG(i)==0&&PD(i)==0)
        Seita=sparse(T,NodeNum*T);
        PW_no=find(i==wind_node);
        
        coefficient=[];
        for j=1:NodeNum
            coefficient=sparse([coefficient,diag(B(i,j)*ones(1,T))]);
        end
        Seita=coefficient;
        
        PWrt=sparse(T,R*T);
        if(~isempty(PW_no))
            PWrt=[];
            for t=1:T
                PW_part=sparse(1,R);
                PW_part(1,PW_no)=1;
                PWrt=blkdiag(PWrt,PW_part);
            end
        end
        
        Aeq_DCPowerFlow=[sparse(T,5*N*T),Seita,sparse(T,N*T),PWrt];
        beq_DCPowerFlow=[sparse(T,1)];
        Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
        beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];
    end
    
end

%Seita=0
% Seita=sparse(T,NodeNum*T);
% Seita(:,1:T)=sparse(diag(ones(1,T)));
% Aeq_DCPowerFlow=[sparse(T,5*N*T),Seita,sparse(T,N*T),sparse(T,R*T)];
% beq_DCPowerFlow=[sparse(T,1)];
% Aeq_constraints_DCPowerFlow=[Aeq_constraints_DCPowerFlow;Aeq_DCPowerFlow];
% beq_constraints_DCPowerFlow=[beq_constraints_DCPowerFlow;beq_DCPowerFlow];

Aineq_DCPowerFlow=[];
bineq_DCPowerFlow=[];


for index=1:length(branchI)
    Seita_i=branchI(index);
    Seita_j=branchJ(index);
    Seita=sparse(T,NodeNum*T);
    
    Seita(1:T,(Seita_i-1)*T+1:Seita_i*T)=diag((1/branchX(index))*ones(1,T));
    Seita(1:T,(Seita_j-1)*T+1:Seita_j*T)=diag(-1*(1/branchX(index))*ones(1,T));
    
    Aineq_DCPowerFlow=sparse([Aineq_DCPowerFlow;sparse(T,5*N*T),Seita,sparse(T,N*T),sparse(T,R*T)]);
    bineq_DCPowerFlow=[bineq_DCPowerFlow;branchP(index)*ones(T,1)];
    
    Aineq_DCPowerFlow=sparse([Aineq_DCPowerFlow;sparse(T,5*N*T),-1*Seita,sparse(T,N*T),sparse(T,R*T)]);
    bineq_DCPowerFlow=[bineq_DCPowerFlow;branchP(index)*ones(T,1)];
    
    
end
Aineq_constraints_DCPowerFlow=[Aineq_constraints_DCPowerFlow;Aineq_DCPowerFlow];
bineq_constraints_DCPowerFlow=[bineq_constraints_DCPowerFlow;bineq_DCPowerFlow];


eq.A=Aeq_constraints_DCPowerFlow;
eq.b=beq_constraints_DCPowerFlow;

ineq.A=Aineq_constraints_DCPowerFlow;
ineq.b=bineq_constraints_DCPowerFlow;


end